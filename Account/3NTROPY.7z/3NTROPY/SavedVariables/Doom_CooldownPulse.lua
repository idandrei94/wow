
DCP_Saved = {
	["fadeInTime"] = 0.3,
	["petOverlay"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
	},
	["holdTime"] = 0,
	["fadeOutTime"] = 0.7,
	["maxAlpha"] = 0.7,
	["x"] = 614.4000287902251,
	["iconSize"] = 75,
	["animScale"] = 1.5,
	["ignoredSpells"] = "",
	["y"] = 384.000026990836,
}
