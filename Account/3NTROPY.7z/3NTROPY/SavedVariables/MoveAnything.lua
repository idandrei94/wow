
MoveAnything_CustomFrames = {
}
MoveAnything_CharacterSettings = {
	["default"] = {
	},
}
MoveAnything_UseCharacterSettings = nil
MADB = {
	["collapsed"] = true,
}
