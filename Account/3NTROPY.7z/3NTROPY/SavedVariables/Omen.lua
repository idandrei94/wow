
Omen3DB = {
	["profileKeys"] = {
		["Mirceabravo - Blackrock [PvP only]"] = "Mirceabravo - Blackrock [PvP only]",
		["Ulrezaj - Icecrown"] = "Ulrezaj - Icecrown",
		["Lingurita - Lordaeron"] = "Lingurita - Lordaeron",
	},
	["profiles"] = {
		["Mirceabravo - Blackrock [PvP only]"] = {
			["PositionW"] = 200.0000027354896,
			["PositionH"] = 81.99999849548074,
			["PositionY"] = 99.49396643321771,
			["Shown"] = true,
			["PositionX"] = 1316.833205232636,
		},
		["Ulrezaj - Icecrown"] = {
			["PositionX"] = 570.1666910451083,
			["PositionY"] = 501.6666844028324,
		},
		["Lingurita - Lordaeron"] = {
			["PositionX"] = 570.499982563299,
			["PositionY"] = 459.0000086157817,
		},
	},
}
