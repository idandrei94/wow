
CombatLogFixDB = {
	["report"] = true,
	["zone"] = true,
	["auto"] = true,
	["wait"] = false,
}
