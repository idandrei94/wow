
sadb = {
	["profileKeys"] = {
		["Rimgar - Icecrown"] = "Default",
		["Vrael - Icecrown"] = "Default",
		["Nalar - Icecrown"] = "Default",
		["Denathra - Icecrown"] = "Default",
		["Vhalanor - Icecrown"] = "Default",
		["Noobschmoq - Icecrown"] = "Default",
		["Muiex - Icecrown"] = "Default",
		["Aevie - Icecrown"] = "Default",
		["Urgash - Icecrown"] = "Default",
		["Ulrezaj - Icecrown"] = "Default",
		["Pocaitoru - Icecrown"] = "Default",
		["Kalaam - Icecrown"] = "Default",
		["Gligor - Icecrown"] = "Default",
		["Mirceabravo - Blackrock [PvP only]"] = "Default",
		["Maciucaru - Icecrown"] = "Default",
		["Drext - Icecrown"] = "Default",
		["Lingurita - Lordaeron"] = "Default",
		["Mirceabravo - Icecrown"] = "Default",
		["Rakhnis - Icecrown"] = "Default",
		["Praxia - Icecrown"] = "Default",
		["Izanagi - Icecrown"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
