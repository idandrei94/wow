
Icicledb = {
	["profileKeys"] = {
		["Rimgar - Icecrown"] = "Default",
		["Vrael - Icecrown"] = "Default",
		["Nalar - Icecrown"] = "Default",
		["Denathra - Icecrown"] = "Default",
		["Vhalanor - Icecrown"] = "Default",
		["Drext - Icecrown"] = "Default",
		["Muiex - Icecrown"] = "Default",
		["Aevie - Icecrown"] = "Default",
		["Urgash - Icecrown"] = "Default",
		["Ulrezaj - Icecrown"] = "Default",
		["Pocaitoru - Icecrown"] = "Default",
		["Kalaam - Icecrown"] = "Default",
		["Lingurita - Lordaeron"] = "Default",
		["Mirceabravo - Blackrock [PvP only]"] = "Default",
		["Maciucaru - Icecrown"] = "Default",
		["Noobschmoq - Icecrown"] = "Default",
		["Gligor - Icecrown"] = "Default",
		["Mirceabravo - Icecrown"] = "Default",
		["Rakhnis - Icecrown"] = "Default",
		["Praxia - Icecrown"] = "Default",
		["Izanagi - Icecrown"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
