
ShadowtimerGlobalSettings = nil
