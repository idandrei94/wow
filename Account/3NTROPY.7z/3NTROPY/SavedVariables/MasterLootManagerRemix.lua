
MasterLootManagerSettings = {
	["ascending"] = false,
	["raidwarning"] = true,
	["enforcelow"] = true,
	["ignorefixed"] = true,
	["enforcehigh"] = true,
}
MasterLootLogger_Log = {
}
MasterLootLogger_LastExport = "$I,$N,$S,$W,$T,$V,$H:$M,$m/$d/$y"
