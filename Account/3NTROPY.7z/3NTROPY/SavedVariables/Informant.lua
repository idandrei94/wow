
InformantConfig = {
	["welcomed"] = true,
	["profile.Default"] = {
	},
	["position"] = {
		["y"] = 426.6666958452222,
		["x"] = 682.6666433238223,
	},
}
InformantLocalUpdates = nil
