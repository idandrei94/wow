
BagnonGlobalSettings = {
	["version"] = "2.13.3",
	["highlightOpacity"] = 1,
}
