
TomTomDB = {
	["profileKeys"] = {
		["Rimgar - Icecrown"] = "Default",
		["Vrael - Icecrown"] = "Default",
		["Nalar - Icecrown"] = "Default",
		["Denathra - Icecrown"] = "Default",
		["Vhalanor - Icecrown"] = "Default",
		["Drext - Icecrown"] = "Default",
		["Muiex - Icecrown"] = "Default",
		["Aevie - Icecrown"] = "Default",
		["Urgash - Icecrown"] = "Default",
		["Ulrezaj - Icecrown"] = "Default",
		["Pocaitoru - Icecrown"] = "Default",
		["Kalaam - Icecrown"] = "Default",
		["Lingurita - Lordaeron"] = "Default",
		["Mirceabravo - Blackrock [PvP only]"] = "Default",
		["Maciucaru - Icecrown"] = "Default",
		["Noobschmoq - Icecrown"] = "Default",
		["Gligor - Icecrown"] = "Default",
		["Mirceabravo - Icecrown"] = "Default",
		["Rakhnis - Icecrown"] = "Default",
		["Praxia - Icecrown"] = "Default",
		["Izanagi - Icecrown"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
TomTomWaypoints = {
	["profileKeys"] = {
		["Rimgar - Icecrown"] = "Rimgar - Icecrown",
		["Vrael - Icecrown"] = "Vrael - Icecrown",
		["Nalar - Icecrown"] = "Nalar - Icecrown",
		["Denathra - Icecrown"] = "Denathra - Icecrown",
		["Vhalanor - Icecrown"] = "Vhalanor - Icecrown",
		["Drext - Icecrown"] = "Drext - Icecrown",
		["Muiex - Icecrown"] = "Muiex - Icecrown",
		["Aevie - Icecrown"] = "Aevie - Icecrown",
		["Urgash - Icecrown"] = "Urgash - Icecrown",
		["Ulrezaj - Icecrown"] = "Ulrezaj - Icecrown",
		["Pocaitoru - Icecrown"] = "Pocaitoru - Icecrown",
		["Kalaam - Icecrown"] = "Kalaam - Icecrown",
		["Lingurita - Lordaeron"] = "Lingurita - Lordaeron",
		["Mirceabravo - Blackrock [PvP only]"] = "Mirceabravo - Blackrock [PvP only]",
		["Maciucaru - Icecrown"] = "Maciucaru - Icecrown",
		["Noobschmoq - Icecrown"] = "Noobschmoq - Icecrown",
		["Gligor - Icecrown"] = "Gligor - Icecrown",
		["Mirceabravo - Icecrown"] = "Mirceabravo - Icecrown",
		["Rakhnis - Icecrown"] = "Rakhnis - Icecrown",
		["Praxia - Icecrown"] = "Praxia - Icecrown",
		["Izanagi - Icecrown"] = "Izanagi - Icecrown",
	},
	["profiles"] = {
		["Rimgar - Icecrown"] = {
		},
		["Vrael - Icecrown"] = {
		},
		["Nalar - Icecrown"] = {
		},
		["Denathra - Icecrown"] = {
		},
		["Vhalanor - Icecrown"] = {
		},
		["Drext - Icecrown"] = {
		},
		["Muiex - Icecrown"] = {
		},
		["Aevie - Icecrown"] = {
		},
		["Urgash - Icecrown"] = {
		},
		["Ulrezaj - Icecrown"] = {
		},
		["Pocaitoru - Icecrown"] = {
		},
		["Kalaam - Icecrown"] = {
		},
		["Lingurita - Lordaeron"] = {
		},
		["Mirceabravo - Blackrock [PvP only]"] = {
		},
		["Maciucaru - Icecrown"] = {
		},
		["Noobschmoq - Icecrown"] = {
		},
		["Gligor - Icecrown"] = {
		},
		["Mirceabravo - Icecrown"] = {
		},
		["Rakhnis - Icecrown"] = {
		},
		["Praxia - Icecrown"] = {
		},
		["Izanagi - Icecrown"] = {
		},
	},
}
