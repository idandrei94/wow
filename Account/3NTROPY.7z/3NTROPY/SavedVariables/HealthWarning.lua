
HealthWarningDB = {
	["treshold"] = 20,
}
