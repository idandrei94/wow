
OmniCCGlobalSettings = {
	["version"] = "3.0.4",
}
