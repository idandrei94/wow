
PowaSet = {
}
PowaMisc = {
	["AnimationLimit"] = 0,
	["TimerRoundUp"] = true,
	["Disabled"] = false,
	["DefaultTimerTexture"] = "Original",
	["AnimationFps"] = 30,
	["Version"] = "3.0.0S",
	["AllowInspections"] = true,
	["DefaultStacksTexture"] = "Original",
	["OnUpdateLimit"] = 0,
	["debug"] = false,
}
PowaTimer = {
}
PowaPlayerListe = {
	"Page 1", -- [1]
	"Page 2", -- [2]
	"Page 3", -- [3]
	"Page 4", -- [4]
	"Page 5", -- [5]
}
PowaState = {
}
