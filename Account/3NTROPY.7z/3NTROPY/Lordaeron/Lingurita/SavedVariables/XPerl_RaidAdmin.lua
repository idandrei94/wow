
XPerl_Admin = {
	["ResistSort"] = "fr",
	["Transparency"] = 0.8,
	["SavedRosters"] = {
	},
	["AutoHideShow"] = 1,
}
XPerl_CheckItems = {
	{
		["link"] = "dur",
		["fixed"] = true,
	}, -- [1]
	{
		["link"] = "reg",
		["fixed"] = true,
	}, -- [2]
	{
		["link"] = "res",
		["fixed"] = true,
	}, -- [3]
}
