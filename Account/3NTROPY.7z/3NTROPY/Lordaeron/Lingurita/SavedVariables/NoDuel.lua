
NoDuelData = {
	["minimappos"] = 45,
	["whisper"] = "No thanks, no duels please!",
}
