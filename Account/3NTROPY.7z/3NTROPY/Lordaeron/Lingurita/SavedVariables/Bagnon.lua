
BagnonFrameSettings = {
	["frames"] = {
	},
	["version"] = "2.13.3",
}
