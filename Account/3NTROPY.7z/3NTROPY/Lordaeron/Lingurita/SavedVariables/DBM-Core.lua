
DBM_SavedOptions = {
	["SpecialWarningFontSize"] = 50,
	["ShowWarningsInChat"] = true,
	["DontSetIcons"] = false,
	["BigBrotherAnnounceToRaid"] = false,
	["ArrowPosX"] = 0,
	["HPFramePoint"] = "CENTER",
	["AutoRespond"] = true,
	["HealthFrameGrowUp"] = false,
	["StatusEnabled"] = true,
	["HideBossEmoteFrame"] = false,
	["ShowBigBrotherOnCombatStart"] = false,
	["BlockVersionUpdatePopup"] = true,
	["WarningColors"] = {
		{
			["b"] = 0.94,
			["g"] = 0.8,
			["r"] = 0.41,
		}, -- [1]
		{
			["b"] = 0,
			["g"] = 0.95,
			["r"] = 0.95,
		}, -- [2]
		{
			["b"] = 0,
			["g"] = 0.5,
			["r"] = 1,
		}, -- [3]
		{
			["b"] = 0.1,
			["g"] = 0.1,
			["r"] = 1,
		}, -- [4]
	},
	["RangeFrameY"] = -50,
	["SpecialWarningFont"] = "Fonts\\FRIZQT__.TTF",
	["SpamBlockRaidWarning"] = true,
	["ShowFakedRaidWarnings"] = false,
	["LatencyThreshold"] = 250,
	["DontSendBossAnnounces"] = false,
	["HPFrameMaxEntries"] = 5,
	["WarningIconRight"] = true,
	["RangeFramePoint"] = "CENTER",
	["SpecialWarningPoint"] = "CENTER",
	["ShowSpecialWarnings"] = true,
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["AlwaysShowHealthFrame"] = false,
	["DontShowBossAnnounces"] = false,
	["RangeFrameSound2"] = "none",
	["SpecialWarningY"] = 75,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["RangeFrameLocked"] = false,
	["Enabled"] = true,
	["RangeFrameX"] = 50,
	["WarningIconLeft"] = true,
	["HealthFrameWidth"] = 200,
	["RangeFrameSound1"] = "none",
	["DontSendBossWhispers"] = false,
	["SpecialWarningFontColor"] = {
		0, -- [1]
		0, -- [2]
		1, -- [3]
	},
	["HPFrameY"] = 50,
	["FixCLEUOnCombatStart"] = false,
	["SpecialWarningX"] = 0,
	["ShowMinimapButton"] = true,
	["HPFrameX"] = -50,
	["HealthFrameLocked"] = false,
	["SpamBlockBossWhispers"] = false,
	["ArrowPosY"] = -150,
	["ArrowPoint"] = "TOP",
}
DBT_SavedOptions = {
	["DBM"] = {
	},
}
