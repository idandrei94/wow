
NoDuelData = {
	["duelok"] = 1,
	["minimappos"] = 45,
	["whisper"] = "No thanks, no duels please!",
}
