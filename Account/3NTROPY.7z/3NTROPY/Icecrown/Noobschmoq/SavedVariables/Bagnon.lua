
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				true, -- [4]
			},
			["y"] = -190.3954442842722,
			["x"] = -120.8884275455259,
		},
	},
	["version"] = "2.13.3",
}
