
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 16,
			["y"] = -130.0443867377721,
			["x"] = -131.5557425414654,
		},
		["bank"] = {
			["y"] = -128.5930453870379,
			["x"] = 75.06179026440627,
			["point"] = "TOPLEFT",
		},
	},
	["version"] = "2.13.3",
}
