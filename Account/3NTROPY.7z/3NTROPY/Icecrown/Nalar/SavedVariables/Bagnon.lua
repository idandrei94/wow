
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 12,
			["y"] = -41.0273366363914,
			["x"] = -195.9528612229376,
		},
		["bank"] = {
			["point"] = "TOPLEFT",
			["itemFrameColumns"] = 12,
			["y"] = -107.2050008032081,
			["x"] = 76.00982779340845,
		},
	},
	["version"] = "2.13.3",
}
