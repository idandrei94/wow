
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 12,
			["y"] = -55.23472545361426,
			["x"] = -142.2223486626294,
		},
		["bank"] = {
			["y"] = 123.2590332875572,
			["x"] = 64.00031075161611,
			["itemFrameColumns"] = 16,
		},
	},
	["version"] = "2.13.3",
}
