
DBMWorldEvent_SavedVars = nil
DBMWorldEvent_SavedStats = nil
