
NoDuelData = {
	["duelok"] = 1,
	["whisper"] = "No thanks, no duels please!",
	["minimappos"] = 45,
}
