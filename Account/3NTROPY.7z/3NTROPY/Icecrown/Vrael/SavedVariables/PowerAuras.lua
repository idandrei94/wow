
PowaSet = {
}
PowaMisc = {
	["AnimationLimit"] = 0,
	["TimerRoundUp"] = true,
	["Disabled"] = false,
	["DefaultTimerTexture"] = "Original",
	["AnimationFps"] = 30,
	["Version"] = "3.0.0S",
	["debug"] = false,
	["OnUpdateLimit"] = 0,
	["DefaultStacksTexture"] = "Original",
	["AllowInspections"] = true,
}
PowaTimer = {
}
PowaPlayerListe = {
	"Page 1", -- [1]
	"Page 2", -- [2]
	"Page 3", -- [3]
	"Page 4", -- [4]
	"Page 5", -- [5]
}
PowaState = {
}
