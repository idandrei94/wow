
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Argussg"] = {
			["GUID"] = "0x070000000051B851",
			["TimeLast"] = {
				["TimeHeal"] = 1604179445,
				["OVERALL"] = 1604179447,
				["DamageTaken"] = 1604179447,
				["RageGain"] = 1604179445,
				["HealingTaken"] = 1604179445,
				["TimeDamage"] = 1604179445,
				["Healing"] = 1604179445,
				["ActiveTime"] = 1604179445,
				["DOT_Time"] = 1604179441,
				["Damage"] = 1604179445,
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"HEAL", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"HEAL", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					2.53, -- [1]
				},
				["Healing"] = {
					1116, -- [1]
				},
				["DamageTaken"] = {
					4457, -- [1]
				},
				["RageGain"] = {
					27, -- [1]
				},
				["ActiveTime"] = {
					38.31000000000001, -- [1]
				},
				["HealingTaken"] = {
					1116, -- [1]
				},
				["TimeDamage"] = {
					35.78000000000001, -- [1]
				},
				["DOT_Time"] = {
					30, -- [1]
				},
				["Damage"] = {
					30553, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "Argussg",
			["level"] = 80,
			["LastDamageAbility"] = "Horseman's Cleave",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[5] = 0.9973725132714891,
				[16] = 12.16151000053622,
				[7] = 0.9973725132714891,
				[9] = 0.9973725132714891,
				[39] = 0.9973725132714891,
				[42] = 0.9973725132714891,
				[46] = 0.9973725132714891,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 2268,
			["LastAbility"] = 1138228.079,
			["Owner"] = false,
			["LastEventHealth"] = {
				"17018 (91%)", -- [1]
				"17018 (91%)", -- [2]
				"17018 (91%)", -- [3]
				"17018 (91%)", -- [4]
				"17204 (92%)", -- [5]
				"17204 (92%)", -- [6]
				"17390 (93%)", -- [7]
				"17390 (93%)", -- [8]
				"17576 (94%)", -- [9]
				"17576 (94%)", -- [10]
				"17576 (94%)", -- [11]
				"17576 (94%)", -- [12]
				"17576 (94%)", -- [13]
				"17576 (94%)", -- [14]
				"17576 (94%)", -- [15]
				"15308 (82%)", -- [16]
				"16460 (88%)", -- [17]
				"16460 (88%)", -- [18]
				"16460 (88%)", -- [19]
				"16460 (88%)", -- [20]
				"16460 (88%)", -- [21]
				"16460 (88%)", -- [22]
				"16460 (88%)", -- [23]
				"16460 (88%)", -- [24]
				"16460 (88%)", -- [25]
				"16460 (88%)", -- [26]
				"16460 (88%)", -- [27]
				"16460 (88%)", -- [28]
				"16460 (88%)", -- [29]
				"16460 (88%)", -- [30]
				"16460 (88%)", -- [31]
				"16460 (88%)", -- [32]
				"16460 (88%)", -- [33]
				"16460 (88%)", -- [34]
				"16460 (88%)", -- [35]
				"16460 (88%)", -- [36]
				"16460 (88%)", -- [37]
				"16460 (88%)", -- [38]
				"16646 (89%)", -- [39]
				"16646 (89%)", -- [40]
				"16646 (89%)", -- [41]
				"16832 (90%)", -- [42]
				"16832 (90%)", -- [43]
				"16832 (90%)", -- [44]
				"16832 (90%)", -- [45]
				"17018 (91%)", -- [46]
				"17018 (91%)", -- [47]
				"17018 (91%)", -- [48]
				"17018 (91%)", -- [49]
				"17018 (91%)", -- [50]
			},
			["NextEventNum"] = 17,
			["LastEventHealthNum"] = {
				91.25422274652796, -- [1]
				91.25422274652796, -- [2]
				91.25422274652796, -- [3]
				91.25422274652796, -- [4]
				92.25159525979946, -- [5]
				92.25159525979946, -- [6]
				93.24896777307095, -- [7]
				93.24896777307095, -- [8]
				94.24634028634243, -- [9]
				94.24634028634243, -- [10]
				94.24634028634243, -- [11]
				94.24634028634243, -- [12]
				94.24634028634243, -- [13]
				94.24634028634243, -- [14]
				94.24634028634243, -- [15]
				82.08483028580621, -- [16]
				88.2621052067135, -- [17]
				88.2621052067135, -- [18]
				88.2621052067135, -- [19]
				88.2621052067135, -- [20]
				88.2621052067135, -- [21]
				88.2621052067135, -- [22]
				88.2621052067135, -- [23]
				88.2621052067135, -- [24]
				88.2621052067135, -- [25]
				88.2621052067135, -- [26]
				88.2621052067135, -- [27]
				88.2621052067135, -- [28]
				88.2621052067135, -- [29]
				88.2621052067135, -- [30]
				88.2621052067135, -- [31]
				88.2621052067135, -- [32]
				88.2621052067135, -- [33]
				88.2621052067135, -- [34]
				88.2621052067135, -- [35]
				88.2621052067135, -- [36]
				88.2621052067135, -- [37]
				88.2621052067135, -- [38]
				89.25947771998499, -- [39]
				89.25947771998499, -- [40]
				89.25947771998499, -- [41]
				90.25685023325647, -- [42]
				90.25685023325647, -- [43]
				90.25685023325647, -- [44]
				90.25685023325647, -- [45]
				91.25422274652796, -- [46]
				91.25422274652796, -- [47]
				91.25422274652796, -- [48]
				91.25422274652796, -- [49]
				91.25422274652796, -- [50]
			},
			["LastEvents"] = {
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [1]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [2]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [3]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [4]
				"Argussg Bloodthirst Argussg Hit +186", -- [5]
				"Argussg Melee Head of the Horseman Crit -1480 (Physical)", -- [6]
				"Argussg Bloodthirst Argussg Hit +186", -- [7]
				"Argussg Whirlwind Head of the Horseman Crit -2145 (Physical)", -- [8]
				"Argussg Bloodthirst Argussg Hit +186", -- [9]
				"Argussg Whirlwind Pulsing Pumpkin Hit -834 (Physical)", -- [10]
				"Argussg Whirlwind Pulsing Pumpkin Hit -966 (Physical)", -- [11]
				"Argussg Whirlwind Head of the Horseman Hit -575 (Physical)", -- [12]
				"Argussg Whirlwind Pulsing Pumpkin Hit -509 (Physical)", -- [13]
				"Argussg Whirlwind Pulsing Pumpkin Hit -509 (Physical)", -- [14]
				"Argussg Melee Head of the Horseman Hit -455 (Physical)", -- [15]
				"Headless Horseman Horseman's Cleave Argussg Hit -2268 (Physical)", -- [16]
				"Argussg Melee Headless Horseman Hit -437 (Physical)", -- [17]
				"Argussg Rend (DoT) Headless Horseman Tick -535 (Physical)", -- [18]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -135 (Physical)", -- [19]
				"Argussg Whirlwind Headless Horseman Hit -944 (Physical)", -- [20]
				"Argussg Whirlwind Headless Horseman Crit -1309 (Physical)", -- [21]
				"Argussg Melee Headless Horseman Crit -1390 (Physical)", -- [22]
				"Argussg Melee Headless Horseman Miss", -- [23]
				"Argussg Rend (DoT) Headless Horseman Tick -535 (Physical)", -- [24]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -347 (Physical)", -- [25]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -347 (Physical)", -- [26]
				"Argussg Melee Headless Horseman Hit -844 (Physical)", -- [27]
				"Argussg Demoralizing Shout Headless Horseman Immune (Physical)", -- [28]
				"Argussg Melee Headless Horseman Immune", -- [29]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [30]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [31]
				"Argussg Rend Headless Horseman Immune (Physical)", -- [32]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [33]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [34]
				"Argussg Melee Head of the Horseman Crit -1590 (Physical)", -- [35]
				"Argussg Melee Headless Horseman Crit -1010 (Physical)", -- [36]
				"Argussg Heroic Strike Headless Horseman Hit -1087 (Physical)", -- [37]
				"Argussg Bloodthirst Headless Horseman Crit -2552 (Physical)", -- [38]
				"Argussg Bloodthirst Argussg Hit +186", -- [39]
				"Argussg Melee Headless Horseman Crit -906 (Physical)", -- [40]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -248 (Physical)", -- [41]
				"Argussg Bloodthirst Argussg Hit +186", -- [42]
				"Argussg Melee Headless Horseman Hit -769 (Physical)", -- [43]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -346 (Physical)", -- [44]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -346 (Physical)", -- [45]
				"Argussg Bloodthirst Argussg Hit +186", -- [46]
				"Argussg Melee Headless Horseman Hit -779 (Physical)", -- [47]
				"Argussg Melee Headless Horseman Miss", -- [48]
				"Argussg Bloodthirst Headless Horseman Crit -2292 (Physical)", -- [49]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [50]
			},
			["Name"] = "Argussg",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138224.823, -- [1]
				1138225.727, -- [2]
				1138226.678, -- [3]
				1138227.769, -- [4]
				1138227.944, -- [5]
				1138227.944, -- [6]
				1138228.077, -- [7]
				1138228.078, -- [8]
				1138228.078, -- [9]
				1138228.078, -- [10]
				1138228.078, -- [11]
				1138228.078, -- [12]
				1138228.079, -- [13]
				1138228.079, -- [14]
				1138228.079, -- [15]
				1138229.56, -- [16]
				1138203.66, -- [17]
				1138204.561, -- [18]
				1138205.234, -- [19]
				1138205.699, -- [20]
				1138205.7, -- [21]
				1138206.027, -- [22]
				1138206.187, -- [23]
				1138207.533, -- [24]
				1138207.533, -- [25]
				1138208.55, -- [26]
				1138208.701, -- [27]
				1138209.001, -- [28]
				1138209.002, -- [29]
				1138209.652, -- [30]
				1138210.493, -- [31]
				1138210.655, -- [32]
				1138211.542, -- [33]
				1138212.515, -- [34]
				1138215.208, -- [35]
				1138218.692, -- [36]
				1138218.999, -- [37]
				1138219.733, -- [38]
				1138221.201, -- [39]
				1138221.201, -- [40]
				1138221.201, -- [41]
				1138221.591, -- [42]
				1138221.591, -- [43]
				1138222.641, -- [44]
				1138223.674, -- [45]
				1138224.036, -- [46]
				1138224.036, -- [47]
				1138224.215, -- [48]
				1138224.434, -- [49]
				1138224.822, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["RageGain"] = 0,
					["RageGained"] = {
						["Charge"] = {
							["Details"] = {
								["Argussg"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGainedFrom"] = {
						["Argussg"] = {
							["Details"] = {
								["Charge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 21,
								},
							},
							["amount"] = 21,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 4457,
					["RageGainedFrom"] = {
						["Argussg"] = {
							["Details"] = {
								["Unbridled Wrath"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Tick"] = {
									["count"] = 10,
								},
							},
							["amount"] = 39,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 4457,
					},
					["DOT_Time"] = 30,
					["Damage"] = 30553,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 2.53,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 11200,
						["Physical"] = 19353,
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 2818,
								},
							},
							["amount"] = 2818,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4191,
								},
								["Whirlwind"] = {
									["count"] = 2720,
								},
							},
							["amount"] = 6911,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Unbridled Wrath"] = {
							["Details"] = {
								["Argussg"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["HealedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Bloodthirst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 186,
									["min"] = 186,
									["count"] = 6,
									["amount"] = 1116,
								},
							},
							["count"] = 6,
							["amount"] = 1116,
						},
					},
					["WhoHealed"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 38.31000000000001,
					["Healing"] = 1116,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 347,
									["min"] = 88,
									["count"] = 7,
									["amount"] = 1857,
								},
							},
							["count"] = 7,
							["amount"] = 1857,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2552,
									["min"] = 2292,
									["count"] = 2,
									["amount"] = 4844,
								},
							},
							["count"] = 2,
							["amount"] = 4844,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 535,
									["min"] = 515,
									["count"] = 3,
									["amount"] = 1585,
								},
							},
							["count"] = 3,
							["amount"] = 1585,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 844,
									["min"] = 437,
									["count"] = 6,
									["amount"] = 3950,
								},
								["Crit"] = {
									["max"] = 1590,
									["min"] = 874,
									["count"] = 6,
									["amount"] = 7250,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 11200,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2145,
									["min"] = 1309,
									["count"] = 2,
									["amount"] = 3454,
								},
								["Hit"] = {
									["max"] = 966,
									["min"] = 509,
									["count"] = 6,
									["amount"] = 4337,
								},
							},
							["count"] = 8,
							["amount"] = 7791,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2189,
									["min"] = 2189,
									["count"] = 1,
									["amount"] = 2189,
								},
								["Hit"] = {
									["max"] = 1087,
									["min"] = 1087,
									["count"] = 1,
									["amount"] = 1087,
								},
							},
							["count"] = 2,
							["amount"] = 3276,
						},
					},
					["HealingTaken"] = 1116,
					["RageGain"] = 12,
					["TimeDamage"] = 35.78000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 21,
								},
							},
							["amount"] = 21,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 4457,
					["RageGainedFrom"] = {
						["Argussg"] = {
							["Details"] = {
								["Unbridled Wrath"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Tick"] = {
									["count"] = 10,
								},
							},
							["amount"] = 39,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 4457,
					},
					["DOT_Time"] = 30,
					["Damage"] = 30553,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 2.53,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 11200,
						["Physical"] = 19353,
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 2818,
								},
							},
							["amount"] = 2818,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4191,
								},
								["Whirlwind"] = {
									["count"] = 2720,
								},
							},
							["amount"] = 6911,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Unbridled Wrath"] = {
							["Details"] = {
								["Argussg"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["HealedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Bloodthirst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 186,
									["min"] = 186,
									["count"] = 6,
									["amount"] = 1116,
								},
							},
							["count"] = 6,
							["amount"] = 1116,
						},
					},
					["WhoHealed"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 38.31000000000001,
					["Healing"] = 1116,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 347,
									["min"] = 88,
									["count"] = 7,
									["amount"] = 1857,
								},
							},
							["count"] = 7,
							["amount"] = 1857,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2552,
									["min"] = 2292,
									["count"] = 2,
									["amount"] = 4844,
								},
							},
							["count"] = 2,
							["amount"] = 4844,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 535,
									["min"] = 515,
									["count"] = 3,
									["amount"] = 1585,
								},
							},
							["count"] = 3,
							["amount"] = 1585,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 844,
									["min"] = 437,
									["count"] = 6,
									["amount"] = 3950,
								},
								["Crit"] = {
									["max"] = 1590,
									["min"] = 874,
									["count"] = 6,
									["amount"] = 7250,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 11200,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2145,
									["min"] = 1309,
									["count"] = 2,
									["amount"] = 3454,
								},
								["Hit"] = {
									["max"] = 966,
									["min"] = 509,
									["count"] = 6,
									["amount"] = 4337,
								},
							},
							["count"] = 8,
							["amount"] = 7791,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2189,
									["min"] = 2189,
									["count"] = 1,
									["amount"] = 2189,
								},
								["Hit"] = {
									["max"] = 1087,
									["min"] = 1087,
									["count"] = 1,
									["amount"] = 1087,
								},
							},
							["count"] = 2,
							["amount"] = 3276,
						},
					},
					["HealingTaken"] = 1116,
					["RageGain"] = 12,
					["TimeDamage"] = 35.78000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
					},
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 21,
								},
							},
							["amount"] = 21,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["TimeSpent"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["DamageTaken"] = 4457,
					["RageGainedFrom"] = {
						["Argussg"] = {
							["Details"] = {
								["Unbridled Wrath"] = {
									["count"] = 12,
								},
								["Charge"] = {
									["count"] = 15,
								},
							},
							["amount"] = 27,
						},
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 38.31000000000001,
					["ElementTaken"] = {
						["Physical"] = 4457,
					},
					["RageGained"] = {
						["Unbridled Wrath"] = {
							["Details"] = {
								["Argussg"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["Charge"] = {
							["Details"] = {
								["Argussg"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 30553,
					["WhoHealed"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["TimeHeal"] = 2.53,
					["HealingTaken"] = 1116,
					["HealedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 1116,
								},
							},
							["amount"] = 1116,
						},
					},
					["Heals"] = {
						["Bloodthirst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 186,
									["min"] = 186,
									["count"] = 6,
									["amount"] = 1116,
								},
							},
							["count"] = 6,
							["amount"] = 1116,
						},
					},
					["Healing"] = 1116,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
					},
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 347,
									["min"] = 88,
									["count"] = 7,
									["amount"] = 1857,
								},
							},
							["count"] = 7,
							["amount"] = 1857,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2552,
									["min"] = 2292,
									["count"] = 2,
									["amount"] = 4844,
								},
							},
							["count"] = 2,
							["amount"] = 4844,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 535,
									["min"] = 515,
									["count"] = 3,
									["amount"] = 1585,
								},
							},
							["count"] = 3,
							["amount"] = 1585,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 844,
									["min"] = 437,
									["count"] = 6,
									["amount"] = 3950,
								},
								["Crit"] = {
									["max"] = 1590,
									["min"] = 874,
									["count"] = 6,
									["amount"] = 7250,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 11200,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2145,
									["min"] = 1309,
									["count"] = 2,
									["amount"] = 3454,
								},
								["Hit"] = {
									["max"] = 966,
									["min"] = 509,
									["count"] = 6,
									["amount"] = 4337,
								},
							},
							["count"] = 8,
							["amount"] = 7791,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2189,
									["min"] = 2189,
									["count"] = 1,
									["amount"] = 2189,
								},
								["Hit"] = {
									["max"] = 1087,
									["min"] = 1087,
									["count"] = 1,
									["amount"] = 1087,
								},
							},
							["count"] = 2,
							["amount"] = 3276,
						},
					},
					["RageGain"] = 27,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Tick"] = {
									["count"] = 10,
								},
							},
							["amount"] = 39,
						},
					},
					["TimeDamage"] = 35.78000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 5.28,
								},
								["Demoralizing Shout"] = {
									["count"] = 0.3,
								},
								["Rend"] = {
									["count"] = 0.16,
								},
								["Bloodthirst"] = {
									["count"] = 0.95,
								},
								["Rend (DoT)"] = {
									["count"] = 3.99,
								},
								["Deep Wounds"] = {
									["count"] = 9.609999999999999,
								},
								["Melee"] = {
									["count"] = 9.18,
								},
								["Whirlwind"] = {
									["count"] = 0.47,
								},
								["Heroic Strike"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 32.22,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.56,
								},
								["Whirlwind"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.56,
						},
					},
					["ElementDone"] = {
						["Melee"] = 11200,
						["Physical"] = 19353,
					},
					["DOT_Time"] = 30,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Whirlwind"] = {
									["count"] = 2818,
								},
							},
							["amount"] = 2818,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4191,
								},
								["Whirlwind"] = {
									["count"] = 2720,
								},
							},
							["amount"] = 6911,
						},
					},
				},
			},
			["UnitLockout"] = 1604179376,
			["LastActive"] = 1604179447,
		},
		["Headless Horseman"] = {
			["GUID"] = "0xF130005C8200008A",
			["LastEventHealth"] = {
				"29663 (23%)", -- [1]
				"28280 (22%)", -- [2]
				"26861 (21%)", -- [3]
				"26515 (21%)", -- [4]
				"26515 (21%)", -- [5]
				"26056 (20%)", -- [6]
				"25383 (20%)", -- [7]
				"22617 (17%)", -- [8]
				"20549 (16%)", -- [9]
				"20203 (16%)", -- [10]
				"20203 (16%)", -- [11]
				"20203 (16%)", -- [12]
				"17108 (13%)", -- [13]
				"6777 (5%)", -- [14]
				"6104 (4%)", -- [15]
				"3812 (3%)", -- [16]
				"1 (0%)", -- [17]
				"1 (0%)", -- [18]
				"1 (0%)", -- [19]
				"1 (0%)", -- [20]
				"1 (0%)", -- [21]
				"1 (0%)", -- [22]
				"2521 (2%)", -- [23]
				"2521 (2%)", -- [24]
				"2521 (2%)", -- [25]
				"2521 (2%)", -- [26]
				"5041 (4%)", -- [27]
				"5041 (4%)", -- [28]
				"5041 (4%)", -- [29]
				"7561 (6%)", -- [30]
				"7561 (6%)", -- [31]
				"7561 (6%)", -- [32]
				"7561 (6%)", -- [33]
				"7561 (6%)", -- [34]
				"9147 (97%)", -- [35]
				"9147 (97%)", -- [36]
				"9147 (97%)", -- [37]
				"9147 (97%)", -- [38]
				"69527 (55%)", -- [39]
				"67272 (53%)", -- [40]
				"64206 (50%)", -- [41]
				"64206 (50%)", -- [42]
				"64206 (50%)", -- [43]
				"63958 (50%)", -- [44]
				"56806 (45%)", -- [45]
				"56439 (44%)", -- [46]
				"56439 (44%)", -- [47]
				"49831 (39%)", -- [48]
				"48596 (38%)", -- [49]
				"46241 (36%)", -- [50]
			},
			["LastAttackedBy"] = "Vrael",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Damage"] = {
					9101, -- [1]
				},
				["TimeDamage"] = {
					36.45, -- [1]
				},
				["DamageTaken"] = {
					417002, -- [1]
				},
				["ActiveTime"] = {
					36.45, -- [1]
				},
			},
			["enClass"] = "MOB",
			["unit"] = "party1target",
			["LastAbility"] = 1138229.56,
			["TimeLast"] = {
				["ActiveTime"] = 1604179447,
				["TimeDamage"] = 1604179447,
				["OVERALL"] = 1604179447,
				["DamageTaken"] = 1604179442,
				["Damage"] = 1604179447,
			},
			["level"] = -1,
			["LastDamageAbility"] = "Pyroblast",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				13.15714285714286, -- [1]
				1.097619047619048, -- [2]
				1.126190476190476, -- [3]
				0.2746031746031746, -- [4]
				2.195238095238095, -- [5]
				0.3642857142857143, -- [6]
				0.5341269841269841, -- [7]
				nil, -- [8]
				1.641269841269841, -- [9]
				0.2746031746031746, -- [10]
				0.6182539682539683, -- [11]
				1.838095238095238, -- [12]
				nil, -- [13]
				8.199206349206349, -- [14]
				0.5341269841269841, -- [15]
				1.819047619047619, -- [16]
				16.42142857142857, -- [17]
				[39] = 0.3642857142857143,
				[40] = 1.78968253968254,
				[41] = 2.433333333333333,
				[43] = 0.7190476190476191,
				[44] = 0.1968253968253968,
				[45] = 4.957142857142857,
				[46] = 0.2912698412698413,
				[47] = 0.6103174603174604,
				[48] = 5.244444444444445,
				[49] = 0.3698412698412699,
				[50] = 1.869047619047619,
			},
			["type"] = "Boss",
			["FightsSaved"] = 1,
			["GuardianReverseGUIDs"] = {
				["Pulsing Pumpkin"] = {
					["LatestGuardian"] = 3,
					["GUIDs"] = {
						"0xF130005C8E000092", -- [1]
						"0xF130005C8E000093", -- [2]
						"0xF130005C8E000094", -- [3]
						[0] = "0xF130005C8E000091",
					},
				},
			},
			["LastDamageTaken"] = 20691,
			["Owner"] = false,
			["Pet"] = {
				"Pulsing Pumpkin <Headless Horseman>", -- [1]
			},
			["NextEventNum"] = 39,
			["LastEventHealthNum"] = {
				23.54206349206349, -- [1]
				22.44444444444444, -- [2]
				21.31825396825397, -- [3]
				21.04365079365079, -- [4]
				21.04365079365079, -- [5]
				20.67936507936508, -- [6]
				20.1452380952381, -- [7]
				17.95, -- [8]
				16.30873015873016, -- [9]
				16.03412698412699, -- [10]
				16.03412698412699, -- [11]
				16.03412698412699, -- [12]
				13.57777777777778, -- [13]
				5.378571428571429, -- [14]
				4.844444444444444, -- [15]
				3.025396825396825, -- [16]
				0.0007936507936507937, -- [17]
				0.0007936507936507937, -- [18]
				0.0007936507936507937, -- [19]
				0.0007936507936507937, -- [20]
				0.0007936507936507937, -- [21]
				0.0007936507936507937, -- [22]
				2.000793650793651, -- [23]
				2.000793650793651, -- [24]
				2.000793650793651, -- [25]
				2.000793650793651, -- [26]
				4.000793650793651, -- [27]
				4.000793650793651, -- [28]
				4.000793650793651, -- [29]
				6.000793650793651, -- [30]
				6.000793650793651, -- [31]
				6.000793650793651, -- [32]
				6.000793650793651, -- [33]
				6.000793650793651, -- [34]
				97.83934110600065, -- [35]
				97.83934110600065, -- [36]
				97.83934110600065, -- [37]
				97.83934110600065, -- [38]
				55.18015873015873, -- [39]
				53.39047619047619, -- [40]
				50.95714285714286, -- [41]
				50.95714285714286, -- [42]
				50.95714285714286, -- [43]
				50.76031746031746, -- [44]
				45.08412698412698, -- [45]
				44.79285714285714, -- [46]
				44.79285714285714, -- [47]
				39.5484126984127, -- [48]
				38.56825396825397, -- [49]
				36.69920634920635, -- [50]
			},
			["LastEvents"] = {
				"Vrael Fireball Headless Horseman Crit -16578 (Fire)", -- [1]
				"Thrug Rend (DoT) Headless Horseman Tick -1383 (Physical)", -- [2]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1419 (Fire)", -- [3]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -346 (Physical)", -- [4]
				"Thrug Melee Headless Horseman Hit -2766 (Physical)", -- [5]
				"Teebz Frost Fever (DoT) Headless Horseman Tick -459 (Frost)", -- [6]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -673 (Physical)", -- [7]
				"Headless Horseman Melee Teebz Parry", -- [8]
				"Teebz Death Strike Headless Horseman Hit -2068 (Physical)", -- [9]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -346 (Physical)", -- [10]
				"Argussg Melee Headless Horseman Hit -779 (Physical)", -- [11]
				"Teebz Melee Headless Horseman Hit -2316 (Physical)", -- [12]
				"Argussg Melee Headless Horseman Miss", -- [13]
				"Vrael Fireball Headless Horseman Hit -10331 (Fire)", -- [14]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -673 (Physical)", -- [15]
				"Argussg Bloodthirst Headless Horseman Crit -2292 (Physical)", -- [16]
				"Vrael Pyroblast Headless Horseman Crit -20691 (Fire)", -- [17]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [18]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [19]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [20]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [21]
				"Thrug Rend Headless Horseman Immune (Physical)", -- [22]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [23]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [24]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [25]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [26]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [27]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [28]
				"Vrael Pyroblast Headless Horseman Immune (Fire)", -- [29]
				"Teebz Melee Headless Horseman Immune", -- [30]
				"Argussg Deep Wounds Headless Horseman Immune (Physical)", -- [31]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [32]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [33]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [34]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [35]
				"Baldrdove Holy Nova Headless Horseman Immune (Holy)", -- [36]
				"Headless Horseman Horseman's Cleave Thrug Hit -1666 (Physical)", -- [37]
				"Headless Horseman Horseman's Cleave Argussg Hit -2268 (Physical)", -- [38]
				"Teebz Frost Fever (DoT) Headless Horseman Tick -459 (Frost)", -- [39]
				"Teebz Heart Strike Headless Horseman Hit -2255 (Physical)", -- [40]
				"Teebz Rune Strike Headless Horseman Hit -3066 (Physical)", -- [41]
				"Headless Horseman Melee Teebz Absorb (821 Absorbed)", -- [42]
				"Argussg Melee Headless Horseman Crit -906 (Physical)", -- [43]
				"Argussg Deep Wounds (DoT) Headless Horseman Tick -248 (Physical)", -- [44]
				"Vrael Ignite (DoT) Headless Horseman Tick -6246 (Fire)", -- [45]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -367 (Physical)", -- [46]
				"Argussg Melee Headless Horseman Hit -769 (Physical)", -- [47]
				"Thrug Overpower Headless Horseman Crit -6608 (Physical)", -- [48]
				"Teebz Blood Plague (DoT) Headless Horseman Tick -466 (Shadow)", -- [49]
				"Teebz Heart Strike Headless Horseman Hit -2355 (Physical)", -- [50]
			},
			["Name"] = "Headless Horseman",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				false, -- [42]
				true, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				1138222.483, -- [1]
				1138222.484, -- [2]
				1138222.484, -- [3]
				1138222.641, -- [4]
				1138223.096, -- [5]
				1138223.096, -- [6]
				1138223.096, -- [7]
				1138223.317, -- [8]
				1138223.674, -- [9]
				1138223.674, -- [10]
				1138224.036, -- [11]
				1138224.036, -- [12]
				1138224.215, -- [13]
				1138224.216, -- [14]
				1138224.216, -- [15]
				1138224.434, -- [16]
				1138224.436, -- [17]
				1138224.823, -- [18]
				1138224.823, -- [19]
				1138224.991, -- [20]
				1138225.179, -- [21]
				1138225.524, -- [22]
				1138225.727, -- [23]
				1138226.119, -- [24]
				1138226.119, -- [25]
				1138226.519, -- [26]
				1138226.678, -- [27]
				1138227.185, -- [28]
				1138227.56, -- [29]
				1138227.769, -- [30]
				1138227.769, -- [31]
				1138227.945, -- [32]
				1138228.08, -- [33]
				1138228.491, -- [34]
				1138229.112, -- [35]
				1138229.268, -- [36]
				1138229.56, -- [37]
				1138229.56, -- [38]
				1138220.034, -- [39]
				1138220.65, -- [40]
				1138220.82, -- [41]
				1138221.021, -- [42]
				1138221.201, -- [43]
				1138221.201, -- [44]
				1138221.404, -- [45]
				1138221.404, -- [46]
				1138221.592, -- [47]
				1138221.592, -- [48]
				1138221.901, -- [49]
				1138222.088, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["Attacks"] = {
						["Conflagration"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Horseman's Whirl"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 102,
									["min"] = 102,
									["count"] = 1,
									["amount"] = 102,
								},
							},
							["count"] = 1,
							["amount"] = 102,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Absorb"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2268,
									["min"] = 1016,
									["count"] = 5,
									["amount"] = 8999,
								},
							},
							["count"] = 5,
							["amount"] = 8999,
						},
					},
					["DamagedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
						["Teebz"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["ElementDone"] = {
						["Physical"] = 9101,
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 21,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 12,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 27,
						},
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 16,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 48,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 22,
								},
								["Immune"] = {
									["count"] = 37,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 84,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 18,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 39,
						},
					},
					["DamageTaken"] = 417002,
					["ElementDoneAbsorb"] = {
						["Melee"] = 2535,
						["Fire"] = 1358,
					},
					["PartialResist"] = {
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["PartialAbsorb"] = {
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 36.45,
					["WhoDamaged"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Thrug"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
						["Vrael"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 7932,
						["Melee"] = 40705,
						["Fire"] = 272281,
						["Physical"] = 83950,
						["Frost"] = 12134,
					},
					["TimeDamage"] = 36.45,
					["Damage"] = 9101,
				},
				["LastFightData"] = {
					["Attacks"] = {
						["Conflagration"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Horseman's Whirl"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 102,
									["min"] = 102,
									["count"] = 1,
									["amount"] = 102,
								},
							},
							["count"] = 1,
							["amount"] = 102,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Absorb"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2268,
									["min"] = 1016,
									["count"] = 5,
									["amount"] = 8999,
								},
							},
							["count"] = 5,
							["amount"] = 8999,
						},
					},
					["DamagedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
						["Teebz"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["ElementDone"] = {
						["Physical"] = 9101,
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 21,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 12,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 27,
						},
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 16,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 48,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 22,
								},
								["Immune"] = {
									["count"] = 37,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 84,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 18,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 39,
						},
					},
					["DamageTaken"] = 417002,
					["ElementDoneAbsorb"] = {
						["Melee"] = 2535,
						["Fire"] = 1358,
					},
					["PartialResist"] = {
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["PartialAbsorb"] = {
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 36.45,
					["WhoDamaged"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Thrug"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
						["Vrael"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 7932,
						["Melee"] = 40705,
						["Fire"] = 272281,
						["Physical"] = 83950,
						["Frost"] = 12134,
					},
					["TimeDamage"] = 36.45,
					["Damage"] = 9101,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["Attacks"] = {
						["Conflagration"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Horseman's Whirl"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 102,
									["min"] = 102,
									["count"] = 1,
									["amount"] = 102,
								},
							},
							["count"] = 1,
							["amount"] = 102,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Absorb"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2268,
									["min"] = 1016,
									["count"] = 5,
									["amount"] = 8999,
								},
							},
							["count"] = 5,
							["amount"] = 8999,
						},
					},
					["DamagedWho"] = {
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 4457,
								},
							},
							["amount"] = 4457,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
						["Teebz"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["ElementDone"] = {
						["Physical"] = 9101,
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 21,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 12,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 27,
						},
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 16,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 48,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 22,
								},
								["Immune"] = {
									["count"] = 37,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 84,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 18,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 39,
						},
					},
					["DamageTaken"] = 417002,
					["ElementDoneAbsorb"] = {
						["Melee"] = 2535,
						["Fire"] = 1358,
					},
					["PartialResist"] = {
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 26.33,
								},
								["Horseman's Cleave"] = {
									["count"] = 2.25,
								},
							},
							["amount"] = 28.58,
						},
						["Thrug"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Argussg"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Vrael"] = {
							["Details"] = {
								["Conflagration"] = {
									["count"] = 0.87,
								},
							},
							["amount"] = 0.87,
						},
					},
					["PartialAbsorb"] = {
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Holy Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Execute"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Demoralizing Shout"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heroic Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rend"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Blood Plague"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
							},
							["count"] = 25,
							["amount"] = 0,
						},
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Charge Stun"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Whirlwind"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 36.45,
					["WhoDamaged"] = {
						["Teebz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Thrug"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
						["Argussg"] = {
							["Details"] = {
								["Bloodthirst"] = {
									["count"] = 4844,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1857,
								},
								["Melee"] = {
									["count"] = 7009,
								},
								["Whirlwind"] = {
									["count"] = 2253,
								},
								["Rend (DoT)"] = {
									["count"] = 1585,
								},
								["Heroic Strike"] = {
									["count"] = 3276,
								},
							},
							["amount"] = 20824,
						},
						["Mirror Image <Vrael>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
						["Vrael"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 7932,
						["Melee"] = 40705,
						["Fire"] = 272281,
						["Physical"] = 83950,
						["Frost"] = 12134,
					},
					["TimeDamage"] = 36.45,
					["Damage"] = 9101,
				},
			},
			["UnitLockout"] = 1604179444,
			["LastActive"] = 1604179447,
		},
		["Baldrdove"] = {
			["GUID"] = "0x070000000058AA39",
			["LastEventHealth"] = {
				"22490 (100%)", -- [1]
				"22490 (100%)", -- [2]
				"22490 (100%)", -- [3]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"HEAL", -- [2]
				"HEAL", -- [3]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					0, -- [1]
				},
				["Overhealing"] = {
					3045, -- [1]
				},
				["ActiveTime"] = {
					3.5, -- [1]
				},
				["Healing"] = {
					487, -- [1]
				},
				["TimeDamage"] = {
					3.5, -- [1]
				},
			},
			["enClass"] = "PRIEST",
			["unit"] = "Baldrdove",
			["level"] = 80,
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[3] = 7.981325033348155,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["TimeHeal"] = 1604179446,
				["Overhealing"] = 1604179446,
				["ActiveTime"] = 1604179446,
				["OVERALL"] = 1604179446,
				["Healing"] = 1604179446,
				["TimeDamage"] = 1604179446,
			},
			["Owner"] = false,
			["LastAbility"] = 1138229.268,
			["NextEventNum"] = 4,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
			},
			["LastEvents"] = {
				"Baldrdove Holy Nova Headless Horseman Immune (Holy)", -- [1]
				"Baldrdove Holy Nova Teebz Hit +1737 (1250 overheal)", -- [2]
				"Baldrdove Holy Nova Baldrdove Hit +1795 (1795 overheal)", -- [3]
			},
			["Name"] = "Baldrdove",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
			},
			["LastEventTimes"] = {
				1138229.268, -- [1]
				1138229.268, -- [2]
				1138229.268, -- [3]
			},
			["Fights"] = {
				["Fight1"] = {
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1795,
									["min"] = 1250,
									["count"] = 2,
									["amount"] = 3045,
								},
							},
							["count"] = 2,
							["amount"] = 3045,
						},
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["Overhealing"] = 3045,
					["Attacks"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 487,
									["min"] = 487,
									["count"] = 1,
									["amount"] = 487,
								},
							},
							["count"] = 1,
							["amount"] = 487,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Healing"] = 487,
					["TimeHeal"] = 0,
					["ActiveTime"] = 3.5,
				},
				["LastFightData"] = {
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1795,
									["min"] = 1250,
									["count"] = 2,
									["amount"] = 3045,
								},
							},
							["count"] = 2,
							["amount"] = 3045,
						},
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["Overhealing"] = 3045,
					["Attacks"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 487,
									["min"] = 487,
									["count"] = 1,
									["amount"] = 487,
								},
							},
							["count"] = 1,
							["amount"] = 487,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Healing"] = 487,
					["TimeHeal"] = 0,
					["ActiveTime"] = 3.5,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1795,
									["min"] = 1250,
									["count"] = 2,
									["amount"] = 3045,
								},
							},
							["count"] = 2,
							["amount"] = 3045,
						},
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["Overhealing"] = 3045,
					["Attacks"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Holy Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 487,
									["min"] = 487,
									["count"] = 1,
									["amount"] = 487,
								},
							},
							["count"] = 1,
							["amount"] = 487,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Healing"] = 487,
					["TimeHeal"] = 0,
					["ActiveTime"] = 3.5,
				},
			},
			["UnitLockout"] = 1604179446,
			["LastActive"] = 1604179446,
		},
		["Vrael"] = {
			["GUID"] = "0x070000000000421C",
			["LastEventHealth"] = {
				"25927 (95%)", -- [1]
				"25927 (95%)", -- [2]
				"25927 (95%)", -- [3]
				"25930 (95%)", -- [4]
				"25932 (95%)", -- [5]
				"25932 (95%)", -- [6]
				"25932 (95%)", -- [7]
				"25757 (94%)", -- [8]
				"25760 (94%)", -- [9]
				"25762 (94%)", -- [10]
				"25762 (94%)", -- [11]
				"25794 (94%)", -- [12]
				"25794 (94%)", -- [13]
				"25794 (94%)", -- [14]
				"25889 (95%)", -- [15]
				"25891 (95%)", -- [16]
				"25891 (95%)", -- [17]
				"25893 (95%)", -- [18]
				"25895 (95%)", -- [19]
				"25895 (95%)", -- [20]
				"25897 (95%)", -- [21]
				"25897 (95%)", -- [22]
				"25899 (95%)", -- [23]
				"25899 (95%)", -- [24]
				"25902 (95%)", -- [25]
				"25902 (95%)", -- [26]
				"25902 (95%)", -- [27]
				"25904 (95%)", -- [28]
				"25906 (95%)", -- [29]
				"25906 (95%)", -- [30]
				"25908 (95%)", -- [31]
				"25908 (95%)", -- [32]
				"25908 (95%)", -- [33]
				"25910 (95%)", -- [34]
				"25910 (95%)", -- [35]
				"25910 (95%)", -- [36]
				"25910 (95%)", -- [37]
				"25912 (95%)", -- [38]
				"25912 (95%)", -- [39]
				"25915 (95%)", -- [40]
				"25915 (95%)", -- [41]
				"25915 (95%)", -- [42]
				"25919 (95%)", -- [43]
				"25921 (95%)", -- [44]
				"25921 (95%)", -- [45]
				"25921 (95%)", -- [46]
				"25923 (95%)", -- [47]
				"25925 (95%)", -- [48]
				"25925 (95%)", -- [49]
				"25927 (95%)", -- [50]
			},
			["LastAttackedBy"] = "Anguished Dead",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["DOT_Time"] = {
					27, -- [1]
				},
				["ActiveTime"] = {
					63.27, -- [1]
				},
				["TimeDamage"] = {
					63.27, -- [1]
				},
				["ManaGain"] = {
					21899, -- [1]
				},
				["DamageTaken"] = {
					188, -- [1]
				},
				["Damage"] = {
					305756, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "Vrael",
			["LastAbility"] = 1138228.66,
			["LastDamageTaken"] = 96,
			["level"] = 80,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
			},
			["type"] = "Self",
			["FightsSaved"] = 3,
			["GuardianReverseGUIDs"] = {
				["Mirror Image"] = {
					["LatestGuardian"] = 2,
					["GUIDs"] = {
						"0xF1300079F000008D", -- [1]
						"0xF1300079F000008E", -- [2]
						[0] = "0xF1300079F000008C",
					},
				},
			},
			["TimeLast"] = {
				["DOT_Time"] = 1604179440,
				["ManaGain"] = 1604179463,
				["ActiveTime"] = 1604179446,
				["TimeDamage"] = 1604179446,
				["OVERALL"] = 1604179463,
				["DamageTaken"] = 1604179384,
				["Damage"] = 1604179446,
			},
			["Owner"] = false,
			["Pet"] = {
				"Mirror Image <Vrael>", -- [1]
			},
			["NextEventNum"] = 8,
			["LastEventHealthNum"] = {
				95.3268622692845, -- [1]
				95.3268622692845, -- [2]
				95.3268622692845, -- [3]
				95.33789249209501, -- [4]
				95.34524597396867, -- [5]
				95.34524597396867, -- [6]
				95.34524597396867, -- [7]
				94.70181631002279, -- [8]
				94.7128465328333, -- [9]
				94.72020001470696, -- [10]
				94.72020001470696, -- [11]
				94.83785572468564, -- [12]
				94.83785572468564, -- [13]
				94.83785572468564, -- [14]
				95.18714611368483, -- [15]
				95.1944995955585, -- [16]
				95.1944995955585, -- [17]
				95.20185307743216, -- [18]
				95.20920655930583, -- [19]
				95.20920655930583, -- [20]
				95.21656004117951, -- [21]
				95.21656004117951, -- [22]
				95.22391352305317, -- [23]
				95.22391352305317, -- [24]
				95.23494374586366, -- [25]
				95.23494374586366, -- [26]
				95.23494374586366, -- [27]
				95.24229722773734, -- [28]
				95.249650709611, -- [29]
				95.249650709611, -- [30]
				95.25700419148467, -- [31]
				95.25700419148467, -- [32]
				95.25700419148467, -- [33]
				95.26435767335833, -- [34]
				95.26435767335833, -- [35]
				95.26435767335833, -- [36]
				95.26435767335833, -- [37]
				95.271711155232, -- [38]
				95.271711155232, -- [39]
				95.2827413780425, -- [40]
				95.2827413780425, -- [41]
				95.2827413780425, -- [42]
				95.29744834178983, -- [43]
				95.30480182366351, -- [44]
				95.30480182366351, -- [45]
				95.30480182366351, -- [46]
				95.31215530553718, -- [47]
				95.31950878741084, -- [48]
				95.31950878741084, -- [49]
				95.3268622692845, -- [50]
			},
			["LastEvents"] = {
				"Vrael Pyroblast Headless Horseman Crit -20691 (Fire)", -- [1]
				"Vrael Molten Armor Pulsing Pumpkin Hit -202 (Fire)", -- [2]
				"Pulsing Pumpkin Melee Vrael Absorb (142 Absorbed)", -- [3]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [4]
				"Vrael Pyroblast Headless Horseman Immune (Fire)", -- [5]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [6]
				"Vrael Scorch Pulsing Pumpkin Hit -2424 (Fire)", -- [7]
				"Vrael Ice Lance Anguished Dead Hit -843 (Frost)", -- [8]
				"Vrael Ice Lance Anguished Dead Hit -841 (Frost)", -- [9]
				"Vrael Ice Lance Anguished Dead Crit -1537 (Frost)", -- [10]
				"Vrael Ice Lance Anguished Dead Hit -977 (Frost)", -- [11]
				"Vrael Blizzard Unfettered Spirit Hit -1013 (Frost)", -- [12]
				"Vrael Blizzard Unfettered Spirit Hit -1013 (Frost)", -- [13]
				"Vrael Blizzard Unfettered Spirit Hit -1013 (Frost)", -- [14]
				"Vrael Scorch Headless Horseman Crit -6341 (Fire)", -- [15]
				"Vrael Scorch Headless Horseman Crit -7625 (Fire)", -- [16]
				"Vrael Pyroblast Headless Horseman Hit -11575 (Fire)", -- [17]
				"Vrael Ignite (DoT) Headless Horseman Tick -2793 (Fire)", -- [18]
				"Vrael Fireball Headless Horseman Crit -21017 (Fire)", -- [19]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1655 (Fire)", -- [20]
				"Vrael Fireball Headless Horseman Crit -20317 (Fire)", -- [21]
				"Vrael Pyroblast Headless Horseman Crit -23192 (Fire)", -- [22]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [23]
				"Vrael Pyroblast Headless Horseman Immune (Fire)", -- [24]
				"Vrael Scorch Head of the Horseman Crit -6205 (Fire)", -- [25]
				"Vrael Fire Blast Head of the Horseman Hit -4401 (Fire)", -- [26]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [27]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1753 (Fire)", -- [28]
				"Vrael Fireball Headless Horseman Crit -18446 (Fire)", -- [29]
				"Vrael Pyroblast Headless Horseman Crit -20432 (Fire)", -- [30]
				"Vrael Ignite (DoT) Headless Horseman Tick -7775 (Fire)", -- [31]
				"Vrael Fireball Headless Horseman Hit -8637 (Fire)", -- [32]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1565 (Fire)", -- [33]
				"Vrael Ignite (DoT) Headless Horseman Tick -7775 (Fire)", -- [34]
				"Vrael Fire Blast Headless Horseman Crit -9002 (Fire)", -- [35]
				"Vrael Fireball Headless Horseman Hit -12211 (Fire)", -- [36]
				"Headless Horseman Conflagration Vrael Absorb (1358 Absorbed) (Fire)", -- [37]
				"Vrael Pyroblast Headless Horseman Immune (Fire)", -- [38]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [39]
				"Vrael Ignite Headless Horseman Immune (Fire)", -- [40]
				"Vrael Scorch Head of the Horseman Crit -6581 (Fire)", -- [41]
				"Vrael Pyroblast Headless Horseman Immune (Fire)", -- [42]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1565 (Fire)", -- [43]
				"Vrael Scorch Headless Horseman Crit -5594 (Fire)", -- [44]
				"Vrael Fire Blast Headless Horseman Crit -7131 (Fire)", -- [45]
				"Vrael Pyroblast Headless Horseman Crit -18512 (Fire)", -- [46]
				"Vrael Ignite (DoT) Headless Horseman Tick -6246 (Fire)", -- [47]
				"Vrael Fireball Headless Horseman Crit -16578 (Fire)", -- [48]
				"Vrael Pyroblast (DoT) Headless Horseman Tick -1419 (Fire)", -- [49]
				"Vrael Fireball Headless Horseman Hit -10331 (Fire)", -- [50]
			},
			["Name"] = "Vrael",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138224.436, -- [1]
				1138225.38, -- [2]
				1138225.38, -- [3]
				1138226.519, -- [4]
				1138227.56, -- [5]
				1138228.491, -- [6]
				1138228.66, -- [7]
				1138167.266, -- [8]
				1138169.117, -- [9]
				1138170.317, -- [10]
				1138171.236, -- [11]
				1138181.169, -- [12]
				1138181.171, -- [13]
				1138181.172, -- [14]
				1138189.053, -- [15]
				1138190.249, -- [16]
				1138191.094, -- [17]
				1138192.351, -- [18]
				1138193.884, -- [19]
				1138194.159, -- [20]
				1138195.504, -- [21]
				1138195.829, -- [22]
				1138197.838, -- [23]
				1138198.974, -- [24]
				1138199.476, -- [25]
				1138199.818, -- [26]
				1138199.949, -- [27]
				1138201.859, -- [28]
				1138203.948, -- [29]
				1138204.067, -- [30]
				1138206.19, -- [31]
				1138206.793, -- [32]
				1138207.22, -- [33]
				1138208.131, -- [34]
				1138208.443, -- [35]
				1138208.703, -- [36]
				1138209.32, -- [37]
				1138210.071, -- [38]
				1138210.493, -- [39]
				1138212.515, -- [40]
				1138212.837, -- [41]
				1138213.152, -- [42]
				1138216.159, -- [43]
				1138217.512, -- [44]
				1138217.818, -- [45]
				1138219.302, -- [46]
				1138221.404, -- [47]
				1138222.483, -- [48]
				1138222.484, -- [49]
				1138224.216, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 96,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 5,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 96,
					},
					["DOT_Time"] = 0,
					["Damage"] = 5425,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 5058,
						["Fire"] = 367,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Ice Lance"] = {
									["count"] = 5058,
								},
								["Molten Armor"] = {
									["count"] = 367,
								},
								["Scorch"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5425,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 96,
								},
							},
							["amount"] = 96,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Vrael"] = {
							["Details"] = {
								["Master of Elements"] = {
									["count"] = 67,
								},
							},
							["amount"] = 67,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Master of Elements"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 67,
								},
							},
							["amount"] = 67,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Ice Lance"] = {
									["count"] = 7.930000000000001,
								},
								["Molten Armor"] = {
									["count"] = 0.63,
								},
								["Scorch"] = {
									["count"] = 0,
								},
							},
							["amount"] = 8.560000000000001,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 8.560000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Ice Lance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1537,
									["min"] = 1537,
									["count"] = 1,
									["amount"] = 1537,
								},
								["Hit"] = {
									["max"] = 977,
									["min"] = 841,
									["count"] = 4,
									["amount"] = 3521,
								},
							},
							["count"] = 5,
							["amount"] = 5058,
						},
						["Molten Armor"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 367,
									["min"] = 367,
									["count"] = 1,
									["amount"] = 367,
								},
							},
							["count"] = 1,
							["amount"] = 367,
						},
						["Scorch"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 8.560000000000001,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Ice Lance"] = {
									["count"] = 7.930000000000001,
								},
								["Molten Armor"] = {
									["count"] = 0.63,
								},
								["Scorch"] = {
									["count"] = 0,
								},
							},
							["amount"] = 8.560000000000001,
						},
					},
					["ManaGain"] = 67,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Vrael"] = {
							["Details"] = {
								["Evocation"] = {
									["count"] = 18728,
								},
							},
							["amount"] = 18728,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Evocation"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 18728,
								},
							},
							["amount"] = 18728,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 18728,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Scorch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2416,
									["min"] = 2416,
									["count"] = 1,
									["amount"] = 2416,
								},
							},
							["count"] = 1,
							["amount"] = 2416,
						},
						["Molten Armor"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 411,
									["min"] = 411,
									["count"] = 1,
									["amount"] = 411,
								},
							},
							["count"] = 1,
							["amount"] = 411,
						},
					},
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 3.5,
								},
								["Molten Armor"] = {
									["count"] = 1.14,
								},
							},
							["amount"] = 4.64,
						},
					},
					["DamageTaken"] = 92,
					["WhoDamaged"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 92,
								},
							},
							["amount"] = 92,
						},
					},
					["ElementDone"] = {
						["Fire"] = 2827,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 2416,
								},
								["Molten Armor"] = {
									["count"] = 411,
								},
							},
							["amount"] = 2827,
						},
					},
					["TimeDamage"] = 4.64,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 3.5,
								},
								["Molten Armor"] = {
									["count"] = 1.14,
								},
							},
							["amount"] = 4.64,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 92,
					},
					["ActiveTime"] = 4.64,
					["Damage"] = 2827,
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 41,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 142,
						["Fire"] = 1358,
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 27,
					["Damage"] = 289991,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 289991,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["Conflagration"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1358,
									["min"] = 1358,
									["count"] = 1,
									["amount"] = 1358,
								},
							},
							["count"] = 1,
							["amount"] = 1358,
						},
						["Melee"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 142,
									["min"] = 142,
									["count"] = 1,
									["amount"] = 142,
								},
							},
							["count"] = 1,
							["amount"] = 142,
						},
					},
					["DamagedWho"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 2424,
								},
								["Molten Armor"] = {
									["count"] = 202,
								},
							},
							["amount"] = 2626,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 12786,
								},
								["Fire Blast"] = {
									["count"] = 4401,
								},
							},
							["amount"] = 17187,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Conflagration"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Vrael"] = {
							["Details"] = {
								["Empowered Fire"] = {
									["count"] = 260,
								},
								["Master of Elements"] = {
									["count"] = 2766,
								},
							},
							["amount"] = 3026,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Empowered Fire"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 260,
								},
							},
							["amount"] = 260,
						},
						["Master of Elements"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 2766,
								},
							},
							["amount"] = 2766,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 43.07,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 21017,
									["min"] = 16578,
									["count"] = 4,
									["amount"] = 76358,
								},
								["Hit"] = {
									["max"] = 12211,
									["min"] = 8637,
									["count"] = 3,
									["amount"] = 31179,
								},
							},
							["count"] = 7,
							["amount"] = 107537,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1753,
									["min"] = 1419,
									["count"] = 5,
									["amount"] = 7957,
								},
							},
							["count"] = 5,
							["amount"] = 7957,
						},
						["Blizzard"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Molten Armor"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 202,
									["min"] = 202,
									["count"] = 1,
									["amount"] = 202,
								},
							},
							["count"] = 1,
							["amount"] = 202,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9002,
									["min"] = 7131,
									["count"] = 2,
									["amount"] = 16133,
								},
								["Hit"] = {
									["max"] = 4401,
									["min"] = 4401,
									["count"] = 1,
									["amount"] = 4401,
								},
							},
							["count"] = 3,
							["amount"] = 20534,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 23192,
									["min"] = 18512,
									["count"] = 4,
									["amount"] = 82827,
								},
								["Hit"] = {
									["max"] = 11575,
									["min"] = 11575,
									["count"] = 1,
									["amount"] = 11575,
								},
							},
							["count"] = 9,
							["amount"] = 94402,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7625,
									["min"] = 5594,
									["count"] = 5,
									["amount"] = 32346,
								},
								["Hit"] = {
									["max"] = 2424,
									["min"] = 2424,
									["count"] = 1,
									["amount"] = 2424,
								},
							},
							["count"] = 6,
							["amount"] = 34770,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 7775,
									["min"] = 2793,
									["count"] = 4,
									["amount"] = 24589,
								},
							},
							["count"] = 4,
							["amount"] = 24589,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 43.07,
					["TimeDamaging"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 3026,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 41,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 142,
						["Fire"] = 1358,
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 27,
					["Damage"] = 289991,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 289991,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["Conflagration"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1358,
									["min"] = 1358,
									["count"] = 1,
									["amount"] = 1358,
								},
							},
							["count"] = 1,
							["amount"] = 1358,
						},
						["Melee"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 142,
									["min"] = 142,
									["count"] = 1,
									["amount"] = 142,
								},
							},
							["count"] = 1,
							["amount"] = 142,
						},
					},
					["DamagedWho"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 2424,
								},
								["Molten Armor"] = {
									["count"] = 202,
								},
							},
							["amount"] = 2626,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 12786,
								},
								["Fire Blast"] = {
									["count"] = 4401,
								},
							},
							["amount"] = 17187,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Conflagration"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Vrael"] = {
							["Details"] = {
								["Empowered Fire"] = {
									["count"] = 260,
								},
								["Master of Elements"] = {
									["count"] = 2766,
								},
							},
							["amount"] = 3026,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Empowered Fire"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 260,
								},
							},
							["amount"] = 260,
						},
						["Master of Elements"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 2766,
								},
							},
							["amount"] = 2766,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 43.07,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 21017,
									["min"] = 16578,
									["count"] = 4,
									["amount"] = 76358,
								},
								["Hit"] = {
									["max"] = 12211,
									["min"] = 8637,
									["count"] = 3,
									["amount"] = 31179,
								},
							},
							["count"] = 7,
							["amount"] = 107537,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1753,
									["min"] = 1419,
									["count"] = 5,
									["amount"] = 7957,
								},
							},
							["count"] = 5,
							["amount"] = 7957,
						},
						["Blizzard"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Molten Armor"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 202,
									["min"] = 202,
									["count"] = 1,
									["amount"] = 202,
								},
							},
							["count"] = 1,
							["amount"] = 202,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9002,
									["min"] = 7131,
									["count"] = 2,
									["amount"] = 16133,
								},
								["Hit"] = {
									["max"] = 4401,
									["min"] = 4401,
									["count"] = 1,
									["amount"] = 4401,
								},
							},
							["count"] = 3,
							["amount"] = 20534,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 23192,
									["min"] = 18512,
									["count"] = 4,
									["amount"] = 82827,
								},
								["Hit"] = {
									["max"] = 11575,
									["min"] = 11575,
									["count"] = 1,
									["amount"] = 11575,
								},
							},
							["count"] = 9,
							["amount"] = 94402,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7625,
									["min"] = 5594,
									["count"] = 5,
									["amount"] = 32346,
								},
								["Hit"] = {
									["max"] = 2424,
									["min"] = 2424,
									["count"] = 1,
									["amount"] = 2424,
								},
							},
							["count"] = 6,
							["amount"] = 34770,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 7775,
									["min"] = 2793,
									["count"] = 4,
									["amount"] = 24589,
								},
							},
							["count"] = 4,
							["amount"] = 24589,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 43.07,
					["TimeDamaging"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 3026,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 7,
								},
								["Molten Armor"] = {
									["count"] = 1.77,
								},
								["Ice Lance"] = {
									["count"] = 7.930000000000001,
								},
							},
							["amount"] = 16.7,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
					},
					["DamageTaken"] = 188,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Conflagration"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Master of Elements"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 2911,
								},
							},
							["amount"] = 2911,
						},
						["Evocation"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 18728,
								},
							},
							["amount"] = 18728,
						},
						["Empowered Fire"] = {
							["Details"] = {
								["Vrael"] = {
									["count"] = 260,
								},
							},
							["amount"] = 260,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 142,
									["min"] = 142,
									["count"] = 1,
									["amount"] = 142,
								},
							},
							["count"] = 3,
							["amount"] = 142,
						},
						["Conflagration"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1358,
									["min"] = 1358,
									["count"] = 1,
									["amount"] = 1358,
								},
							},
							["count"] = 1,
							["amount"] = 1358,
						},
					},
					["ActiveTime"] = 63.27,
					["ElementTaken"] = {
						["Melee"] = 188,
					},
					["DOT_Time"] = 27,
					["Damage"] = 305756,
					["ElementTakenAbsorb"] = {
						["Melee"] = 142,
						["Fire"] = 1358,
					},
					["ManaGainedFrom"] = {
						["Vrael"] = {
							["Details"] = {
								["Master of Elements"] = {
									["count"] = 2911,
								},
								["Evocation"] = {
									["count"] = 18728,
								},
								["Empowered Fire"] = {
									["count"] = 260,
								},
							},
							["amount"] = 21899,
						},
					},
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 21017,
									["min"] = 16578,
									["count"] = 4,
									["amount"] = 76358,
								},
								["Hit"] = {
									["max"] = 12211,
									["min"] = 8637,
									["count"] = 3,
									["amount"] = 31179,
								},
							},
							["count"] = 7,
							["amount"] = 107537,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1753,
									["min"] = 1419,
									["count"] = 5,
									["amount"] = 7957,
								},
							},
							["count"] = 5,
							["amount"] = 7957,
						},
						["Blizzard"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1013,
									["min"] = 1013,
									["count"] = 3,
									["amount"] = 3039,
								},
							},
							["count"] = 3,
							["amount"] = 3039,
						},
						["Molten Armor"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 411,
									["min"] = 367,
									["count"] = 2,
									["amount"] = 778,
								},
								["Hit"] = {
									["max"] = 202,
									["min"] = 202,
									["count"] = 1,
									["amount"] = 202,
								},
							},
							["count"] = 3,
							["amount"] = 980,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9002,
									["min"] = 7131,
									["count"] = 2,
									["amount"] = 16133,
								},
								["Hit"] = {
									["max"] = 4401,
									["min"] = 4401,
									["count"] = 1,
									["amount"] = 4401,
								},
							},
							["count"] = 3,
							["amount"] = 20534,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 23192,
									["min"] = 18512,
									["count"] = 4,
									["amount"] = 82827,
								},
								["Hit"] = {
									["max"] = 11575,
									["min"] = 11575,
									["count"] = 1,
									["amount"] = 11575,
								},
							},
							["count"] = 9,
							["amount"] = 94402,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 7775,
									["min"] = 2793,
									["count"] = 4,
									["amount"] = 24589,
								},
							},
							["count"] = 4,
							["amount"] = 24589,
						},
						["Scorch"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7625,
									["min"] = 4474,
									["count"] = 6,
									["amount"] = 36820,
								},
								["Hit"] = {
									["max"] = 2424,
									["min"] = 2416,
									["count"] = 2,
									["amount"] = 4840,
								},
							},
							["count"] = 8,
							["amount"] = 41660,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Ice Lance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1537,
									["min"] = 1537,
									["count"] = 1,
									["amount"] = 1537,
								},
								["Hit"] = {
									["max"] = 977,
									["min"] = 841,
									["count"] = 4,
									["amount"] = 3521,
								},
							},
							["count"] = 5,
							["amount"] = 5058,
						},
					},
					["ElementDone"] = {
						["Frost"] = 8097,
						["Fire"] = 297659,
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 107537,
								},
								["Pyroblast"] = {
									["count"] = 94402,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7957,
								},
								["Ignite (DoT)"] = {
									["count"] = 24589,
								},
								["Scorch"] = {
									["count"] = 19560,
								},
								["Fire Blast"] = {
									["count"] = 16133,
								},
							},
							["amount"] = 270178,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 3039,
								},
							},
							["amount"] = 3039,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 6890,
								},
								["Molten Armor"] = {
									["count"] = 778,
								},
								["Ice Lance"] = {
									["count"] = 5058,
								},
							},
							["amount"] = 12726,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 2424,
								},
								["Molten Armor"] = {
									["count"] = 202,
								},
							},
							["amount"] = 2626,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 12786,
								},
								["Fire Blast"] = {
									["count"] = 4401,
								},
							},
							["amount"] = 17187,
						},
					},
					["TimeDamage"] = 63.27,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.629999999999999,
								},
								["Pyroblast"] = {
									["count"] = 6.84,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.619999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 6.390000000000001,
								},
								["Scorch"] = {
									["count"] = 6.050000000000001,
								},
								["Ignite"] = {
									["count"] = 6.65,
								},
								["Fire Blast"] = {
									["count"] = 0.62,
								},
							},
							["amount"] = 40.8,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Blizzard"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 7,
								},
								["Molten Armor"] = {
									["count"] = 1.77,
								},
								["Ice Lance"] = {
									["count"] = 7.930000000000001,
								},
							},
							["amount"] = 16.7,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.17,
								},
								["Molten Armor"] = {
									["count"] = 0.94,
								},
							},
							["amount"] = 1.11,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 0.8200000000000001,
								},
								["Fire Blast"] = {
									["count"] = 0.34,
								},
							},
							["amount"] = 1.16,
						},
					},
					["ManaGain"] = 21899,
					["WhoDamaged"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 188,
								},
							},
							["amount"] = 188,
						},
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 18,
								},
								["Hit"] = {
									["count"] = 8,
								},
							},
							["amount"] = 45,
						},
					},
				},
			},
			["UnitLockout"] = 1604179372,
			["LastActive"] = 1604179463,
		},
		["Mirror Image <Vrael>"] = {
			["GUID"] = "0xF1300079F000008D",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					26.95000000000001, -- [1]
				},
				["Damage"] = {
					8655, -- [1]
				},
				["DamageTaken"] = {
					102, -- [1]
				},
				["ActiveTime"] = {
					26.95000000000001, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 102,
			["level"] = 1,
			["LastDamageAbility"] = "Horseman's Whirl",
			["LastFightIn"] = 2,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["ActiveTime"] = 1604179432,
				["TimeDamage"] = 1604179432,
				["OVERALL"] = 1604179433,
				["DamageTaken"] = 1604179433,
				["Damage"] = 1604179425,
			},
			["Owner"] = "Vrael",
			["LastAbility"] = 1138214.941,
			["NextEventNum"] = 38,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
			},
			["LastEvents"] = {
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -548 (Frost)", -- [1]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -544 (Frost)", -- [2]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -546 (Frost)", -- [3]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -332 (Fire)", -- [4]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -325 (Fire)", -- [5]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -332 (Fire)", -- [6]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -543 (Frost)", -- [7]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -544 (Frost)", -- [8]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -547 (Frost)", -- [9]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [10]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [11]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [12]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [13]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [14]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [15]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [16]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [17]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [18]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -548 (Frost)", -- [19]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -544 (Frost)", -- [20]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -549 (Frost)", -- [21]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -374 (Fire)", -- [22]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -372 (Fire)", -- [23]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -548 (Frost)", -- [24]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Hit -368 (Fire)", -- [25]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -543 (Frost)", -- [26]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Hit -548 (Frost)", -- [27]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [28]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [29]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [30]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [31]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [32]
				"Mirror Image <Vrael> Fire Blast Headless Horseman Immune (Fire)", -- [33]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [34]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [35]
				"Mirror Image <Vrael> Frostbolt Headless Horseman Immune (Frost)", -- [36]
				"Headless Horseman Horseman's Whirl Mirror Image <Vrael> Hit -102 (Physical)", -- [37]
			},
			["Name"] = "Mirror Image",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				true, -- [37]
			},
			["LastEventTimes"] = {
				1138191.494, -- [1]
				1138191.638, -- [2]
				1138191.638, -- [3]
				1138194.63, -- [4]
				1138194.63, -- [5]
				1138194.631, -- [6]
				1138194.918, -- [7]
				1138195.052, -- [8]
				1138195.052, -- [9]
				1138198.002, -- [10]
				1138198.2, -- [11]
				1138198.207, -- [12]
				1138200.945, -- [13]
				1138200.946, -- [14]
				1138200.947, -- [15]
				1138201.395, -- [16]
				1138201.522, -- [17]
				1138201.522, -- [18]
				1138204.562, -- [19]
				1138204.748, -- [20]
				1138204.748, -- [21]
				1138207.973, -- [22]
				1138207.974, -- [23]
				1138207.974, -- [24]
				1138207.974, -- [25]
				1138208.249, -- [26]
				1138208.249, -- [27]
				1138211.281, -- [28]
				1138211.399, -- [29]
				1138211.407, -- [30]
				1138214.427, -- [31]
				1138214.428, -- [32]
				1138214.429, -- [33]
				1138214.809, -- [34]
				1138214.914, -- [35]
				1138214.941, -- [36]
				1138215.695, -- [37]
			},
			["Fights"] = {
				["Fight1"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 374,
									["min"] = 325,
									["count"] = 6,
									["amount"] = 2103,
								},
							},
							["count"] = 12,
							["amount"] = 2103,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 549,
									["min"] = 543,
									["count"] = 12,
									["amount"] = 6552,
								},
							},
							["count"] = 24,
							["amount"] = 6552,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["DamageTaken"] = 102,
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
					},
					["ElementDone"] = {
						["Fire"] = 2103,
						["Frost"] = 6552,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 12,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
					},
					["TimeDamage"] = 26.95000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 102,
					},
					["ActiveTime"] = 26.95000000000001,
					["Damage"] = 8655,
				},
				["LastFightData"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 374,
									["min"] = 325,
									["count"] = 6,
									["amount"] = 2103,
								},
							},
							["count"] = 12,
							["amount"] = 2103,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 549,
									["min"] = 543,
									["count"] = 12,
									["amount"] = 6552,
								},
							},
							["count"] = 24,
							["amount"] = 6552,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["DamageTaken"] = 102,
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
					},
					["ElementDone"] = {
						["Fire"] = 2103,
						["Frost"] = 6552,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 12,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
					},
					["TimeDamage"] = 26.95000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 102,
					},
					["ActiveTime"] = 26.95000000000001,
					["Damage"] = 8655,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Horseman's Whirl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 374,
									["min"] = 325,
									["count"] = 6,
									["amount"] = 2103,
								},
							},
							["count"] = 12,
							["amount"] = 2103,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 549,
									["min"] = 543,
									["count"] = 12,
									["amount"] = 6552,
								},
							},
							["count"] = 24,
							["amount"] = 6552,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["DamageTaken"] = 102,
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Whirl"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
					},
					["ElementDone"] = {
						["Fire"] = 2103,
						["Frost"] = 6552,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 12,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 2103,
								},
								["Frostbolt"] = {
									["count"] = 6552,
								},
							},
							["amount"] = 8655,
						},
					},
					["TimeDamage"] = 26.95000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 11.97,
								},
								["Frostbolt"] = {
									["count"] = 14.98,
								},
							},
							["amount"] = 26.95000000000001,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 102,
					},
					["ActiveTime"] = 26.95000000000001,
					["Damage"] = 8655,
				},
			},
			["UnitLockout"] = 1604179433,
			["LastActive"] = 1604179433,
		},
		["Teebz"] = {
			["GUID"] = "0x070000000028E90D",
			["LastEventHealth"] = {
				"55212 (99%)", -- [1]
				"55212 (99%)", -- [2]
				"55300 (99%)", -- [3]
				"55300 (99%)", -- [4]
				"55318 (99%)", -- [5]
				"55318 (99%)", -- [6]
				"55318 (99%)", -- [7]
				"55318 (99%)", -- [8]
				"55318 (99%)", -- [9]
				"55318 (99%)", -- [10]
				"55410 (99%)", -- [11]
				"55410 (99%)", -- [12]
				"55448 (99%)", -- [13]
				"55448 (99%)", -- [14]
				"55448 (99%)", -- [15]
				"55448 (99%)", -- [16]
				"55519 (99%)", -- [17]
				"55519 (99%)", -- [18]
				"55519 (99%)", -- [19]
				"55519 (99%)", -- [20]
				"55614 (100%)", -- [21]
				"55614 (100%)", -- [22]
				"55614 (100%)", -- [23]
				"55614 (100%)", -- [24]
				"55614 (100%)", -- [25]
				"55614 (100%)", -- [26]
				"55614 (100%)", -- [27]
				"55614 (100%)", -- [28]
				"55614 (100%)", -- [29]
				"55614 (100%)", -- [30]
				"55614 (100%)", -- [31]
				"55614 (100%)", -- [32]
				"55614 (100%)", -- [33]
				"55614 (100%)", -- [34]
				"55614 (100%)", -- [35]
				"55614 (100%)", -- [36]
				"55614 (100%)", -- [37]
				"55127 (99%)", -- [38]
				"55127 (99%)", -- [39]
				"55127 (99%)", -- [40]
				"55127 (99%)", -- [41]
				"55127 (99%)", -- [42]
				"55127 (99%)", -- [43]
				"55127 (99%)", -- [44]
				"55127 (99%)", -- [45]
				"55127 (99%)", -- [46]
				"55614 (100%)", -- [47]
				"55094 (99%)", -- [48]
				"55112 (99%)", -- [49]
				"55112 (99%)", -- [50]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"HEAL", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"HEAL", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"HEAL", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					12.25, -- [1]
				},
				["Healing"] = {
					1016, -- [1]
				},
				["DamageTaken"] = {
					1016, -- [1]
				},
				["TimeDamage"] = {
					35.82, -- [1]
				},
				["HealingTaken"] = {
					1503, -- [1]
				},
				["HOT_Time"] = {
					51, -- [1]
				},
				["ActiveTime"] = {
					48.06999999999998, -- [1]
				},
				["Overhealing"] = {
					8841, -- [1]
				},
				["RunicPowerGain"] = {
					10, -- [1]
				},
				["DOT_Time"] = {
					36, -- [1]
				},
				["Damage"] = {
					76224, -- [1]
				},
			},
			["enClass"] = "DEATHKNIGHT",
			["unit"] = "Teebz",
			["level"] = 80,
			["LastDamageAbility"] = "Horseman's Cleave",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				0.1798108389973748, -- [1]
				[3] = 0.1582335383176898,
				[17] = 0.1276656956881361,
				[35] = 15.74603517100011,
				[11] = 0.1654259718775848,
				[47] = 3.1233142733844,
				[49] = 0.03236595101952746,
				[21] = 0.3218614018053008,
				[13] = 0.06832811881900242,
				[5] = 0.03236595101952746,
			},
			["type"] = "Grouped",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 1016,
			["TimeLast"] = {
				["TimeHeal"] = 1604179434,
				["OVERALL"] = 1604179446,
				["DamageTaken"] = 1604179413,
				["ActiveTime"] = 1604179446,
				["Overhealing"] = 1604179441,
				["HealingTaken"] = 1604179446,
				["HOT_Time"] = 1604179434,
				["TimeDamage"] = 1604179446,
				["Healing"] = 1604179434,
				["RunicPowerGain"] = 1604179442,
				["DOT_Time"] = 1604179440,
				["Damage"] = 1604179446,
			},
			["Owner"] = false,
			["LastAbility"] = 1138229.112,
			["NextEventNum"] = 48,
			["LastEventHealthNum"] = {
				99.27716042723056, -- [1]
				99.27716042723056, -- [2]
				99.43539396554824, -- [3]
				99.43539396554824, -- [4]
				99.46775991656777, -- [5]
				99.46775991656777, -- [6]
				99.46775991656777, -- [7]
				99.46775991656777, -- [8]
				99.46775991656777, -- [9]
				99.46775991656777, -- [10]
				99.63318588844535, -- [11]
				99.63318588844535, -- [12]
				99.70151400726437, -- [13]
				99.70151400726437, -- [14]
				99.70151400726437, -- [15]
				99.70151400726437, -- [16]
				99.82917970295249, -- [17]
				99.82917970295249, -- [18]
				99.82917970295249, -- [19]
				99.82917970295249, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				99.12432121408278, -- [38]
				99.12432121408278, -- [39]
				99.12432121408278, -- [40]
				99.12432121408278, -- [41]
				99.12432121408278, -- [42]
				99.12432121408278, -- [43]
				99.12432121408278, -- [44]
				99.12432121408278, -- [45]
				99.12432121408278, -- [46]
				100, -- [47]
				99.06498363721366, -- [48]
				99.09734958823317, -- [49]
				99.09734958823317, -- [50]
			},
			["LastEvents"] = {
				"Teebz Blood Presence Teebz Tick +100", -- [1]
				"Teebz Heart Strike Headless Horseman Hit -2401 (Physical)", -- [2]
				"Teebz Blood Presence Teebz Tick +88", -- [3]
				"Teebz Melee Headless Horseman Hit -2109 (Physical)", -- [4]
				"Teebz Blood Presence Teebz Tick +18", -- [5]
				"Teebz Frost Fever (DoT) Headless Horseman Tick -465 (Frost)", -- [6]
				"Headless Horseman Melee Teebz Miss", -- [7]
				"Teebz Death Strike Headless Horseman Immune (Physical)", -- [8]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [9]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [10]
				"Teebz Blood Presence Teebz Tick +92", -- [11]
				"Teebz Melee Head of the Horseman Hit -2213 (Physical)", -- [12]
				"Teebz Blood Presence Teebz Tick +38", -- [13]
				"Teebz Icy Touch Head of the Horseman Hit -925 (Frost)", -- [14]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [15]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [16]
				"Teebz Blood Presence Teebz Tick +71", -- [17]
				"Teebz Death Coil Head of the Horseman Hit -1723 (Shadow)", -- [18]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [19]
				"Headless Horseman Melee Teebz Dodge", -- [20]
				"Teebz Blood Presence Teebz Tick +179 (84 overheal)", -- [21]
				"Teebz Melee Headless Horseman Crit -4284 (Physical)", -- [22]
				"Teebz Icy Touch Headless Horseman Hit -930 (Frost)", -- [23]
				"Teebz Blood Plague (DoT) Headless Horseman Tick -471 (Shadow)", -- [24]
				"Headless Horseman Melee Teebz Absorb (851 Absorbed)", -- [25]
				"Teebz Plague Strike Headless Horseman Hit -1136 (Physical)", -- [26]
				"Teebz Frost Fever (DoT) Headless Horseman Tick -459 (Frost)", -- [27]
				"Teebz Heart Strike Headless Horseman Hit -2255 (Physical)", -- [28]
				"Teebz Rune Strike Headless Horseman Hit -3066 (Physical)", -- [29]
				"Headless Horseman Melee Teebz Absorb (821 Absorbed)", -- [30]
				"Teebz Blood Plague (DoT) Headless Horseman Tick -466 (Shadow)", -- [31]
				"Teebz Heart Strike Headless Horseman Hit -2355 (Physical)", -- [32]
				"Teebz Frost Fever (DoT) Headless Horseman Tick -459 (Frost)", -- [33]
				"Headless Horseman Melee Teebz Parry", -- [34]
				"Teebz Death Strike Teebz Hit +8757 (8757 overheal)", -- [35]
				"Teebz Death Strike Headless Horseman Hit -2068 (Physical)", -- [36]
				"Teebz Melee Headless Horseman Hit -2316 (Physical)", -- [37]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [38]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [39]
				"Teebz Melee Headless Horseman Immune", -- [40]
				"Teebz Blood Plague Headless Horseman Immune (Shadow)", -- [41]
				"Teebz Death and Decay Pulsing Pumpkin Hit -466 (Shadow)", -- [42]
				"Teebz Death and Decay Pulsing Pumpkin Crit -932 (Shadow)", -- [43]
				"Teebz Death and Decay Pulsing Pumpkin Hit -466 (Shadow)", -- [44]
				"Teebz Death and Decay Pulsing Pumpkin Hit -466 (Shadow)", -- [45]
				"Teebz Frost Fever Headless Horseman Immune (Frost)", -- [46]
				"Baldrdove Holy Nova Teebz Hit +1737 (1250 overheal)", -- [47]
				"Headless Horseman Melee Teebz Absorb (863 Absorbed)", -- [48]
				"Teebz Blood Presence Teebz Tick +18", -- [49]
				"Teebz Blood Plague (DoT) Headless Horseman Tick -471 (Shadow)", -- [50]
			},
			["Name"] = "Teebz",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				true, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				true, -- [34]
				true, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138207.09, -- [1]
				1138207.091, -- [2]
				1138208.13, -- [3]
				1138208.13, -- [4]
				1138208.13, -- [5]
				1138208.131, -- [6]
				1138208.447, -- [7]
				1138208.84, -- [8]
				1138209.652, -- [9]
				1138211.052, -- [10]
				1138212.022, -- [11]
				1138212.022, -- [12]
				1138212.354, -- [13]
				1138212.354, -- [14]
				1138212.695, -- [15]
				1138214.117, -- [16]
				1138214.728, -- [17]
				1138214.728, -- [18]
				1138215.694, -- [19]
				1138216.428, -- [20]
				1138216.89, -- [21]
				1138216.89, -- [22]
				1138217.029, -- [23]
				1138218.693, -- [24]
				1138218.693, -- [25]
				1138218.839, -- [26]
				1138220.033, -- [27]
				1138220.65, -- [28]
				1138220.82, -- [29]
				1138221.021, -- [30]
				1138221.901, -- [31]
				1138222.088, -- [32]
				1138223.096, -- [33]
				1138223.317, -- [34]
				1138223.674, -- [35]
				1138223.674, -- [36]
				1138224.036, -- [37]
				1138224.991, -- [38]
				1138226.119, -- [39]
				1138227.769, -- [40]
				1138227.945, -- [41]
				1138227.945, -- [42]
				1138227.946, -- [43]
				1138228.81, -- [44]
				1138228.811, -- [45]
				1138229.112, -- [46]
				1138229.268, -- [47]
				1138206.028, -- [48]
				1138206.793, -- [49]
				1138206.794, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementDone"] = {
						["Melee"] = 5060,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5060,
								},
							},
							["amount"] = 5060,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5060,
									["min"] = 5060,
									["count"] = 1,
									["amount"] = 5060,
								},
							},
							["count"] = 1,
							["amount"] = 5060,
						},
					},
					["ActiveTime"] = 3.5,
					["Damage"] = 5060,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1016,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 51,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 15,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 17,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 26,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 2535,
					},
					["ElementTaken"] = {
						["Physical"] = 1016,
					},
					["DOT_Time"] = 36,
					["Damage"] = 71164,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 12.25,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Tap"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementDone"] = {
						["Physical"] = 36536,
						["Frost"] = 7457,
						["Melee"] = 15186,
						["Shadow"] = 11985,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 863,
									["min"] = 821,
									["count"] = 3,
									["amount"] = 2535,
								},
							},
							["count"] = 11,
							["amount"] = 2535,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 2330,
								},
							},
							["amount"] = 2330,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 1875,
								},
								["Melee"] = {
									["count"] = 2213,
								},
								["Death Coil"] = {
									["count"] = 1723,
								},
							},
							["amount"] = 5811,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8757,
									["min"] = 8757,
									["count"] = 1,
									["amount"] = 8757,
								},
							},
							["count"] = 1,
							["amount"] = 8757,
						},
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 84,
									["min"] = 84,
									["count"] = 1,
									["amount"] = 84,
								},
							},
							["count"] = 1,
							["amount"] = 84,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Blood Tap"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 8841,
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 10,
					["Heals"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 125,
									["min"] = 18,
									["count"] = 17,
									["amount"] = 1016,
								},
							},
							["count"] = 17,
							["amount"] = 1016,
						},
					},
					["WhoHealed"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Baldrdove"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 44.56999999999998,
					["Healing"] = 1016,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4284,
									["min"] = 4284,
									["count"] = 1,
									["amount"] = 4284,
								},
								["Hit"] = {
									["max"] = 2316,
									["min"] = 2099,
									["count"] = 5,
									["amount"] = 10902,
								},
							},
							["count"] = 7,
							["amount"] = 15186,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 932,
									["min"] = 932,
									["count"] = 4,
									["amount"] = 3728,
								},
								["Hit"] = {
									["max"] = 466,
									["min"] = 466,
									["count"] = 8,
									["amount"] = 3728,
								},
							},
							["count"] = 13,
							["amount"] = 7456,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 950,
									["min"] = 925,
									["count"] = 5,
									["amount"] = 4691,
								},
							},
							["count"] = 5,
							["amount"] = 4691,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6684,
									["min"] = 6684,
									["count"] = 1,
									["amount"] = 6684,
								},
								["Hit"] = {
									["max"] = 3267,
									["min"] = 3012,
									["count"] = 3,
									["amount"] = 9345,
								},
							},
							["count"] = 4,
							["amount"] = 16029,
						},
						["Death Coil"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1723,
									["min"] = 1723,
									["count"] = 1,
									["amount"] = 1723,
								},
							},
							["count"] = 1,
							["amount"] = 1723,
						},
						["Blood Plague"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 471,
									["min"] = 466,
									["count"] = 6,
									["amount"] = 2806,
								},
							},
							["count"] = 6,
							["amount"] = 2806,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2068,
									["min"] = 2068,
									["count"] = 1,
									["amount"] = 2068,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2068,
						},
						["Frost Fever"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4502,
									["min"] = 4502,
									["count"] = 1,
									["amount"] = 4502,
								},
								["Hit"] = {
									["max"] = 2401,
									["min"] = 2255,
									["count"] = 4,
									["amount"] = 9376,
								},
							},
							["count"] = 6,
							["amount"] = 13878,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 465,
									["min"] = 459,
									["count"] = 6,
									["amount"] = 2766,
								},
							},
							["count"] = 6,
							["amount"] = 2766,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2172,
									["min"] = 2172,
									["count"] = 1,
									["amount"] = 2172,
								},
								["Hit"] = {
									["max"] = 1253,
									["min"] = 1136,
									["count"] = 2,
									["amount"] = 2389,
								},
							},
							["count"] = 3,
							["amount"] = 4561,
						},
					},
					["HealingTaken"] = 1503,
					["RageGain"] = 0,
					["TimeDamage"] = 32.32,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1016,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 51,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 15,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 17,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 26,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 2535,
					},
					["ElementTaken"] = {
						["Physical"] = 1016,
					},
					["DOT_Time"] = 36,
					["Damage"] = 71164,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 12.25,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Tap"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementDone"] = {
						["Physical"] = 36536,
						["Frost"] = 7457,
						["Melee"] = 15186,
						["Shadow"] = 11985,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 863,
									["min"] = 821,
									["count"] = 3,
									["amount"] = 2535,
								},
							},
							["count"] = 11,
							["amount"] = 2535,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 2330,
								},
							},
							["amount"] = 2330,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 1875,
								},
								["Melee"] = {
									["count"] = 2213,
								},
								["Death Coil"] = {
									["count"] = 1723,
								},
							},
							["amount"] = 5811,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8757,
									["min"] = 8757,
									["count"] = 1,
									["amount"] = 8757,
								},
							},
							["count"] = 1,
							["amount"] = 8757,
						},
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 84,
									["min"] = 84,
									["count"] = 1,
									["amount"] = 84,
								},
							},
							["count"] = 1,
							["amount"] = 84,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Blood Tap"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 8841,
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 10,
					["Heals"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 125,
									["min"] = 18,
									["count"] = 17,
									["amount"] = 1016,
								},
							},
							["count"] = 17,
							["amount"] = 1016,
						},
					},
					["WhoHealed"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Baldrdove"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 44.56999999999998,
					["Healing"] = 1016,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4284,
									["min"] = 4284,
									["count"] = 1,
									["amount"] = 4284,
								},
								["Hit"] = {
									["max"] = 2316,
									["min"] = 2099,
									["count"] = 5,
									["amount"] = 10902,
								},
							},
							["count"] = 7,
							["amount"] = 15186,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 932,
									["min"] = 932,
									["count"] = 4,
									["amount"] = 3728,
								},
								["Hit"] = {
									["max"] = 466,
									["min"] = 466,
									["count"] = 8,
									["amount"] = 3728,
								},
							},
							["count"] = 13,
							["amount"] = 7456,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 950,
									["min"] = 925,
									["count"] = 5,
									["amount"] = 4691,
								},
							},
							["count"] = 5,
							["amount"] = 4691,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6684,
									["min"] = 6684,
									["count"] = 1,
									["amount"] = 6684,
								},
								["Hit"] = {
									["max"] = 3267,
									["min"] = 3012,
									["count"] = 3,
									["amount"] = 9345,
								},
							},
							["count"] = 4,
							["amount"] = 16029,
						},
						["Death Coil"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1723,
									["min"] = 1723,
									["count"] = 1,
									["amount"] = 1723,
								},
							},
							["count"] = 1,
							["amount"] = 1723,
						},
						["Blood Plague"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 471,
									["min"] = 466,
									["count"] = 6,
									["amount"] = 2806,
								},
							},
							["count"] = 6,
							["amount"] = 2806,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2068,
									["min"] = 2068,
									["count"] = 1,
									["amount"] = 2068,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2068,
						},
						["Frost Fever"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4502,
									["min"] = 4502,
									["count"] = 1,
									["amount"] = 4502,
								},
								["Hit"] = {
									["max"] = 2401,
									["min"] = 2255,
									["count"] = 4,
									["amount"] = 9376,
								},
							},
							["count"] = 6,
							["amount"] = 13878,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 465,
									["min"] = 459,
									["count"] = 6,
									["amount"] = 2766,
								},
							},
							["count"] = 6,
							["amount"] = 2766,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2172,
									["min"] = 2172,
									["count"] = 1,
									["amount"] = 2172,
								},
								["Hit"] = {
									["max"] = 1253,
									["min"] = 1136,
									["count"] = 2,
									["amount"] = 2389,
								},
							},
							["count"] = 3,
							["amount"] = 4561,
						},
					},
					["HealingTaken"] = 1503,
					["RageGain"] = 0,
					["TimeDamage"] = 32.32,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["RunicPowerGainedFrom"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Tap"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["TimeHealing"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
					},
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 15,
						},
						["Frost"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 17,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 8,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 26,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 3,
								},
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 11,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeSpent"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 12.25,
								},
							},
							["amount"] = 12.25,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
					},
					["DamageTaken"] = 1016,
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8757,
									["min"] = 8757,
									["count"] = 1,
									["amount"] = 8757,
								},
							},
							["count"] = 1,
							["amount"] = 8757,
						},
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 84,
									["min"] = 84,
									["count"] = 1,
									["amount"] = 84,
								},
							},
							["count"] = 1,
							["amount"] = 84,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 8841,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 863,
									["min"] = 821,
									["count"] = 3,
									["amount"] = 2535,
								},
							},
							["count"] = 11,
							["amount"] = 2535,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 48.06999999999998,
					["ElementTakenAbsorb"] = {
						["Melee"] = 2535,
					},
					["ElementTaken"] = {
						["Physical"] = 1016,
					},
					["DOT_Time"] = 36,
					["Damage"] = 76224,
					["WhoHealed"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
						["Baldrdove"] = {
							["Details"] = {
								["Holy Nova"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["TimeHeal"] = 12.25,
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["HealedWho"] = {
						["Teebz"] = {
							["Details"] = {
								["Blood Presence"] = {
									["count"] = 1016,
								},
							},
							["amount"] = 1016,
						},
					},
					["Heals"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 125,
									["min"] = 18,
									["count"] = 17,
									["amount"] = 1016,
								},
							},
							["count"] = 17,
							["amount"] = 1016,
						},
					},
					["Healing"] = 1016,
					["HOTs"] = {
						["Blood Presence"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["HOT_Time"] = 51,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 5060,
									["min"] = 4284,
									["count"] = 2,
									["amount"] = 9344,
								},
								["Hit"] = {
									["max"] = 2316,
									["min"] = 2099,
									["count"] = 5,
									["amount"] = 10902,
								},
							},
							["count"] = 8,
							["amount"] = 20246,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 932,
									["min"] = 932,
									["count"] = 4,
									["amount"] = 3728,
								},
								["Hit"] = {
									["max"] = 466,
									["min"] = 466,
									["count"] = 8,
									["amount"] = 3728,
								},
							},
							["count"] = 13,
							["amount"] = 7456,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 950,
									["min"] = 925,
									["count"] = 5,
									["amount"] = 4691,
								},
							},
							["count"] = 5,
							["amount"] = 4691,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6684,
									["min"] = 6684,
									["count"] = 1,
									["amount"] = 6684,
								},
								["Hit"] = {
									["max"] = 3267,
									["min"] = 3012,
									["count"] = 3,
									["amount"] = 9345,
								},
							},
							["count"] = 4,
							["amount"] = 16029,
						},
						["Death Coil"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1723,
									["min"] = 1723,
									["count"] = 1,
									["amount"] = 1723,
								},
							},
							["count"] = 1,
							["amount"] = 1723,
						},
						["Blood Plague"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 471,
									["min"] = 466,
									["count"] = 6,
									["amount"] = 2806,
								},
							},
							["count"] = 6,
							["amount"] = 2806,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2068,
									["min"] = 2068,
									["count"] = 1,
									["amount"] = 2068,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2068,
						},
						["Frost Fever"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4502,
									["min"] = 4502,
									["count"] = 1,
									["amount"] = 4502,
								},
								["Hit"] = {
									["max"] = 2401,
									["min"] = 2255,
									["count"] = 4,
									["amount"] = 9376,
								},
							},
							["count"] = 6,
							["amount"] = 13878,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 465,
									["min"] = 459,
									["count"] = 6,
									["amount"] = 2766,
								},
							},
							["count"] = 6,
							["amount"] = 2766,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2172,
									["min"] = 2172,
									["count"] = 1,
									["amount"] = 2172,
								},
								["Hit"] = {
									["max"] = 1253,
									["min"] = 1136,
									["count"] = 2,
									["amount"] = 2389,
								},
							},
							["count"] = 3,
							["amount"] = 4561,
						},
					},
					["HealingTaken"] = 1503,
					["DamagedWho"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 2330,
								},
							},
							["amount"] = 2330,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5060,
								},
							},
							["amount"] = 5060,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12973,
								},
								["Death and Decay"] = {
									["count"] = 5126,
								},
								["Icy Touch"] = {
									["count"] = 2816,
								},
								["Rune Strike"] = {
									["count"] = 16029,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2806,
								},
								["Death Strike"] = {
									["count"] = 2068,
								},
								["Heart Strike"] = {
									["count"] = 13878,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2766,
								},
								["Plague Strike"] = {
									["count"] = 4561,
								},
							},
							["amount"] = 63023,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 1875,
								},
								["Melee"] = {
									["count"] = 2213,
								},
								["Death Coil"] = {
									["count"] = 1723,
								},
							},
							["amount"] = 5811,
						},
					},
					["TimeDamage"] = 35.82,
					["TimeDamaging"] = {
						["Pulsing Pumpkin"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 0.86,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.49,
								},
								["Death and Decay"] = {
									["count"] = 5.16,
								},
								["Icy Touch"] = {
									["count"] = 3.64,
								},
								["Rune Strike"] = {
									["count"] = 0.9800000000000001,
								},
								["Blood Plague"] = {
									["count"] = 4.739999999999999,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.91,
								},
								["Death Strike"] = {
									["count"] = 1.29,
								},
								["Frost Fever"] = {
									["count"] = 6.09,
								},
								["Heart Strike"] = {
									["count"] = 1.12,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 2.34,
								},
								["Plague Strike"] = {
									["count"] = 0.7000000000000001,
								},
							},
							["amount"] = 31.46,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Coil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 10,
					["ElementDone"] = {
						["Physical"] = 36536,
						["Frost"] = 7457,
						["Melee"] = 20246,
						["Shadow"] = 11985,
					},
					["RunicPowerGained"] = {
						["Blood Tap"] = {
							["Details"] = {
								["Teebz"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
				},
			},
			["UnitLockout"] = 1604179384,
			["LastActive"] = 1604179446,
		},
		["Thrug"] = {
			["GUID"] = "0x0700000000005C7C",
			["LastEventHealth"] = {
				"40792 (95%)", -- [1]
				"40792 (95%)", -- [2]
				"40792 (95%)", -- [3]
				"40792 (95%)", -- [4]
				"40792 (95%)", -- [5]
				"40792 (95%)", -- [6]
				"40792 (95%)", -- [7]
				"40792 (95%)", -- [8]
				"40792 (95%)", -- [9]
				"40792 (95%)", -- [10]
				"39126 (91%)", -- [11]
				"39126 (91%)", -- [12]
				"40792 (95%)", -- [13]
				"40792 (95%)", -- [14]
				"40792 (95%)", -- [15]
				"40792 (95%)", -- [16]
				"40792 (95%)", -- [17]
				"40792 (95%)", -- [18]
				"40792 (95%)", -- [19]
				"40792 (95%)", -- [20]
				"40792 (95%)", -- [21]
				"40792 (95%)", -- [22]
				"40792 (95%)", -- [23]
				"40792 (95%)", -- [24]
				"40792 (95%)", -- [25]
				"40792 (95%)", -- [26]
				"40792 (95%)", -- [27]
				"40792 (95%)", -- [28]
				"40792 (95%)", -- [29]
				"40792 (95%)", -- [30]
				"40792 (95%)", -- [31]
				"40792 (95%)", -- [32]
				"40792 (95%)", -- [33]
				"40792 (95%)", -- [34]
				"40792 (95%)", -- [35]
				"40792 (95%)", -- [36]
				"40792 (95%)", -- [37]
				"40792 (95%)", -- [38]
				"40792 (95%)", -- [39]
				"40792 (95%)", -- [40]
				"40792 (95%)", -- [41]
				"40792 (95%)", -- [42]
				"40792 (95%)", -- [43]
				"40792 (95%)", -- [44]
				"40792 (95%)", -- [45]
				"40792 (95%)", -- [46]
				"40792 (95%)", -- [47]
				"40792 (95%)", -- [48]
				"40792 (95%)", -- [49]
				"40792 (95%)", -- [50]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["RageGain"] = {
					15, -- [1]
				},
				["ActiveTime"] = {
					46.02000000000002, -- [1]
				},
				["DOT_Time"] = {
					54, -- [1]
				},
				["TimeDamage"] = {
					46.02000000000002, -- [1]
				},
				["DamageTaken"] = {
					3526, -- [1]
				},
				["Damage"] = {
					104867, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "Thrug",
			["level"] = 80,
			["LastDamageAbility"] = "Horseman's Cleave",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[11] = 3.906030197880522,
			},
			["type"] = "Grouped",
			["FightsSaved"] = 3,
			["LastDamageTaken"] = 1666,
			["TimeLast"] = {
				["RageGain"] = 1604179408,
				["DOT_Time"] = 1604179441,
				["ActiveTime"] = 1604179447,
				["TimeDamage"] = 1604179447,
				["OVERALL"] = 1604179447,
				["DamageTaken"] = 1604179447,
				["Damage"] = 1604179447,
			},
			["Owner"] = false,
			["LastAbility"] = 1138229.566,
			["NextEventNum"] = 13,
			["LastEventHealthNum"] = {
				95.63912594954516, -- [1]
				95.63912594954516, -- [2]
				95.63912594954516, -- [3]
				95.63912594954516, -- [4]
				95.63912594954516, -- [5]
				95.63912594954516, -- [6]
				95.63912594954516, -- [7]
				95.63912594954516, -- [8]
				95.63912594954516, -- [9]
				95.63912594954516, -- [10]
				91.73309575166464, -- [11]
				91.73309575166464, -- [12]
				95.63912594954516, -- [13]
				95.63912594954516, -- [14]
				95.63912594954516, -- [15]
				95.63912594954516, -- [16]
				95.63912594954516, -- [17]
				95.63912594954516, -- [18]
				95.63912594954516, -- [19]
				95.63912594954516, -- [20]
				95.63912594954516, -- [21]
				95.63912594954516, -- [22]
				95.63912594954516, -- [23]
				95.63912594954516, -- [24]
				95.63912594954516, -- [25]
				95.63912594954516, -- [26]
				95.63912594954516, -- [27]
				95.63912594954516, -- [28]
				95.63912594954516, -- [29]
				95.63912594954516, -- [30]
				95.63912594954516, -- [31]
				95.63912594954516, -- [32]
				95.63912594954516, -- [33]
				95.63912594954516, -- [34]
				95.63912594954516, -- [35]
				95.63912594954516, -- [36]
				95.63912594954516, -- [37]
				95.63912594954516, -- [38]
				95.63912594954516, -- [39]
				95.63912594954516, -- [40]
				95.63912594954516, -- [41]
				95.63912594954516, -- [42]
				95.63912594954516, -- [43]
				95.63912594954516, -- [44]
				95.63912594954516, -- [45]
				95.63912594954516, -- [46]
				95.63912594954516, -- [47]
				95.63912594954516, -- [48]
				95.63912594954516, -- [49]
				95.63912594954516, -- [50]
			},
			["LastEvents"] = {
				"Thrug Melee Headless Horseman Hit -2766 (Physical)", -- [1]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -673 (Physical)", -- [2]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -673 (Physical)", -- [3]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [4]
				"Thrug Rend Headless Horseman Immune (Physical)", -- [5]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [6]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [7]
				"Thrug Melee Head of the Horseman Crit -5808 (Physical)", -- [8]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [9]
				"Thrug Overpower Head of the Horseman Crit -6477 (Physical)", -- [10]
				"Headless Horseman Horseman's Cleave Thrug Hit -1666 (Physical)", -- [11]
				"Thrug Mortal Strike Head of the Horseman Hit -3595 (Physical)", -- [12]
				"Thrug Whirlwind Head of the Horseman Hit -2607 (Physical)", -- [13]
				"Thrug Melee Head of the Horseman Hit -2667 (Physical)", -- [14]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [15]
				"Thrug Whirlwind Head of the Horseman Hit -2642 (Physical)", -- [16]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [17]
				"Thrug Whirlwind Head of the Horseman Hit -2641 (Physical)", -- [18]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [19]
				"Thrug Mortal Strike Head of the Horseman Hit -3377 (Physical)", -- [20]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [21]
				"Thrug Execute Headless Horseman Crit -6853 (Physical)", -- [22]
				"Thrug Melee Headless Horseman Hit -2631 (Physical)", -- [23]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -394 (Physical)", -- [24]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -394 (Physical)", -- [25]
				"Thrug Melee Headless Horseman Hit -2579 (Physical)", -- [26]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -394 (Physical)", -- [27]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -394 (Physical)", -- [28]
				"Thrug Rend (DoT) Headless Horseman Tick -1383 (Physical)", -- [29]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -394 (Physical)", -- [30]
				"Thrug Deep Wounds Headless Horseman Immune (Physical)", -- [31]
				"Thrug Overpower Headless Horseman Immune (Physical)", -- [32]
				"Thrug Melee Headless Horseman Immune", -- [33]
				"Thrug Rend Headless Horseman Immune (Physical)", -- [34]
				"Thrug Rend Headless Horseman Immune (Physical)", -- [35]
				"Thrug Melee Head of the Horseman Crit -5438 (Physical)", -- [36]
				"Thrug Mortal Strike Head of the Horseman Crit -7163 (Physical)", -- [37]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [38]
				"Thrug Rend (DoT) Headless Horseman Tick -1383 (Physical)", -- [39]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [40]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [41]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [42]
				"Thrug Rend (DoT) Headless Horseman Tick -1383 (Physical)", -- [43]
				"Thrug Melee Headless Horseman Crit -5344 (Physical)", -- [44]
				"Thrug Mortal Strike Headless Horseman Hit -3632 (Physical)", -- [45]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [46]
				"Thrug Deep Wounds (DoT) Head of the Horseman Tick -282 (Physical)", -- [47]
				"Thrug Deep Wounds (DoT) Headless Horseman Tick -367 (Physical)", -- [48]
				"Thrug Overpower Headless Horseman Crit -6608 (Physical)", -- [49]
				"Thrug Rend (DoT) Headless Horseman Tick -1383 (Physical)", -- [50]
			},
			["Name"] = "Thrug",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138223.096, -- [1]
				1138223.096, -- [2]
				1138224.216, -- [3]
				1138225.179, -- [4]
				1138225.524, -- [5]
				1138226.119, -- [6]
				1138227.185, -- [7]
				1138227.944, -- [8]
				1138228.08, -- [9]
				1138228.299, -- [10]
				1138229.56, -- [11]
				1138229.566, -- [12]
				1138197.673, -- [13]
				1138197.974, -- [14]
				1138197.974, -- [15]
				1138198.651, -- [16]
				1138198.974, -- [17]
				1138199.647, -- [18]
				1138199.949, -- [19]
				1138200.267, -- [20]
				1138201.105, -- [21]
				1138202.525, -- [22]
				1138202.526, -- [23]
				1138203.806, -- [24]
				1138204.747, -- [25]
				1138205.7, -- [26]
				1138205.7, -- [27]
				1138206.794, -- [28]
				1138207.533, -- [29]
				1138207.692, -- [30]
				1138208.703, -- [31]
				1138209.002, -- [32]
				1138210.493, -- [33]
				1138210.493, -- [34]
				1138213.488, -- [35]
				1138214.427, -- [36]
				1138214.59, -- [37]
				1138216.159, -- [38]
				1138216.428, -- [39]
				1138217.029, -- [40]
				1138218.177, -- [41]
				1138219.163, -- [42]
				1138219.452, -- [43]
				1138219.873, -- [44]
				1138220.033, -- [45]
				1138220.034, -- [46]
				1138221.202, -- [47]
				1138221.404, -- [48]
				1138221.592, -- [49]
				1138222.484, -- [50]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 18,
								},
								["Headless Horseman"] = {
									["count"] = 24,
								},
							},
							["amount"] = 42,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 3526,
					["RageGainedFrom"] = {
						["Thrug"] = {
							["Details"] = {
								["Charge"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 10,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 18,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 49,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 3526,
					},
					["DOT_Time"] = 54,
					["Damage"] = 98429,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 34636,
						["Physical"] = 63793,
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 14135,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1692,
								},
								["Whirlwind"] = {
									["count"] = 7890,
								},
								["Overpower"] = {
									["count"] = 6477,
								},
								["Melee"] = {
									["count"] = 13913,
								},
							},
							["amount"] = 44107,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Charge"] = {
							["Details"] = {
								["Thrug"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 42.52000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 673,
									["min"] = 282,
									["count"] = 14,
									["amount"] = 5375,
								},
							},
							["count"] = 14,
							["amount"] = 5375,
						},
						["Execute"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6853,
									["min"] = 6853,
									["count"] = 1,
									["amount"] = 6853,
								},
							},
							["count"] = 1,
							["amount"] = 6853,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2672,
									["min"] = 2250,
									["count"] = 6,
									["amount"] = 15181,
								},
							},
							["count"] = 8,
							["amount"] = 15181,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7163,
									["min"] = 7163,
									["count"] = 1,
									["amount"] = 7163,
								},
								["Hit"] = {
									["max"] = 3632,
									["min"] = 3377,
									["count"] = 3,
									["amount"] = 10604,
								},
							},
							["count"] = 4,
							["amount"] = 17767,
						},
						["Charge Stun"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1383,
									["min"] = 1383,
									["count"] = 4,
									["amount"] = 5532,
								},
							},
							["count"] = 4,
							["amount"] = 5532,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6608,
									["min"] = 6477,
									["count"] = 2,
									["amount"] = 13085,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 13085,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 5808,
									["min"] = 5060,
									["count"] = 4,
									["amount"] = 21650,
								},
								["Hit"] = {
									["max"] = 2766,
									["min"] = 2343,
									["count"] = 5,
									["amount"] = 12986,
								},
							},
							["count"] = 10,
							["amount"] = 34636,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 15,
					["TimeDamage"] = 42.52000000000001,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementDone"] = {
						["Melee"] = 6438,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6438,
								},
							},
							["amount"] = 6438,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6438,
									["min"] = 6438,
									["count"] = 1,
									["amount"] = 6438,
								},
							},
							["count"] = 1,
							["amount"] = 6438,
						},
					},
					["ActiveTime"] = 3.5,
					["Damage"] = 6438,
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 18,
								},
								["Headless Horseman"] = {
									["count"] = 24,
								},
							},
							["amount"] = 42,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 3526,
					["RageGainedFrom"] = {
						["Thrug"] = {
							["Details"] = {
								["Charge"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 10,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 18,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 49,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 3526,
					},
					["DOT_Time"] = 54,
					["Damage"] = 98429,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 34636,
						["Physical"] = 63793,
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 14135,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1692,
								},
								["Whirlwind"] = {
									["count"] = 7890,
								},
								["Overpower"] = {
									["count"] = 6477,
								},
								["Melee"] = {
									["count"] = 13913,
								},
							},
							["amount"] = 44107,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Charge"] = {
							["Details"] = {
								["Thrug"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 42.52000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 673,
									["min"] = 282,
									["count"] = 14,
									["amount"] = 5375,
								},
							},
							["count"] = 14,
							["amount"] = 5375,
						},
						["Execute"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6853,
									["min"] = 6853,
									["count"] = 1,
									["amount"] = 6853,
								},
							},
							["count"] = 1,
							["amount"] = 6853,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2672,
									["min"] = 2250,
									["count"] = 6,
									["amount"] = 15181,
								},
							},
							["count"] = 8,
							["amount"] = 15181,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7163,
									["min"] = 7163,
									["count"] = 1,
									["amount"] = 7163,
								},
								["Hit"] = {
									["max"] = 3632,
									["min"] = 3377,
									["count"] = 3,
									["amount"] = 10604,
								},
							},
							["count"] = 4,
							["amount"] = 17767,
						},
						["Charge Stun"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1383,
									["min"] = 1383,
									["count"] = 4,
									["amount"] = 5532,
								},
							},
							["count"] = 4,
							["amount"] = 5532,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6608,
									["min"] = 6477,
									["count"] = 2,
									["amount"] = 13085,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 13085,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 5808,
									["min"] = 5060,
									["count"] = 4,
									["amount"] = 21650,
								},
								["Hit"] = {
									["max"] = 2766,
									["min"] = 2343,
									["count"] = 5,
									["amount"] = 12986,
								},
							},
							["count"] = 10,
							["amount"] = 34636,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 15,
					["TimeDamage"] = 42.52000000000001,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 18,
								},
								["Headless Horseman"] = {
									["count"] = 24,
								},
							},
							["amount"] = 42,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
					},
					["DamageTaken"] = 3526,
					["RageGainedFrom"] = {
						["Thrug"] = {
							["Details"] = {
								["Charge"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 46.02000000000002,
					["ElementTaken"] = {
						["Physical"] = 3526,
					},
					["RageGained"] = {
						["Charge"] = {
							["Details"] = {
								["Thrug"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 104867,
					["DOT_Time"] = 54,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDone"] = {
						["Melee"] = 41074,
						["Physical"] = 63793,
					},
					["RageGain"] = 15,
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6438,
								},
							},
							["amount"] = 6438,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 3632,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 3683,
								},
								["Overpower"] = {
									["count"] = 6608,
								},
								["Execute"] = {
									["count"] = 6853,
								},
								["Whirlwind"] = {
									["count"] = 7291,
								},
								["Rend (DoT)"] = {
									["count"] = 5532,
								},
								["Melee"] = {
									["count"] = 20723,
								},
							},
							["amount"] = 54322,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 14135,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 1692,
								},
								["Whirlwind"] = {
									["count"] = 7890,
								},
								["Overpower"] = {
									["count"] = 6477,
								},
								["Melee"] = {
									["count"] = 13913,
								},
							},
							["amount"] = 44107,
						},
					},
					["TimeDamage"] = 46.02000000000002,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Deep Wounds (DoT)"] = {
									["count"] = 4.79,
								},
								["Execute"] = {
									["count"] = 1.42,
								},
								["Whirlwind"] = {
									["count"] = 5.569999999999999,
								},
								["Mortal Strike"] = {
									["count"] = 0.16,
								},
								["Charge Stun"] = {
									["count"] = 3.5,
								},
								["Rend (DoT)"] = {
									["count"] = 2.19,
								},
								["Deep Wounds"] = {
									["count"] = 5.83,
								},
								["Overpower"] = {
									["count"] = 0.49,
								},
								["Rend"] = {
									["count"] = 3.34,
								},
								["Melee"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 31.72,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Mortal Strike"] = {
									["count"] = 1.75,
								},
								["Deep Wounds (DoT)"] = {
									["count"] = 5.48,
								},
								["Whirlwind"] = {
									["count"] = 1.35,
								},
								["Overpower"] = {
									["count"] = 0.22,
								},
								["Melee"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10.8,
						},
					},
					["Attacks"] = {
						["Deep Wounds (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 673,
									["min"] = 282,
									["count"] = 14,
									["amount"] = 5375,
								},
							},
							["count"] = 14,
							["amount"] = 5375,
						},
						["Execute"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6853,
									["min"] = 6853,
									["count"] = 1,
									["amount"] = 6853,
								},
							},
							["count"] = 1,
							["amount"] = 6853,
						},
						["Whirlwind"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2672,
									["min"] = 2250,
									["count"] = 6,
									["amount"] = 15181,
								},
							},
							["count"] = 8,
							["amount"] = 15181,
						},
						["Mortal Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7163,
									["min"] = 7163,
									["count"] = 1,
									["amount"] = 7163,
								},
								["Hit"] = {
									["max"] = 3632,
									["min"] = 3377,
									["count"] = 3,
									["amount"] = 10604,
								},
							},
							["count"] = 4,
							["amount"] = 17767,
						},
						["Charge Stun"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rend (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1383,
									["min"] = 1383,
									["count"] = 4,
									["amount"] = 5532,
								},
							},
							["count"] = 4,
							["amount"] = 5532,
						},
						["Deep Wounds"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Overpower"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6608,
									["min"] = 6477,
									["count"] = 2,
									["amount"] = 13085,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 13085,
						},
						["Rend"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6438,
									["min"] = 5060,
									["count"] = 5,
									["amount"] = 28088,
								},
								["Hit"] = {
									["max"] = 2766,
									["min"] = 2343,
									["count"] = 5,
									["amount"] = 12986,
								},
							},
							["count"] = 11,
							["amount"] = 41074,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3526,
								},
							},
							["amount"] = 3526,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 11,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 18,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 49,
						},
					},
				},
			},
			["UnitLockout"] = 1604179374,
			["LastActive"] = 1604179447,
		},
	},
	["FightNum"] = 3,
	["CombatTimes"] = {
		{
			1604179372, -- [1]
			1604179376, -- [2]
			"22:22:53", -- [3]
			"22:22:56", -- [4]
			"Anguished Dead", -- [5]
		}, -- [1]
		{
			1604179383, -- [1]
			1604179397, -- [2]
			"22:23:04", -- [3]
			"22:23:17", -- [4]
			"Anguished Dead", -- [5]
		}, -- [2]
		{
			1604179405, -- [1]
			1604179449, -- [2]
			"22:23:26", -- [3]
			"22:24:09", -- [4]
			"Headless Horseman", -- [5]
		}, -- [3]
	},
	["FoughtWho"] = {
		"Headless Horseman 22:23:26-22:24:09", -- [1]
		"Anguished Dead 22:23:04-22:23:17", -- [2]
		"Anguished Dead 22:22:53-22:22:56", -- [3]
	},
}
