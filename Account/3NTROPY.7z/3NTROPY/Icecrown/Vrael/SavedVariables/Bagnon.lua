
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 14,
			["reverseSlotOrder"] = true,
			["y"] = -128.4074697740369,
			["x"] = -254.5780881403466,
		},
		["keys"] = {
			["y"] = 149.9999976748339,
			["x"] = -350.0000179174567,
		},
		["guildbank"] = {
			["y"] = -116.5801407149517,
			["x"] = 104.0001449809477,
			["point"] = "TOPLEFT",
		},
		["bank"] = {
			["y"] = -115.1998783254236,
			["x"] = 8.533514568636203,
			["point"] = "TOPLEFT",
			["itemFrameColumns"] = 16,
		},
	},
	["version"] = "2.13.3",
}
