
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Headless Horseman"] = {
			["GUID"] = "0xF130005C8200008A",
			["LastEventHealth"] = {
				"12079 (9%)", -- [1]
				"12079 (9%)", -- [2]
				"1 (0%)", -- [3]
				"1 (0%)", -- [4]
				"1 (0%)", -- [5]
				"1 (0%)", -- [6]
				"1 (0%)", -- [7]
				"5041 (4%)", -- [8]
				"5041 (4%)", -- [9]
				"5041 (4%)", -- [10]
				"5041 (4%)", -- [11]
				"5041 (4%)", -- [12]
				"5041 (4%)", -- [13]
				"5041 (4%)", -- [14]
				"10081 (8%)", -- [15]
				"10081 (8%)", -- [16]
				"10081 (8%)", -- [17]
				"10081 (8%)", -- [18]
				"15121 (12%)", -- [19]
				"1825 (2%)", -- [20]
				"70157 (55%)", -- [21]
				"70157 (55%)", -- [22]
				"70157 (55%)", -- [23]
				"63717 (50%)", -- [24]
				"63427 (50%)", -- [25]
				"63136 (50%)", -- [26]
				"56881 (45%)", -- [27]
				"56881 (45%)", -- [28]
				"56144 (44%)", -- [29]
				"49962 (39%)", -- [30]
				"49508 (39%)", -- [31]
				"49508 (39%)", -- [32]
				"49070 (38%)", -- [33]
				"48277 (38%)", -- [34]
				"47796 (37%)", -- [35]
				"47317 (37%)", -- [36]
				"42884 (34%)", -- [37]
				"38648 (30%)", -- [38]
				"38171 (30%)", -- [39]
				"38171 (30%)", -- [40]
				"36369 (28%)", -- [41]
				"36369 (28%)", -- [42]
				"32474 (25%)", -- [43]
				"31580 (25%)", -- [44]
				"30878 (24%)", -- [45]
				"23648 (18%)", -- [46]
				"23194 (18%)", -- [47]
				"20488 (16%)", -- [48]
				"20036 (15%)", -- [49]
				"13618 (10%)", -- [50]
			},
			["LastAttackedBy"] = "Praxia",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					26.26, -- [1]
				},
				["Damage"] = {
					16986, -- [1]
				},
				["DamageTaken"] = {
					413870, -- [1]
				},
				["ActiveTime"] = {
					26.26, -- [1]
				},
			},
			["enClass"] = "MOB",
			["unit"] = "party1target",
			["level"] = -1,
			["LastDamageAbility"] = "Kill Shot",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				1.221428571428572, -- [1]
				0.9801587301587301, -- [2]
				22.4515873015873, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				0.3468253968253968, -- [21]
				1.016666666666667, -- [22]
				2.185714285714286, -- [23]
				5.111111111111111, -- [24]
				0.2301587301587302, -- [25]
				0.230952380952381, -- [26]
				1.761904761904762, -- [27]
				nil, -- [28]
				0.584920634920635, -- [29]
				4.906349206349207, -- [30]
				0.3603174603174603, -- [31]
				0.3476190476190476, -- [32]
				0.9531746031746032, -- [33]
				0.6293650793650794, -- [34]
				0.3817460317460317, -- [35]
				0.3801587301587301, -- [36]
				2.565079365079365, -- [37]
				3.361904761904762, -- [38]
				0.3785714285714286, -- [39]
				1.083333333333333, -- [40]
				0.3468253968253968, -- [41]
				0.5571428571428572, -- [42]
				3.091269841269841, -- [43]
				0.7095238095238096, -- [44]
				2.147619047619048, -- [45]
				5.738095238095238, -- [46]
				0.3603174603174603, -- [47]
				0.3587301587301587, -- [48]
				nil, -- [49]
				5.093650793650793, -- [50]
			},
			["type"] = "Boss",
			["FightsSaved"] = 1,
			["LastDamageTaken"] = 28289,
			["TimeLast"] = {
				["ActiveTime"] = 1604180068,
				["TimeDamage"] = 1604180068,
				["OVERALL"] = 1604180068,
				["DamageTaken"] = 1604180065,
				["Damage"] = 1604180068,
			},
			["Owner"] = false,
			["LastAbility"] = 1138851.418,
			["NextEventNum"] = 21,
			["LastEventHealthNum"] = {
				9.586507936507937, -- [1]
				9.586507936507937, -- [2]
				0.0007936507936507937, -- [3]
				0.0007936507936507937, -- [4]
				0.0007936507936507937, -- [5]
				0.0007936507936507937, -- [6]
				0.0007936507936507937, -- [7]
				4.000793650793651, -- [8]
				4.000793650793651, -- [9]
				4.000793650793651, -- [10]
				4.000793650793651, -- [11]
				4.000793650793651, -- [12]
				4.000793650793651, -- [13]
				4.000793650793651, -- [14]
				8.000793650793652, -- [15]
				8.000793650793652, -- [16]
				8.000793650793652, -- [17]
				8.000793650793652, -- [18]
				12.00079365079365, -- [19]
				2.896825396825397, -- [20]
				55.68015873015873, -- [21]
				55.68015873015873, -- [22]
				55.68015873015873, -- [23]
				50.56904761904762, -- [24]
				50.33888888888889, -- [25]
				50.10793650793651, -- [26]
				45.14365079365079, -- [27]
				45.14365079365079, -- [28]
				44.55873015873016, -- [29]
				39.65238095238095, -- [30]
				39.29206349206349, -- [31]
				39.29206349206349, -- [32]
				38.94444444444444, -- [33]
				38.31507936507936, -- [34]
				37.93333333333333, -- [35]
				37.5531746031746, -- [36]
				34.03492063492064, -- [37]
				30.67301587301587, -- [38]
				30.29444444444444, -- [39]
				30.29444444444444, -- [40]
				28.86428571428571, -- [41]
				28.86428571428571, -- [42]
				25.77301587301587, -- [43]
				25.06349206349206, -- [44]
				24.50634920634921, -- [45]
				18.76825396825397, -- [46]
				18.40793650793651, -- [47]
				16.26031746031746, -- [48]
				15.9015873015873, -- [49]
				10.80793650793651, -- [50]
			},
			["LastEvents"] = {
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Crit -1539 (Fire)", -- [1]
				"Druidwarr Melee Headless Horseman Hit -1235 (Physical)", -- [2]
				"Praxia Kill Shot Headless Horseman Crit -28289 (Physical)", -- [3]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [4]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [5]
				"Druidwarr Melee Headless Horseman Immune", -- [6]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [7]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [8]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [9]
				"Praxia Serpent Sting Headless Horseman Immune (Nature)", -- [10]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [11]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [12]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [13]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [14]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [15]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [16]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [17]
				"Doable Living Bomb Headless Horseman Immune (Fire)", -- [18]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [19]
				"Headless Horseman Horseman's Cleave Doable Hit -3059 (Physical)", -- [20]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [21]
				"Trolopresor Melee Headless Horseman Crit -1281 (Physical)", -- [22]
				"Druidwarr Melee Headless Horseman Crit -2754 (Physical)", -- [23]
				"Doable Scorch Headless Horseman Crit -6440 (Fire)", -- [24]
				"Mirror Image <Doable> Fire Blast Headless Horseman Hit -290 (Fire)", -- [25]
				"Mirror Image <Doable> Fire Blast Headless Horseman Hit -291 (Fire)", -- [26]
				"Praxia Chimera Shot - Serpent Headless Horseman Hit -2220 (Nature)", -- [27]
				"Headless Horseman Melee Druidwarr Dodge", -- [28]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Hit -737 (Fire)", -- [29]
				"Praxia Auto Shot Headless Horseman Crit -6182 (Physical)", -- [30]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -454 (Physical)", -- [31]
				"Stormfang <Praxia> Melee Headless Horseman Hit -438 (Physical)", -- [32]
				"Druidwarr Melee Headless Horseman Hit -1201 (Physical)", -- [33]
				"Praxia Serpent Sting (DoT) Headless Horseman Tick -793 (Nature)", -- [34]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -481 (Frost)", -- [35]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -479 (Frost)", -- [36]
				"Doable Living Bomb (DoT) Headless Horseman Crit -3232 (Fire)", -- [37]
				"Doable Living Bomb Headless Horseman Hit -4236 (Fire)", -- [38]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -477 (Frost)", -- [39]
				"Trolopresor Melee Headless Horseman Hit -1365 (Physical)", -- [40]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [41]
				"Trolopresor Melee Headless Horseman Hit -702 (Physical)", -- [42]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -3895 (Physical)", -- [43]
				"Stormfang <Praxia> Bite Headless Horseman Crit -894 (Physical)", -- [44]
				"Druidwarr Melee Headless Horseman Crit -2706 (Physical)", -- [45]
				"Doable Scorch Headless Horseman Crit -7230 (Fire)", -- [46]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -454 (Physical)", -- [47]
				"Stormfang <Praxia> Melee Headless Horseman Hit -452 (Physical)", -- [48]
				"Headless Horseman Melee Druidwarr Hit -1978 (Physical)", -- [49]
				"Praxia Auto Shot Headless Horseman Crit -6418 (Physical)", -- [50]
			},
			["Name"] = "Headless Horseman",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				false, -- [20]
				true, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				1138847.768, -- [1]
				1138847.937, -- [2]
				1138847.939, -- [3]
				1138848.247, -- [4]
				1138848.247, -- [5]
				1138848.611, -- [6]
				1138848.766, -- [7]
				1138849.31, -- [8]
				1138849.31, -- [9]
				1138849.521, -- [10]
				1138849.751, -- [11]
				1138849.877, -- [12]
				1138849.889, -- [13]
				1138849.97, -- [14]
				1138850.032, -- [15]
				1138850.162, -- [16]
				1138850.162, -- [17]
				1138850.633, -- [18]
				1138851.195, -- [19]
				1138851.418, -- [20]
				1138845.615, -- [21]
				1138845.616, -- [22]
				1138845.616, -- [23]
				1138845.616, -- [24]
				1138845.617, -- [25]
				1138845.617, -- [26]
				1138845.79, -- [27]
				1138845.79, -- [28]
				1138845.791, -- [29]
				1138846.109, -- [30]
				1138846.109, -- [31]
				1138846.273, -- [32]
				1138846.468, -- [33]
				1138846.468, -- [34]
				1138846.469, -- [35]
				1138846.469, -- [36]
				1138846.64, -- [37]
				1138846.641, -- [38]
				1138846.641, -- [39]
				1138846.785, -- [40]
				1138847.075, -- [41]
				1138847.076, -- [42]
				1138847.076, -- [43]
				1138847.08, -- [44]
				1138847.206, -- [45]
				1138847.207, -- [46]
				1138847.207, -- [47]
				1138847.496, -- [48]
				1138847.651, -- [49]
				1138847.767, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["PartialBlock"] = {
						["Aimed Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 1,
									["amount"] = 40,
								},
							},
							["count"] = 1,
							["amount"] = 40,
						},
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
					},
					["TimeSpent"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["DamageTaken"] = 413870,
					["PartialResist"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.26,
					["ElementTaken"] = {
						["Physical"] = 214537,
						["Melee"] = 59717,
						["Arcane"] = 5156,
						["Fire"] = 70925,
						["Frost"] = 2879,
						["Nature"] = 60656,
					},
					["Damage"] = 16986,
					["ElementTakenBlock"] = {
						["Melee"] = 80,
						["Physical"] = 120,
					},
					["ElementDone"] = {
						["Melee"] = 13927,
						["Physical"] = 3059,
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 26,
								},
								["Crit"] = {
									["count"] = 20,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 71,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 26,
								},
							},
							["amount"] = 54,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 44,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
					},
					["DamagedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["TimeDamage"] = 26.26,
					["TimeDamaging"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2096,
									["min"] = 1899,
									["count"] = 7,
									["amount"] = 13927,
								},
							},
							["count"] = 9,
							["amount"] = 13927,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3059,
									["min"] = 3059,
									["count"] = 1,
									["amount"] = 3059,
								},
							},
							["count"] = 1,
							["amount"] = 3059,
						},
					},
					["WhoDamaged"] = {
						["Praxia"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
						["Magma Totem VII <Trolopresor>"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
						["Mirror Image <Doable>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
						["Doable"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
						["Stormfang <Praxia>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["LastFightData"] = {
					["PartialBlock"] = {
						["Aimed Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 1,
									["amount"] = 40,
								},
							},
							["count"] = 1,
							["amount"] = 40,
						},
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
					},
					["TimeSpent"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["DamageTaken"] = 413870,
					["PartialResist"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.26,
					["ElementTaken"] = {
						["Physical"] = 214537,
						["Melee"] = 59717,
						["Arcane"] = 5156,
						["Fire"] = 70925,
						["Frost"] = 2879,
						["Nature"] = 60656,
					},
					["Damage"] = 16986,
					["ElementTakenBlock"] = {
						["Melee"] = 80,
						["Physical"] = 120,
					},
					["ElementDone"] = {
						["Melee"] = 13927,
						["Physical"] = 3059,
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 26,
								},
								["Crit"] = {
									["count"] = 20,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 71,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 26,
								},
							},
							["amount"] = 54,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 44,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
					},
					["DamagedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["TimeDamage"] = 26.26,
					["TimeDamaging"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2096,
									["min"] = 1899,
									["count"] = 7,
									["amount"] = 13927,
								},
							},
							["count"] = 9,
							["amount"] = 13927,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3059,
									["min"] = 3059,
									["count"] = 1,
									["amount"] = 3059,
								},
							},
							["count"] = 1,
							["amount"] = 3059,
						},
					},
					["WhoDamaged"] = {
						["Praxia"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
						["Magma Totem VII <Trolopresor>"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
						["Mirror Image <Doable>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
						["Doable"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
						["Stormfang <Praxia>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["PartialBlock"] = {
						["Aimed Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 1,
									["amount"] = 40,
								},
							},
							["count"] = 1,
							["amount"] = 40,
						},
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 2,
									["amount"] = 80,
								},
							},
							["count"] = 2,
							["amount"] = 80,
						},
					},
					["TimeSpent"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["DamageTaken"] = 413870,
					["PartialResist"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Chimera Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Lava Lash"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fire Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 54,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Ignite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Magma Totem"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Earth Shock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.26,
					["ElementTaken"] = {
						["Physical"] = 214537,
						["Melee"] = 59717,
						["Arcane"] = 5156,
						["Fire"] = 70925,
						["Frost"] = 2879,
						["Nature"] = 60656,
					},
					["Damage"] = 16986,
					["ElementTakenBlock"] = {
						["Melee"] = 80,
						["Physical"] = 120,
					},
					["ElementDone"] = {
						["Melee"] = 13927,
						["Physical"] = 3059,
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 26,
								},
								["Crit"] = {
									["count"] = 20,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 71,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 14,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 26,
								},
							},
							["amount"] = 54,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 17,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 44,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 19,
						},
					},
					["DamagedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["TimeDamage"] = 26.26,
					["TimeDamaging"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.76,
								},
							},
							["amount"] = 22.76,
						},
						["Doable"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2096,
									["min"] = 1899,
									["count"] = 7,
									["amount"] = 13927,
								},
							},
							["count"] = 9,
							["amount"] = 13927,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3059,
									["min"] = 3059,
									["count"] = 1,
									["amount"] = 3059,
								},
							},
							["count"] = 1,
							["amount"] = 3059,
						},
					},
					["WhoDamaged"] = {
						["Praxia"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
						["Magma Totem VII <Trolopresor>"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
						["Mirror Image <Doable>"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
						["Doable"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
						["Stormfang <Praxia>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["UnitLockout"] = 1604180065,
			["LastActive"] = 1604180068,
		},
		["Druidwarr"] = {
			["GUID"] = "0x0700000000586326",
			["TimeLast"] = {
				["TimeHeal"] = 1604180064,
				["OVERALL"] = 1604180066,
				["DamageTaken"] = 1604180065,
				["Healing"] = 1604180064,
				["EnergyGain"] = 1604180042,
				["HealingTaken"] = 1604180065,
				["HOT_Time"] = 1604180064,
				["TimeDamage"] = 1604180066,
				["Overhealing"] = 1604180015,
				["ManaGain"] = 1604180064,
				["ActiveTime"] = 1604180066,
				["Damage"] = 1604180065,
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					5.61, -- [1]
				},
				["Healing"] = {
					4780, -- [1]
				},
				["DamageTaken"] = {
					13927, -- [1]
				},
				["EnergyGain"] = {
					60, -- [1]
				},
				["HealingTaken"] = {
					11765, -- [1]
				},
				["Overhealing"] = {
					1195, -- [1]
				},
				["ActiveTime"] = {
					39.11, -- [1]
				},
				["TimeDamage"] = {
					33.50000000000001, -- [1]
				},
				["ManaGain"] = {
					2435, -- [1]
				},
				["HOT_Time"] = {
					15, -- [1]
				},
				["Damage"] = {
					145102, -- [1]
				},
			},
			["enClass"] = "DRUID",
			["unit"] = "Druidwarr",
			["level"] = 80,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[49] = 7.358517062210364,
				[36] = 6.680943687684314,
				[29] = 7.091700603847774,
				[30] = 4.195337733464401,
				[46] = 4.195337733464401,
				[13] = 4.195337733464401,
				[9] = 6.944249403173711,
				[7] = 4.195337733464401,
				[10] = 24.52253896924589,
				[41] = 7.098722089594158,
				[22] = 6.666900716191546,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 3,
			["LastDamageTaken"] = 1978,
			["LastAbility"] = 1138848.611,
			["Owner"] = false,
			["LastEventHealth"] = {
				"20120 (70%)", -- [1]
				"20120 (70%)", -- [2]
				"20120 (70%)", -- [3]
				"20120 (70%)", -- [4]
				"20120 (70%)", -- [5]
				"20120 (70%)", -- [6]
				"21315 (74%)", -- [7]
				"21315 (74%)", -- [8]
				"21315 (74%)", -- [9]
				"26322 (92%)", -- [10]
				"26322 (92%)", -- [11]
				"26322 (92%)", -- [12]
				"27670 (97%)", -- [13]
				"27670 (97%)", -- [14]
				"27670 (97%)", -- [15]
				"27670 (97%)", -- [16]
				"27670 (97%)", -- [17]
				"27670 (97%)", -- [18]
				"27670 (97%)", -- [19]
				"27670 (97%)", -- [20]
				"27670 (97%)", -- [21]
				"27670 (97%)", -- [22]
				"25771 (90%)", -- [23]
				"25771 (90%)", -- [24]
				"25771 (90%)", -- [25]
				"25771 (90%)", -- [26]
				"25771 (90%)", -- [27]
				"25771 (90%)", -- [28]
				"25771 (90%)", -- [29]
				"24946 (87%)", -- [30]
				"24946 (87%)", -- [31]
				"24946 (87%)", -- [32]
				"24946 (87%)", -- [33]
				"24946 (87%)", -- [34]
				"24946 (87%)", -- [35]
				"24946 (87%)", -- [36]
				"23043 (80%)", -- [37]
				"23043 (80%)", -- [38]
				"23043 (80%)", -- [39]
				"23043 (80%)", -- [40]
				"23043 (80%)", -- [41]
				"21021 (73%)", -- [42]
				"21021 (73%)", -- [43]
				"21021 (73%)", -- [44]
				"21021 (73%)", -- [45]
				"22216 (77%)", -- [46]
				"22216 (77%)", -- [47]
				"22216 (77%)", -- [48]
				"22216 (77%)", -- [49]
				"20120 (70%)", -- [50]
			},
			["NextEventNum"] = 13,
			["LastEventHealthNum"] = {
				70.63614660862238, -- [1]
				70.63614660862238, -- [2]
				70.63614660862238, -- [3]
				70.63614660862238, -- [4]
				70.63614660862238, -- [5]
				70.63614660862238, -- [6]
				74.83148434208678, -- [7]
				74.83148434208678, -- [8]
				74.83148434208678, -- [9]
				92.40977390815897, -- [10]
				92.40977390815897, -- [11]
				92.40977390815897, -- [12]
				97.14225530122174, -- [13]
				97.14225530122174, -- [14]
				97.14225530122174, -- [15]
				97.14225530122174, -- [16]
				97.14225530122174, -- [17]
				97.14225530122174, -- [18]
				97.14225530122174, -- [19]
				97.14225530122174, -- [20]
				97.14225530122174, -- [21]
				97.14225530122174, -- [22]
				90.47535458503019, -- [23]
				90.47535458503019, -- [24]
				90.47535458503019, -- [25]
				90.47535458503019, -- [26]
				90.47535458503019, -- [27]
				90.47535458503019, -- [28]
				90.47535458503019, -- [29]
				87.57899171464682, -- [30]
				87.57899171464682, -- [31]
				87.57899171464682, -- [32]
				87.57899171464682, -- [33]
				87.57899171464682, -- [34]
				87.57899171464682, -- [35]
				87.57899171464682, -- [36]
				80.8980480269625, -- [37]
				80.8980480269625, -- [38]
				80.8980480269625, -- [39]
				80.8980480269625, -- [40]
				80.8980480269625, -- [41]
				73.79932593736835, -- [42]
				73.79932593736835, -- [43]
				73.79932593736835, -- [44]
				73.79932593736835, -- [45]
				77.99466367083275, -- [46]
				77.99466367083275, -- [47]
				77.99466367083275, -- [48]
				77.99466367083275, -- [49]
				70.63614660862238, -- [50]
			},
			["LastEvents"] = {
				"Druidwarr Mangle (Cat) Headless Horseman Crit -8500 (Physical)", -- [1]
				"Druidwarr Melee Headless Horseman Hit -1238 (Physical)", -- [2]
				"Druidwarr Melee Headless Horseman Crit -2754 (Physical)", -- [3]
				"Headless Horseman Melee Druidwarr Dodge", -- [4]
				"Druidwarr Melee Headless Horseman Hit -1201 (Physical)", -- [5]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -3895 (Physical)", -- [6]
				"Druidwarr Improved Leader of the Pack Druidwarr Tick +1195", -- [7]
				"Druidwarr Melee Headless Horseman Crit -2706 (Physical)", -- [8]
				"Headless Horseman Melee Druidwarr Hit -1978 (Physical)", -- [9]
				"Trolopresor Healing Wave Druidwarr Hit +6985", -- [10]
				"Druidwarr Melee Headless Horseman Hit -1235 (Physical)", -- [11]
				"Druidwarr Melee Headless Horseman Immune", -- [12]
				"Druidwarr Improved Leader of the Pack Druidwarr Tick +1195", -- [13]
				"Druidwarr Mangle (Cat) Headless Horseman Crit -6932 (Physical)", -- [14]
				"Druidwarr Melee Headless Horseman Hit -1074 (Physical)", -- [15]
				"Druidwarr Mangle (Cat) Headless Horseman Crit -7205 (Physical)", -- [16]
				"Druidwarr Melee Headless Horseman Crit -2351 (Physical)", -- [17]
				"Headless Horseman Melee Druidwarr Dodge", -- [18]
				"Druidwarr Melee Headless Horseman Crit -3126 (Physical)", -- [19]
				"Druidwarr Mangle (Cat) Headless Horseman Crit -9532 (Physical)", -- [20]
				"Druidwarr Melee Headless Horseman Crit -3190 (Physical)", -- [21]
				"Headless Horseman Melee Druidwarr Hit -1899 (Physical)", -- [22]
				"Druidwarr Melee Headless Horseman Hit -1536 (Physical)", -- [23]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -4582 (Physical)", -- [24]
				"Druidwarr Melee Headless Horseman Hit -1498 (Physical)", -- [25]
				"Druidwarr Melee Headless Horseman Immune", -- [26]
				"Druidwarr Melee Headless Horseman Immune", -- [27]
				"Druidwarr Melee Headless Horseman Immune", -- [28]
				"Headless Horseman Melee Druidwarr Hit -2020 (Physical)", -- [29]
				"Druidwarr Improved Leader of the Pack Druidwarr Tick +1195", -- [30]
				"Druidwarr Melee Headless Horseman Crit -2970 (Physical)", -- [31]
				"Druidwarr Mangle (Cat) Headless Horseman Crit -9026 (Physical)", -- [32]
				"Druidwarr Melee Headless Horseman Crit -3003 (Physical)", -- [33]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -4146 (Physical)", -- [34]
				"Druidwarr Melee Headless Horseman Crit -2987 (Physical)", -- [35]
				"Headless Horseman Melee Druidwarr Hit -1903 (Physical)", -- [36]
				"Druidwarr Melee Headless Horseman Crit -2959 (Physical)", -- [37]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -4111 (Physical)", -- [38]
				"Druidwarr Melee Headless Horseman Hit -1247 (Physical)", -- [39]
				"Druidwarr Mangle (Cat) Headless Horseman Hit -3834 (Physical)", -- [40]
				"Headless Horseman Melee Druidwarr Hit -2022 (Physical)", -- [41]
				"Druidwarr Melee Headless Horseman Crit -2717 (Physical)", -- [42]
				"Druidwarr Melee Headless Horseman Hit -1246 (Physical)", -- [43]
				"Druidwarr Melee Headless Horseman Immune", -- [44]
				"Druidwarr Rake Headless Horseman Immune (Physical)", -- [45]
				"Druidwarr Improved Leader of the Pack Druidwarr Tick +1195", -- [46]
				"Druidwarr Melee Head of the Horseman Crit -2723 (Physical)", -- [47]
				"Druidwarr Mangle (Cat) Head of the Horseman Crit -8514 (Physical)", -- [48]
				"Headless Horseman Melee Druidwarr Hit -2096 (Physical)", -- [49]
				"Druidwarr Melee Headless Horseman Crit -2741 (Physical)", -- [50]
			},
			["Name"] = "Druidwarr",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				true, -- [29]
				true, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				true, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138844.053, -- [1]
				1138844.717, -- [2]
				1138845.616, -- [3]
				1138845.79, -- [4]
				1138846.468, -- [5]
				1138847.076, -- [6]
				1138847.206, -- [7]
				1138847.206, -- [8]
				1138847.651, -- [9]
				1138847.765, -- [10]
				1138847.937, -- [11]
				1138848.611, -- [12]
				1138820.829, -- [13]
				1138820.83, -- [14]
				1138821.583, -- [15]
				1138822.147, -- [16]
				1138822.46, -- [17]
				1138822.461, -- [18]
				1138823.616, -- [19]
				1138824.316, -- [20]
				1138824.481, -- [21]
				1138824.482, -- [22]
				1138825.381, -- [23]
				1138825.65, -- [24]
				1138826.41, -- [25]
				1138827.192, -- [26]
				1138828.262, -- [27]
				1138829.163, -- [28]
				1138832.912, -- [29]
				1138833.081, -- [30]
				1138833.081, -- [31]
				1138833.383, -- [32]
				1138834.054, -- [33]
				1138834.52, -- [34]
				1138834.787, -- [35]
				1138834.944, -- [36]
				1138835.547, -- [37]
				1138835.698, -- [38]
				1138836.409, -- [39]
				1138836.739, -- [40]
				1138836.996, -- [41]
				1138837.156, -- [42]
				1138837.904, -- [43]
				1138838.678, -- [44]
				1138838.819, -- [45]
				1138840.65, -- [46]
				1138840.65, -- [47]
				1138840.784, -- [48]
				1138843.553, -- [49]
				1138843.953, -- [50]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 15,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1195,
									["min"] = 1195,
									["count"] = 1,
									["amount"] = 1195,
								},
							},
							["count"] = 1,
							["amount"] = 1195,
						},
					},
					["TimeSpent"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.55,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 2.94,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.7,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.48,
								},
							},
							["amount"] = 5.18,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["HOT_Time"] = 3,
					["ActiveTime"] = 8.119999999999999,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Damage"] = 29276,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2398,
									["min"] = 2272,
									["count"] = 3,
									["amount"] = 6958,
								},
							},
							["count"] = 3,
							["amount"] = 6958,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8118,
									["min"] = 7092,
									["count"] = 2,
									["amount"] = 15210,
								},
								["Crit (Blocked)"] = {
									["max"] = 7108,
									["min"] = 7108,
									["count"] = 1,
									["amount"] = 7108,
								},
							},
							["count"] = 3,
							["amount"] = 22318,
						},
					},
					["DamagedWho"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2398,
								},
								["Mangle (Cat)"] = {
									["count"] = 8118,
								},
							},
							["amount"] = 10516,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4560,
								},
								["Mangle (Cat)"] = {
									["count"] = 14200,
								},
							},
							["amount"] = 18760,
						},
					},
					["ManaGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 487,
								},
							},
							["amount"] = 487,
						},
					},
					["TimeDamage"] = 8.119999999999999,
					["TimeDamaging"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.55,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 2.94,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.7,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.48,
								},
							},
							["amount"] = 5.18,
						},
					},
					["ManaGain"] = 487,
					["ElementDone"] = {
						["Melee"] = 6958,
						["Physical"] = 22318,
					},
					["Overhealing"] = 1195,
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 13927,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 26,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 13927,
					},
					["DOT_Time"] = 0,
					["Damage"] = 115826,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 5.61,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 45549,
						["Physical"] = 70277,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2723,
								},
								["Mangle (Cat)"] = {
									["count"] = 8514,
								},
							},
							["amount"] = 11237,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
					},
					["EnergyGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 80,
					},
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1948,
								},
							},
							["amount"] = 1948,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
					},
					["EnergyGain"] = 60,
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 1948,
								},
							},
							["amount"] = 1948,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1195,
									["min"] = 1195,
									["count"] = 4,
									["amount"] = 4780,
								},
							},
							["count"] = 4,
							["amount"] = 4780,
						},
					},
					["WhoHealed"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
					},
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ActiveTime"] = 30.99,
					["Healing"] = 4780,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9532,
									["min"] = 6932,
									["count"] = 6,
									["amount"] = 49709,
								},
								["Hit"] = {
									["max"] = 4582,
									["min"] = 3834,
									["count"] = 5,
									["amount"] = 20568,
								},
							},
							["count"] = 11,
							["amount"] = 70277,
						},
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1498,
									["min"] = 1201,
									["count"] = 2,
									["amount"] = 2699,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3190,
									["min"] = 2351,
									["count"] = 12,
									["amount"] = 34227,
								},
								["Hit"] = {
									["max"] = 1536,
									["min"] = 1047,
									["count"] = 7,
									["amount"] = 8623,
								},
							},
							["count"] = 26,
							["amount"] = 45549,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 11765,
					["RageGain"] = 0,
					["TimeDamage"] = 25.38,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
					},
					["ManaGain"] = 1948,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 13927,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 26,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 13927,
					},
					["DOT_Time"] = 0,
					["Damage"] = 115826,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 5.61,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 45549,
						["Physical"] = 70277,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2723,
								},
								["Mangle (Cat)"] = {
									["count"] = 8514,
								},
							},
							["amount"] = 11237,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
					},
					["EnergyGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 80,
					},
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1948,
								},
							},
							["amount"] = 1948,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
					},
					["EnergyGain"] = 60,
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 1948,
								},
							},
							["amount"] = 1948,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1195,
									["min"] = 1195,
									["count"] = 4,
									["amount"] = 4780,
								},
							},
							["count"] = 4,
							["amount"] = 4780,
						},
					},
					["WhoHealed"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
					},
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ActiveTime"] = 30.99,
					["Healing"] = 4780,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9532,
									["min"] = 6932,
									["count"] = 6,
									["amount"] = 49709,
								},
								["Hit"] = {
									["max"] = 4582,
									["min"] = 3834,
									["count"] = 5,
									["amount"] = 20568,
								},
							},
							["count"] = 11,
							["amount"] = 70277,
						},
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1498,
									["min"] = 1201,
									["count"] = 2,
									["amount"] = 2699,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3190,
									["min"] = 2351,
									["count"] = 12,
									["amount"] = 34227,
								},
								["Hit"] = {
									["max"] = 1536,
									["min"] = 1047,
									["count"] = 7,
									["amount"] = 8623,
								},
							},
							["count"] = 26,
							["amount"] = 45549,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 11765,
					["RageGain"] = 0,
					["TimeDamage"] = 25.38,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
					},
					["ManaGain"] = 1948,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.55,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 2.94,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.7,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.48,
								},
							},
							["amount"] = 5.18,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
					},
					["Overhealing"] = 1195,
					["ElementTaken"] = {
						["Melee"] = 13927,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 145102,
					["TimeHeal"] = 5.61,
					["ElementDone"] = {
						["Melee"] = 52507,
						["Physical"] = 92595,
					},
					["ManaGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2435,
								},
							},
							["amount"] = 2435,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13927,
								},
							},
							["amount"] = 13927,
						},
					},
					["EnergyGainedFrom"] = {
						["Druidwarr"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 80,
						["Physical"] = 15,
					},
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1195,
									["min"] = 1195,
									["count"] = 1,
									["amount"] = 1195,
								},
							},
							["count"] = 1,
							["amount"] = 1195,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 2435,
								},
							},
							["amount"] = 2435,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 39.11,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1195,
									["min"] = 1195,
									["count"] = 4,
									["amount"] = 4780,
								},
							},
							["count"] = 4,
							["amount"] = 4780,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 3,
								},
							},
							["amount"] = 12,
						},
					},
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Druidwarr"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["EnergyGain"] = 60,
					["Healing"] = 4780,
					["DamageTaken"] = 13927,
					["WhoHealed"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 4780,
								},
							},
							["amount"] = 4780,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
					},
					["Attacks"] = {
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 7108,
									["min"] = 7108,
									["count"] = 1,
									["amount"] = 7108,
								},
								["Crit"] = {
									["max"] = 9532,
									["min"] = 6932,
									["count"] = 8,
									["amount"] = 64919,
								},
								["Hit"] = {
									["max"] = 4582,
									["min"] = 3834,
									["count"] = 5,
									["amount"] = 20568,
								},
							},
							["count"] = 14,
							["amount"] = 92595,
						},
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1498,
									["min"] = 1201,
									["count"] = 2,
									["amount"] = 2699,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3190,
									["min"] = 2272,
									["count"] = 15,
									["amount"] = 41185,
								},
								["Hit"] = {
									["max"] = 1536,
									["min"] = 1047,
									["count"] = 7,
									["amount"] = 8623,
								},
							},
							["count"] = 29,
							["amount"] = 52507,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 11765,
					["HOT_Time"] = 15,
					["TimeDamage"] = 33.50000000000001,
					["TimeDamaging"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.55,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 2.94,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.7,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.48,
								},
							},
							["amount"] = 5.18,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Mangle (Cat)"] = {
									["count"] = 3.49,
								},
								["Melee"] = {
									["count"] = 21.62,
								},
								["Rake"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 25.25000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 0.13,
						},
					},
					["ManaGain"] = 2435,
					["DamagedWho"] = {
						["Fallen Champion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2398,
								},
								["Mangle (Cat)"] = {
									["count"] = 8118,
								},
							},
							["amount"] = 10516,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4560,
								},
								["Mangle (Cat)"] = {
									["count"] = 14200,
								},
							},
							["amount"] = 18760,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 42826,
								},
								["Mangle (Cat)"] = {
									["count"] = 61763,
								},
							},
							["amount"] = 104589,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2723,
								},
								["Mangle (Cat)"] = {
									["count"] = 8514,
								},
							},
							["amount"] = 11237,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 29,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 15,
						},
					},
				},
			},
			["UnitLockout"] = 1604180015,
			["LastActive"] = 1604180066,
		},
		["Magma Totem VII <Trolopresor>"] = {
			["GUID"] = "0xF1300079BF000090",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"MISC", -- [9]
			},
			["TimeWindows"] = {
				["Damage"] = {
					6023, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["TimeDamage"] = {
					17.55, -- [1]
				},
				["ActiveTime"] = {
					17.55, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 2,
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-14.99799999990501, -- [1]
						-12.99799999990501, -- [2]
						-11.08799999998882, -- [3]
						-8.982000000076369, -- [4]
						-7.005000000121072, -- [5]
						-5.022000000113621, -- [6]
						0, -- [7]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
					},
					["Messages"] = {
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [1]
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [2]
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Hit -737 (Fire)", -- [3]
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Hit -737 (Fire)", -- [4]
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Crit -1539 (Fire)", -- [5]
						"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [6]
						"Magma Totem VII <Trolopresor> dies.", -- [7]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["DeathAt"] = 1604180074,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"MISC", -- [7]
					},
				}, -- [1]
			},
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["DeathCount"] = 1604180072,
				["ActiveTime"] = 1604180067,
				["OVERALL"] = 1604180072,
				["TimeDamage"] = 1604180067,
				["Damage"] = 1604180065,
			},
			["Owner"] = "Trolopresor",
			["LastAbility"] = 1138849.751,
			["NextEventNum"] = 10,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
			},
			["LastEvents"] = {
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Crit -1505 (Fire)", -- [1]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Crit -1505 (Fire)", -- [2]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [3]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [4]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Hit -737 (Fire)", -- [5]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Hit -737 (Fire)", -- [6]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Crit -1539 (Fire)", -- [7]
				"Magma Totem VII <Trolopresor> Magma Totem Headless Horseman Immune (Fire)", -- [8]
				"Magma Totem VII <Trolopresor> dies.", -- [9]
			},
			["Name"] = "Magma Totem VII",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
			},
			["LastEventTimes"] = {
				1138835.698, -- [1]
				1138837.751, -- [2]
				1138839.775, -- [3]
				1138841.775, -- [4]
				1138843.685, -- [5]
				1138845.791, -- [6]
				1138847.768, -- [7]
				1138849.751, -- [8]
				1138854.773, -- [9]
			},
			["Fights"] = {
				["Fight1"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementDone"] = {
						["Fire"] = 6023,
					},
					["DeathCount"] = 1,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
					},
					["TimeDamage"] = 17.55,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["Attacks"] = {
						["Magma Totem"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1539,
									["min"] = 1505,
									["count"] = 3,
									["amount"] = 4549,
								},
								["Hit"] = {
									["max"] = 737,
									["min"] = 737,
									["count"] = 2,
									["amount"] = 1474,
								},
							},
							["count"] = 8,
							["amount"] = 6023,
						},
					},
					["ActiveTime"] = 17.55,
					["Damage"] = 6023,
				},
				["LastFightData"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementDone"] = {
						["Fire"] = 6023,
					},
					["DeathCount"] = 1,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
					},
					["TimeDamage"] = 17.55,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["Attacks"] = {
						["Magma Totem"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1539,
									["min"] = 1505,
									["count"] = 3,
									["amount"] = 4549,
								},
								["Hit"] = {
									["max"] = 737,
									["min"] = 737,
									["count"] = 2,
									["amount"] = 1474,
								},
							},
							["count"] = 8,
							["amount"] = 6023,
						},
					},
					["ActiveTime"] = 17.55,
					["Damage"] = 6023,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementDone"] = {
						["Fire"] = 6023,
					},
					["DeathCount"] = 1,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 6023,
								},
							},
							["amount"] = 6023,
						},
					},
					["TimeDamage"] = 17.55,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Magma Totem"] = {
									["count"] = 17.55,
								},
							},
							["amount"] = 17.55,
						},
					},
					["Attacks"] = {
						["Magma Totem"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1539,
									["min"] = 1505,
									["count"] = 3,
									["amount"] = 4549,
								},
								["Hit"] = {
									["max"] = 737,
									["min"] = 737,
									["count"] = 2,
									["amount"] = 1474,
								},
							},
							["count"] = 8,
							["amount"] = 6023,
						},
					},
					["ActiveTime"] = 17.55,
					["Damage"] = 6023,
				},
			},
			["UnitLockout"] = 1604180072,
			["LastActive"] = 1604180067,
		},
		["Praxia"] = {
			["GUID"] = "0x070000000001DBA5",
			["LastEventHealth"] = {
				"27682 (100%)", -- [1]
				"27682 (100%)", -- [2]
				"27682 (100%)", -- [3]
				"27682 (100%)", -- [4]
				"27682 (100%)", -- [5]
				"27682 (100%)", -- [6]
				"27682 (100%)", -- [7]
				"27682 (100%)", -- [8]
				"27682 (100%)", -- [9]
				"27682 (100%)", -- [10]
				"27682 (100%)", -- [11]
				"27682 (100%)", -- [12]
				"27682 (100%)", -- [13]
				"27682 (100%)", -- [14]
				"27682 (100%)", -- [15]
				"27682 (100%)", -- [16]
				"27682 (100%)", -- [17]
				"27682 (100%)", -- [18]
				"27682 (100%)", -- [19]
				"27682 (100%)", -- [20]
				"27682 (100%)", -- [21]
				"27682 (100%)", -- [22]
				"27682 (100%)", -- [23]
				"27682 (100%)", -- [24]
				"27682 (100%)", -- [25]
				"27682 (100%)", -- [26]
				"27682 (100%)", -- [27]
				"27682 (100%)", -- [28]
				"27682 (100%)", -- [29]
				"27682 (100%)", -- [30]
				"27682 (100%)", -- [31]
				"27682 (100%)", -- [32]
				"27682 (100%)", -- [33]
				"27682 (100%)", -- [34]
				"27682 (100%)", -- [35]
				"27682 (100%)", -- [36]
				"27682 (100%)", -- [37]
				"27682 (100%)", -- [38]
				"27682 (100%)", -- [39]
				"27682 (100%)", -- [40]
				"27682 (100%)", -- [41]
				"27682 (100%)", -- [42]
				"27682 (100%)", -- [43]
				"27682 (100%)", -- [44]
				"27682 (100%)", -- [45]
				"27682 (100%)", -- [46]
				"27682 (100%)", -- [47]
				"27682 (100%)", -- [48]
				"27682 (100%)", -- [49]
				"27682 (100%)", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"HEAL", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Overhealing"] = {
					6972, -- [1]
				},
				["HOT_Time"] = {
					18, -- [1]
				},
				["ActiveTime"] = {
					55.67000000000002, -- [1]
				},
				["TimeDamage"] = {
					55.67000000000002, -- [1]
				},
				["ManaGain"] = {
					2860, -- [1]
				},
				["DOT_Time"] = {
					42, -- [1]
				},
				["Damage"] = {
					301199, -- [1]
				},
			},
			["enClass"] = "HUNTER",
			["unit"] = "Praxia",
			["level"] = 80,
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[26] = 4.197673578498663,
				[13] = 4.197673578498663,
				[49] = 4.197673578498663,
			},
			["type"] = "Self",
			["FightsSaved"] = 3,
			["TimeLast"] = {
				["ManaGain"] = 1604180090,
				["TimeDamage"] = 1604180068,
				["HOT_Time"] = 1604180065,
				["ActiveTime"] = 1604180068,
				["Overhealing"] = 1604180065,
				["OVERALL"] = 1604180090,
				["DOT_Time"] = 1604180064,
				["Damage"] = 1604180068,
			},
			["LastAbility"] = 1138851.195,
			["Owner"] = false,
			["Pet"] = {
				"Stormfang <Praxia>", -- [1]
			},
			["NextEventNum"] = 36,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Praxia Auto Shot Headless Horseman Crit -6569 (Physical)", -- [1]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -880 (Physical)", -- [2]
				"Praxia Serpent Sting (DoT) Headless Horseman Tick -846 (Nature)", -- [3]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -880 (Physical)", -- [4]
				"Praxia Auto Shot Headless Horseman Crit -6534 (Physical)", -- [5]
				"Praxia Kill Shot Headless Horseman Crit -25590 (Physical)", -- [6]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [7]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [8]
				"Praxia Serpent Sting Headless Horseman Immune (Nature)", -- [9]
				"Praxia Auto Shot Headless Horseman Immune (Physical)", -- [10]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [11]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [12]
				"Praxia Improved Leader of the Pack Praxia Tick +1162 (1162 overheal)", -- [13]
				"Praxia Silencing Shot Head of the Horseman Crit -3423 (Physical)", -- [14]
				"Praxia Auto Shot Headless Horseman Immune (Physical)", -- [15]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [16]
				"Praxia Serpent Sting (DoT) Headless Horseman Tick -846 (Nature)", -- [17]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -880 (Physical)", -- [18]
				"Praxia Auto Shot Headless Horseman Crit -5841 (Physical)", -- [19]
				"Praxia Chimera Shot Headless Horseman Crit -9329 (Nature)", -- [20]
				"Praxia Chimera Shot - Serpent Headless Horseman Hit -2220 (Nature)", -- [21]
				"Praxia Auto Shot Headless Horseman Crit -6182 (Physical)", -- [22]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -454 (Physical)", -- [23]
				"Praxia Serpent Sting (DoT) Headless Horseman Tick -793 (Nature)", -- [24]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -454 (Physical)", -- [25]
				"Praxia Improved Leader of the Pack Praxia Tick +1162 (1162 overheal)", -- [26]
				"Praxia Auto Shot Headless Horseman Crit -6418 (Physical)", -- [27]
				"Praxia Kill Shot Headless Horseman Crit -28289 (Physical)", -- [28]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [29]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [30]
				"Praxia Serpent Sting Headless Horseman Immune (Nature)", -- [31]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [32]
				"Praxia Auto Shot Head of the Horseman Crit -6614 (Physical)", -- [33]
				"Praxia Aimed Shot Head of the Horseman Crit -10461 (Physical)", -- [34]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [35]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [36]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [37]
				"Praxia Steady Shot Head of the Horseman Crit -5669 (Physical)", -- [38]
				"Praxia Serpent Sting Headless Horseman Immune (Nature)", -- [39]
				"Praxia Auto Shot Head of the Horseman Hit -3329 (Physical)", -- [40]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [41]
				"Praxia Piercing Shots Headless Horseman Immune (Physical)", -- [42]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -914 (Physical)", -- [43]
				"Praxia Chimera Shot Headless Horseman Crit -9612 (Nature)", -- [44]
				"Praxia Serpent Sting (DoT) Headless Horseman Tick -846 (Nature)", -- [45]
				"Praxia Auto Shot Headless Horseman Hit -2993 (Physical)", -- [46]
				"Praxia Chimera Shot - Serpent Headless Horseman Hit -2465 (Nature)", -- [47]
				"Praxia Piercing Shots (DoT) Headless Horseman Tick -468 (Physical)", -- [48]
				"Praxia Improved Leader of the Pack Praxia Tick +1162 (1162 overheal)", -- [49]
				"Praxia Aimed Shot Headless Horseman Crit -9659 (Physical)", -- [50]
			},
			["Name"] = "Praxia",
			["LastEventTimes"] = {
				1138835.548, -- [1]
				1138836.121, -- [2]
				1138836.409, -- [3]
				1138837.156, -- [4]
				1138837.905, -- [5]
				1138837.907, -- [6]
				1138838.238, -- [7]
				1138839.077, -- [8]
				1138839.465, -- [9]
				1138839.911, -- [10]
				1138840.212, -- [11]
				1138841.141, -- [12]
				1138841.447, -- [13]
				1138841.448, -- [14]
				1138842.19, -- [15]
				1138842.251, -- [16]
				1138842.405, -- [17]
				1138843.137, -- [18]
				1138844.476, -- [19]
				1138845.119, -- [20]
				1138845.79, -- [21]
				1138846.109, -- [22]
				1138846.109, -- [23]
				1138846.468, -- [24]
				1138847.207, -- [25]
				1138847.767, -- [26]
				1138847.767, -- [27]
				1138847.939, -- [28]
				1138848.247, -- [29]
				1138849.31, -- [30]
				1138849.521, -- [31]
				1138850.162, -- [32]
				1138850.991, -- [33]
				1138850.993, -- [34]
				1138851.195, -- [35]
				1138829.04, -- [36]
				1138830.072, -- [37]
				1138830.357, -- [38]
				1138830.358, -- [39]
				1138830.484, -- [40]
				1138830.983, -- [41]
				1138832.025, -- [42]
				1138833.082, -- [43]
				1138833.386, -- [44]
				1138833.387, -- [45]
				1138833.51, -- [46]
				1138833.765, -- [47]
				1138834.521, -- [48]
				1138835.112, -- [49]
				1138835.112, -- [50]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 14161,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 14161,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 14161,
								},
							},
							["amount"] = 14161,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 5.3,
								},
							},
							["amount"] = 5.3,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 5.3,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7265,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 14161,
								},
							},
							["count"] = 2,
							["amount"] = 14161,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 5.3,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 5.3,
								},
							},
							["amount"] = 5.3,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Aspect of the Viper"] = {
									["count"] = 2860,
								},
							},
							["amount"] = 2860,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Aspect of the Viper"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 2860,
								},
							},
							["amount"] = 2860,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 2860,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 15,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1162,
									["min"] = 1162,
									["count"] = 1,
									["amount"] = 1162,
								},
							},
							["count"] = 1,
							["amount"] = 1162,
						},
					},
					["Overhealing"] = 1162,
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2.58,
								},
								["Auto Shot"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.08,
						},
					},
					["ActiveTime"] = 6.08,
					["HOT_Time"] = 3,
					["ElementDone"] = {
						["Arcane"] = 12008,
						["Physical"] = 7843,
					},
					["ElementHitsDone"] = {
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2894,
								},
							},
							["amount"] = 2894,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 9114,
								},
								["Auto Shot"] = {
									["count"] = 7843,
								},
							},
							["amount"] = 16957,
						},
					},
					["TimeDamage"] = 6.08,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2.58,
								},
								["Auto Shot"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.08,
						},
					},
					["Attacks"] = {
						["Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (Blocked)"] = {
									["max"] = 7843,
									["min"] = 7843,
									["count"] = 1,
									["amount"] = 7843,
								},
							},
							["count"] = 1,
							["amount"] = 7843,
						},
						["Volley"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3038,
									["min"] = 2894,
									["count"] = 4,
									["amount"] = 12008,
								},
							},
							["count"] = 4,
							["amount"] = 12008,
						},
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Damage"] = 19851,
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 15,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Tick"] = {
									["count"] = 9,
								},
							},
							["amount"] = 48,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 17,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 42,
					["Damage"] = 238028,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 180164,
						["Arcane"] = 5156,
						["Nature"] = 52708,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 5669,
								},
								["Aimed Shot"] = {
									["count"] = 10461,
								},
								["Silencing Shot"] = {
									["count"] = 3423,
								},
								["Auto Shot"] = {
									["count"] = 16734,
								},
							},
							["amount"] = 36287,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Physical"] = 120,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1162,
									["min"] = 1162,
									["count"] = 5,
									["amount"] = 5810,
								},
							},
							["count"] = 5,
							["amount"] = 5810,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 5810,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 33.84999999999999,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 914,
									["min"] = 454,
									["count"] = 9,
									["amount"] = 6352,
								},
							},
							["count"] = 9,
							["amount"] = 6352,
						},
						["Chimera Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10447,
									["min"] = 9329,
									["count"] = 3,
									["amount"] = 29388,
								},
							},
							["count"] = 3,
							["amount"] = 29388,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 881,
									["min"] = 793,
									["count"] = 5,
									["amount"] = 4212,
								},
							},
							["count"] = 5,
							["amount"] = 4212,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 6067,
									["min"] = 5841,
									["count"] = 2,
									["amount"] = 11908,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6886,
									["min"] = 6182,
									["count"] = 9,
									["amount"] = 59317,
								},
								["Hit"] = {
									["max"] = 3329,
									["min"] = 2993,
									["count"] = 2,
									["amount"] = 6322,
								},
							},
							["count"] = 16,
							["amount"] = 77547,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5156,
									["min"] = 5156,
									["count"] = 1,
									["amount"] = 5156,
								},
							},
							["count"] = 1,
							["amount"] = 5156,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3531,
									["min"] = 3423,
									["count"] = 2,
									["amount"] = 6954,
								},
							},
							["count"] = 2,
							["amount"] = 6954,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 28289,
									["min"] = 25590,
									["count"] = 2,
									["amount"] = 53879,
								},
							},
							["count"] = 2,
							["amount"] = 53879,
						},
						["Steady Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5669,
									["min"] = 5669,
									["count"] = 1,
									["amount"] = 5669,
								},
							},
							["count"] = 1,
							["amount"] = 5669,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 9643,
									["min"] = 9643,
									["count"] = 1,
									["amount"] = 9643,
								},
								["Crit"] = {
									["max"] = 10461,
									["min"] = 9659,
									["count"] = 2,
									["amount"] = 20120,
								},
							},
							["count"] = 3,
							["amount"] = 29763,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5860,
									["min"] = 5860,
									["count"] = 1,
									["amount"] = 5860,
								},
								["Hit"] = {
									["max"] = 2465,
									["min"] = 2220,
									["count"] = 2,
									["amount"] = 4685,
								},
							},
							["count"] = 3,
							["amount"] = 10545,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5697,
									["min"] = 5697,
									["count"] = 1,
									["amount"] = 5697,
								},
								["Hit"] = {
									["max"] = 2866,
									["min"] = 2866,
									["count"] = 1,
									["amount"] = 2866,
								},
							},
							["count"] = 2,
							["amount"] = 8563,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 33.84999999999999,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 15,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Tick"] = {
									["count"] = 9,
								},
							},
							["amount"] = 48,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 17,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 42,
					["Damage"] = 238028,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 180164,
						["Arcane"] = 5156,
						["Nature"] = 52708,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 5669,
								},
								["Aimed Shot"] = {
									["count"] = 10461,
								},
								["Silencing Shot"] = {
									["count"] = 3423,
								},
								["Auto Shot"] = {
									["count"] = 16734,
								},
							},
							["amount"] = 36287,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Physical"] = 120,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1162,
									["min"] = 1162,
									["count"] = 5,
									["amount"] = 5810,
								},
							},
							["count"] = 5,
							["amount"] = 5810,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 5810,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 33.84999999999999,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 914,
									["min"] = 454,
									["count"] = 9,
									["amount"] = 6352,
								},
							},
							["count"] = 9,
							["amount"] = 6352,
						},
						["Chimera Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10447,
									["min"] = 9329,
									["count"] = 3,
									["amount"] = 29388,
								},
							},
							["count"] = 3,
							["amount"] = 29388,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 881,
									["min"] = 793,
									["count"] = 5,
									["amount"] = 4212,
								},
							},
							["count"] = 5,
							["amount"] = 4212,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 6067,
									["min"] = 5841,
									["count"] = 2,
									["amount"] = 11908,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6886,
									["min"] = 6182,
									["count"] = 9,
									["amount"] = 59317,
								},
								["Hit"] = {
									["max"] = 3329,
									["min"] = 2993,
									["count"] = 2,
									["amount"] = 6322,
								},
							},
							["count"] = 16,
							["amount"] = 77547,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5156,
									["min"] = 5156,
									["count"] = 1,
									["amount"] = 5156,
								},
							},
							["count"] = 1,
							["amount"] = 5156,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3531,
									["min"] = 3423,
									["count"] = 2,
									["amount"] = 6954,
								},
							},
							["count"] = 2,
							["amount"] = 6954,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 28289,
									["min"] = 25590,
									["count"] = 2,
									["amount"] = 53879,
								},
							},
							["count"] = 2,
							["amount"] = 53879,
						},
						["Steady Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5669,
									["min"] = 5669,
									["count"] = 1,
									["amount"] = 5669,
								},
							},
							["count"] = 1,
							["amount"] = 5669,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 9643,
									["min"] = 9643,
									["count"] = 1,
									["amount"] = 9643,
								},
								["Crit"] = {
									["max"] = 10461,
									["min"] = 9659,
									["count"] = 2,
									["amount"] = 20120,
								},
							},
							["count"] = 3,
							["amount"] = 29763,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5860,
									["min"] = 5860,
									["count"] = 1,
									["amount"] = 5860,
								},
								["Hit"] = {
									["max"] = 2465,
									["min"] = 2220,
									["count"] = 2,
									["amount"] = 4685,
								},
							},
							["count"] = 3,
							["amount"] = 10545,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5697,
									["min"] = 5697,
									["count"] = 1,
									["amount"] = 5697,
								},
								["Hit"] = {
									["max"] = 2866,
									["min"] = 2866,
									["count"] = 1,
									["amount"] = 2866,
								},
							},
							["count"] = 2,
							["amount"] = 8563,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 33.84999999999999,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 135,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1162,
									["min"] = 1162,
									["count"] = 6,
									["amount"] = 6972,
								},
							},
							["count"] = 6,
							["amount"] = 6972,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2.58,
								},
								["Auto Shot"] = {
									["count"] = 13.47,
								},
							},
							["amount"] = 16.05,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 5.77,
								},
							},
							["amount"] = 5.77,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Aspect of the Viper"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 2860,
								},
							},
							["amount"] = 2860,
						},
					},
					["HOT_Time"] = 18,
					["ActiveTime"] = 55.67000000000002,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["Damage"] = 301199,
					["ManaGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Aspect of the Viper"] = {
									["count"] = 2860,
								},
							},
							["amount"] = 2860,
						},
					},
					["Overhealing"] = 6972,
					["DOTs"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Attacks"] = {
						["Piercing Shots (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 914,
									["min"] = 454,
									["count"] = 9,
									["amount"] = 6352,
								},
							},
							["count"] = 9,
							["amount"] = 6352,
						},
						["Wild Quiver Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5697,
									["min"] = 5697,
									["count"] = 1,
									["amount"] = 5697,
								},
								["Hit"] = {
									["max"] = 2866,
									["min"] = 2866,
									["count"] = 1,
									["amount"] = 2866,
								},
							},
							["count"] = 2,
							["amount"] = 8563,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 881,
									["min"] = 793,
									["count"] = 5,
									["amount"] = 4212,
								},
							},
							["count"] = 5,
							["amount"] = 4212,
						},
						["Volley"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3038,
									["min"] = 2894,
									["count"] = 4,
									["amount"] = 12008,
								},
							},
							["count"] = 4,
							["amount"] = 12008,
						},
						["Steady Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5669,
									["min"] = 5669,
									["count"] = 1,
									["amount"] = 5669,
								},
							},
							["count"] = 1,
							["amount"] = 5669,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5156,
									["min"] = 5156,
									["count"] = 1,
									["amount"] = 5156,
								},
							},
							["count"] = 1,
							["amount"] = 5156,
						},
						["Silencing Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3531,
									["min"] = 3423,
									["count"] = 2,
									["amount"] = 6954,
								},
							},
							["count"] = 2,
							["amount"] = 6954,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 28289,
									["min"] = 25590,
									["count"] = 2,
									["amount"] = 53879,
								},
							},
							["count"] = 2,
							["amount"] = 53879,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 7843,
									["min"] = 5841,
									["count"] = 3,
									["amount"] = 19751,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7926,
									["min"] = 6182,
									["count"] = 15,
									["amount"] = 102637,
								},
								["Hit"] = {
									["max"] = 3329,
									["min"] = 2993,
									["count"] = 2,
									["amount"] = 6322,
								},
							},
							["count"] = 23,
							["amount"] = 128710,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 9643,
									["min"] = 9643,
									["count"] = 1,
									["amount"] = 9643,
								},
								["Crit"] = {
									["max"] = 10461,
									["min"] = 9659,
									["count"] = 2,
									["amount"] = 20120,
								},
							},
							["count"] = 3,
							["amount"] = 29763,
						},
						["Chimera Shot - Serpent"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5860,
									["min"] = 5860,
									["count"] = 1,
									["amount"] = 5860,
								},
								["Hit"] = {
									["max"] = 2465,
									["min"] = 2220,
									["count"] = 2,
									["amount"] = 4685,
								},
							},
							["count"] = 3,
							["amount"] = 10545,
						},
						["Chimera Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10447,
									["min"] = 9329,
									["count"] = 3,
									["amount"] = 29388,
								},
							},
							["count"] = 3,
							["amount"] = 29388,
						},
						["Piercing Shots"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
					},
					["DOT_Time"] = 42,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 6352,
								},
								["Chimera Shot"] = {
									["count"] = 29388,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 4212,
								},
								["Auto Shot"] = {
									["count"] = 60813,
								},
								["Arcane Shot"] = {
									["count"] = 5156,
								},
								["Silencing Shot"] = {
									["count"] = 3531,
								},
								["Kill Shot"] = {
									["count"] = 53879,
								},
								["Aimed Shot"] = {
									["count"] = 19302,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 10545,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 8563,
								},
							},
							["amount"] = 201741,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 9114,
								},
								["Auto Shot"] = {
									["count"] = 37446,
								},
							},
							["amount"] = 46560,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 13717,
								},
							},
							["amount"] = 13717,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 5669,
								},
								["Aimed Shot"] = {
									["count"] = 10461,
								},
								["Silencing Shot"] = {
									["count"] = 3423,
								},
								["Auto Shot"] = {
									["count"] = 16734,
								},
							},
							["amount"] = 36287,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2894,
								},
							},
							["amount"] = 2894,
						},
					},
					["TimeDamage"] = 55.67000000000002,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Piercing Shots (DoT)"] = {
									["count"] = 4.94,
								},
								["Chimera Shot"] = {
									["count"] = 1.1,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 1.12,
								},
								["Auto Shot"] = {
									["count"] = 7.620000000000001,
								},
								["Arcane Shot"] = {
									["count"] = 0.35,
								},
								["Silencing Shot"] = {
									["count"] = 3.5,
								},
								["Kill Shot"] = {
									["count"] = 0.17,
								},
								["Serpent Sting"] = {
									["count"] = 0.76,
								},
								["Aimed Shot"] = {
									["count"] = 0.8899999999999999,
								},
								["Chimera Shot - Serpent"] = {
									["count"] = 1.12,
								},
								["Wild Quiver Auto Shot"] = {
									["count"] = 1.24,
								},
								["Piercing Shots"] = {
									["count"] = 8.669999999999998,
								},
							},
							["amount"] = 31.47999999999999,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 2.58,
								},
								["Auto Shot"] = {
									["count"] = 13.47,
								},
							},
							["amount"] = 16.05,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 5.77,
								},
							},
							["amount"] = 5.77,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 0.29,
								},
								["Aimed Shot"] = {
									["count"] = 0,
								},
								["Silencing Shot"] = {
									["count"] = 0.31,
								},
								["Auto Shot"] = {
									["count"] = 1.77,
								},
							},
							["amount"] = 2.37,
						},
						["Rat"] = {
							["Details"] = {
								["Volley"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 2860,
					["ElementDone"] = {
						["Physical"] = 231327,
						["Nature"] = 52708,
						["Arcane"] = 17164,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 26,
								},
								["Tick"] = {
									["count"] = 9,
								},
							},
							["amount"] = 55,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Immune"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 17,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
				},
			},
			["UnitLockout"] = 1604180012,
			["LastActive"] = 1604180090,
		},
		["Fallen Champion"] = {
			["GUID"] = "0xF130001958000049",
			["type"] = "Trivial",
			["FightsSaved"] = 3,
			["LastAttackedBy"] = "Druidwarr",
			["Owner"] = false,
			["enClass"] = "MOB",
			["LastDamageTaken"] = 8118,
			["LastAbility"] = 1138802.453,
			["LastDamageAbility"] = "Mangle (Cat)",
			["Name"] = "Fallen Champion",
			["LastActive"] = 1604180020,
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["WhoDamaged"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2398,
								},
								["Mangle (Cat)"] = {
									["count"] = 8118,
								},
							},
							["amount"] = 10516,
						},
					},
					["TimeSpent"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["TimeDamaging"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["WhoDamaged"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2398,
								},
								["Mangle (Cat)"] = {
									["count"] = 8118,
								},
							},
							["amount"] = 10516,
						},
					},
					["TimeSpent"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["TimeDamaging"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
				},
			},
			["level"] = 33,
			["UnitLockout"] = 1604180019,
			["LastFightIn"] = 0,
		},
		["Mirror Image <Doable>"] = {
			["GUID"] = "0xF1300079F000008D",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
			},
			["TimeWindows"] = {
				["Damage"] = {
					3460, -- [1]
				},
				["TimeDamage"] = {
					24.11000000000001, -- [1]
				},
				["ActiveTime"] = {
					24.11000000000001, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 2,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["Damage"] = 1604180064,
				["OVERALL"] = 1604180067,
				["TimeDamage"] = 1604180067,
				["ActiveTime"] = 1604180067,
			},
			["Owner"] = "Doable",
			["LastAbility"] = 1138850.032,
			["NextEventNum"] = 27,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
			},
			["LastEvents"] = {
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [1]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [2]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [3]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [4]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [5]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [6]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -478 (Frost)", -- [7]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -481 (Frost)", -- [8]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -483 (Frost)", -- [9]
				"Mirror Image <Doable> Fire Blast Headless Horseman Immune (Fire)", -- [10]
				"Mirror Image <Doable> Fire Blast Headless Horseman Immune (Fire)", -- [11]
				"Mirror Image <Doable> Fire Blast Headless Horseman Immune (Fire)", -- [12]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [13]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [14]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [15]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [16]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [17]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [18]
				"Mirror Image <Doable> Fire Blast Headless Horseman Hit -290 (Fire)", -- [19]
				"Mirror Image <Doable> Fire Blast Headless Horseman Hit -291 (Fire)", -- [20]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -481 (Frost)", -- [21]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -479 (Frost)", -- [22]
				"Mirror Image <Doable> Frostbolt Headless Horseman Hit -477 (Frost)", -- [23]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [24]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [25]
				"Mirror Image <Doable> Frostbolt Headless Horseman Immune (Frost)", -- [26]
			},
			["Name"] = "Mirror Image",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
			},
			["LastEventTimes"] = {
				1138829.394, -- [1]
				1138829.507, -- [2]
				1138830.03, -- [3]
				1138832.594, -- [4]
				1138832.627, -- [5]
				1138832.881, -- [6]
				1138835.817, -- [7]
				1138835.818, -- [8]
				1138836.122, -- [9]
				1138838.393, -- [10]
				1138838.394, -- [11]
				1138838.394, -- [12]
				1138839.255, -- [13]
				1138839.263, -- [14]
				1138839.409, -- [15]
				1138842.722, -- [16]
				1138842.735, -- [17]
				1138842.924, -- [18]
				1138845.617, -- [19]
				1138845.617, -- [20]
				1138846.469, -- [21]
				1138846.469, -- [22]
				1138846.641, -- [23]
				1138849.877, -- [24]
				1138849.889, -- [25]
				1138850.032, -- [26]
			},
			["Fights"] = {
				["Fight1"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["ElementDone"] = {
						["Fire"] = 581,
						["Frost"] = 2879,
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
					},
					["TimeDamage"] = 24.11000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 291,
									["min"] = 290,
									["count"] = 2,
									["amount"] = 581,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 581,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 483,
									["min"] = 477,
									["count"] = 6,
									["amount"] = 2879,
								},
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 2879,
						},
					},
					["ActiveTime"] = 24.11000000000001,
					["Damage"] = 3460,
				},
				["LastFightData"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["ElementDone"] = {
						["Fire"] = 581,
						["Frost"] = 2879,
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
					},
					["TimeDamage"] = 24.11000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 291,
									["min"] = 290,
									["count"] = 2,
									["amount"] = 581,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 581,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 483,
									["min"] = 477,
									["count"] = 6,
									["amount"] = 2879,
								},
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 2879,
						},
					},
					["ActiveTime"] = 24.11000000000001,
					["Damage"] = 3460,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["ElementDone"] = {
						["Fire"] = 581,
						["Frost"] = 2879,
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 581,
								},
								["Frostbolt"] = {
									["count"] = 2879,
								},
							},
							["amount"] = 3460,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Immune"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
								["Immune"] = {
									["count"] = 15,
								},
							},
							["amount"] = 21,
						},
					},
					["TimeDamage"] = 24.11000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 4.96,
								},
								["Frostbolt"] = {
									["count"] = 19.15,
								},
							},
							["amount"] = 24.11000000000001,
						},
					},
					["Attacks"] = {
						["Fire Blast"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 291,
									["min"] = 290,
									["count"] = 2,
									["amount"] = 581,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 581,
						},
						["Frostbolt"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 483,
									["min"] = 477,
									["count"] = 6,
									["amount"] = 2879,
								},
								["Immune"] = {
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 2879,
						},
					},
					["ActiveTime"] = 24.11000000000001,
					["Damage"] = 3460,
				},
			},
			["UnitLockout"] = 1604180067,
			["LastActive"] = 1604180067,
		},
		["Trolopresor"] = {
			["GUID"] = "0x0700000000534A6C",
			["LastEventHealth"] = {
				"18043 (75%)", -- [1]
				"18043 (75%)", -- [2]
				"18043 (75%)", -- [3]
				"19044 (79%)", -- [4]
				"19044 (79%)", -- [5]
				"19329 (81%)", -- [6]
				"19344 (81%)", -- [7]
				"19344 (81%)", -- [8]
				"19347 (81%)", -- [9]
				"19347 (81%)", -- [10]
				"19347 (81%)", -- [11]
				"19349 (81%)", -- [12]
				"20350 (85%)", -- [13]
				"20350 (85%)", -- [14]
				"20350 (85%)", -- [15]
				"20350 (85%)", -- [16]
				"20350 (85%)", -- [17]
				"20353 (85%)", -- [18]
				"20353 (85%)", -- [19]
				"20355 (85%)", -- [20]
				"20355 (85%)", -- [21]
				"20355 (85%)", -- [22]
				"20355 (85%)", -- [23]
				"20355 (85%)", -- [24]
				"20358 (85%)", -- [25]
				"20358 (85%)", -- [26]
				"20358 (85%)", -- [27]
				"20358 (85%)", -- [28]
				"20358 (85%)", -- [29]
				"20358 (85%)", -- [30]
				"20358 (85%)", -- [31]
				"20358 (85%)", -- [32]
				"20360 (85%)", -- [33]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"HEAL", -- [33]
			},
			["TimeWindows"] = {
				["ManaGain"] = {
					879, -- [1]
				},
				["TimeHeal"] = {
					2.49, -- [1]
				},
				["HOT_Time"] = {
					6, -- [1]
				},
				["ActiveTime"] = {
					22.42, -- [1]
				},
				["HealingTaken"] = {
					2002, -- [1]
				},
				["Healing"] = {
					8987, -- [1]
				},
				["TimeDamage"] = {
					19.93, -- [1]
				},
				["Damage"] = {
					40222, -- [1]
				},
			},
			["enClass"] = "SHAMAN",
			["unit"] = "Trolopresor",
			["level"] = 80,
			["LastAbility"] = 1138847.765,
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[13] = 4.196361197283475,
				[4] = 4.196361197283475,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 3,
			["GuardianReverseGUIDs"] = {
				["Strength of Earth Totem VIII"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130007999000091",
					},
				},
				["Magma Totem VII"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF1300079BF000090",
					},
				},
				["Windfury Totem"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF1300017E0000093",
					},
				},
				["Mana Spring Totem VIII"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF1300079D6000092",
					},
				},
			},
			["TimeLast"] = {
				["TimeHeal"] = 1604180065,
				["OVERALL"] = 1604180065,
				["HealingTaken"] = 1604180058,
				["HOT_Time"] = 1604180058,
				["TimeDamage"] = 1604180064,
				["ActiveTime"] = 1604180065,
				["ManaGain"] = 1604180058,
				["Healing"] = 1604180065,
				["Damage"] = 1604180064,
			},
			["Owner"] = false,
			["Pet"] = {
				"Magma Totem VII <Trolopresor>", -- [1]
				"Strength of Earth Totem VIII <Trolopresor>", -- [2]
				"Mana Spring Totem VIII <Trolopresor>", -- [3]
				"Windfury Totem <Trolopresor>", -- [4]
			},
			["NextEventNum"] = 34,
			["LastEventHealthNum"] = {
				75.63930577680893, -- [1]
				75.63930577680893, -- [2]
				75.63930577680893, -- [3]
				79.83566697409239, -- [4]
				79.83566697409239, -- [5]
				81.03043514714513, -- [6]
				81.09331768256897, -- [7]
				81.09331768256897, -- [8]
				81.10589418965373, -- [9]
				81.10589418965373, -- [10]
				81.10589418965373, -- [11]
				81.11427852771024, -- [12]
				85.31063972499371, -- [13]
				85.31063972499371, -- [14]
				85.31063972499371, -- [15]
				85.31063972499371, -- [16]
				85.31063972499371, -- [17]
				85.32321623207848, -- [18]
				85.32321623207848, -- [19]
				85.33160057013498, -- [20]
				85.33160057013498, -- [21]
				85.33160057013498, -- [22]
				85.33160057013498, -- [23]
				85.33160057013498, -- [24]
				85.34417707721975, -- [25]
				85.34417707721975, -- [26]
				85.34417707721975, -- [27]
				85.34417707721975, -- [28]
				85.34417707721975, -- [29]
				85.34417707721975, -- [30]
				85.34417707721975, -- [31]
				85.34417707721975, -- [32]
				85.35256141527627, -- [33]
			},
			["LastEvents"] = {
				"Trolopresor Melee Anguished Dead Hit -1590 (Physical)", -- [1]
				"Anguished Dead Melee Trolopresor Miss", -- [2]
				"Trolopresor Flametongue Attack Anguished Dead Hit -409 (Fire)", -- [3]
				"Trolopresor Improved Leader of the Pack Trolopresor Tick +1001", -- [4]
				"Trolopresor Melee Anguished Dead Crit -1932 (Physical)", -- [5]
				"Trolopresor Earth Shock Headless Horseman Crit -3940 (Nature)", -- [6]
				"Trolopresor Earth Shock Headless Horseman Crit -4008 (Nature)", -- [7]
				"Trolopresor Melee Headless Horseman Hit -1295 (Physical)", -- [8]
				"Trolopresor Flametongue Attack Headless Horseman Hit -422 (Fire)", -- [9]
				"Trolopresor Melee Headless Horseman Hit -641 (Physical)", -- [10]
				"Trolopresor Melee Headless Horseman Immune", -- [11]
				"Trolopresor Melee Headless Horseman Immune", -- [12]
				"Trolopresor Improved Leader of the Pack Trolopresor Tick +1001", -- [13]
				"Trolopresor Stormstrike Head of the Horseman Crit -2416 (Physical)", -- [14]
				"Trolopresor Flametongue Attack Head of the Horseman Hit -422 (Fire)", -- [15]
				"Trolopresor Stormstrike Head of the Horseman Crit -1238 (Physical)", -- [16]
				"Trolopresor Melee Head of the Horseman Crit -2486 (Physical)", -- [17]
				"Trolopresor Flametongue Attack Head of the Horseman Hit -422 (Fire)", -- [18]
				"Trolopresor Melee Head of the Horseman Crit -1388 (Physical)", -- [19]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [20]
				"Trolopresor Lava Lash Headless Horseman Crit -2653 (Fire)", -- [21]
				"Trolopresor Melee Headless Horseman Crit -2599 (Physical)", -- [22]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [23]
				"Trolopresor Melee Headless Horseman Hit -714 (Physical)", -- [24]
				"Trolopresor Windfury Attack Headless Horseman Hit -2075 (Physical)", -- [25]
				"Trolopresor Windfury Attack Headless Horseman Hit -1974 (Physical)", -- [26]
				"Trolopresor Melee Headless Horseman Crit -2502 (Physical)", -- [27]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [28]
				"Trolopresor Melee Headless Horseman Crit -1281 (Physical)", -- [29]
				"Trolopresor Melee Headless Horseman Hit -1365 (Physical)", -- [30]
				"Trolopresor Flametongue Attack Headless Horseman Hit -437 (Fire)", -- [31]
				"Trolopresor Melee Headless Horseman Hit -702 (Physical)", -- [32]
				"Trolopresor Healing Wave Druidwarr Hit +6985", -- [33]
			},
			["Name"] = "Trolopresor",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
			},
			["LastEventTimes"] = {
				1138799.897, -- [1]
				1138799.898, -- [2]
				1138800.191, -- [3]
				1138800.191, -- [4]
				1138800.193, -- [5]
				1138824.481, -- [6]
				1138836.121, -- [7]
				1138837.29, -- [8]
				1138837.461, -- [9]
				1138837.462, -- [10]
				1138839.077, -- [11]
				1138839.341, -- [12]
				1138841.14, -- [13]
				1138841.14, -- [14]
				1138841.14, -- [15]
				1138841.141, -- [16]
				1138841.315, -- [17]
				1138841.444, -- [18]
				1138841.446, -- [19]
				1138843.295, -- [20]
				1138843.295, -- [21]
				1138843.785, -- [22]
				1138844.052, -- [23]
				1138844.053, -- [24]
				1138845.406, -- [25]
				1138845.406, -- [26]
				1138845.406, -- [27]
				1138845.615, -- [28]
				1138845.616, -- [29]
				1138846.785, -- [30]
				1138847.075, -- [31]
				1138847.076, -- [32]
				1138847.765, -- [33]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["TimeHealing"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Flametongue Attack"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
					},
					["HealedWho"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 3.79,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Damage"] = 3931,
					["TimeHeal"] = 0,
					["WhoHealed"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["Healing"] = 1001,
					["HOT_Time"] = 3,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1001,
									["min"] = 1001,
									["count"] = 1,
									["amount"] = 1001,
								},
							},
							["count"] = 1,
							["amount"] = 1001,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1932,
									["min"] = 1932,
									["count"] = 1,
									["amount"] = 1932,
								},
								["Hit"] = {
									["max"] = 1590,
									["min"] = 1590,
									["count"] = 1,
									["amount"] = 1590,
								},
							},
							["count"] = 2,
							["amount"] = 3522,
						},
						["Flametongue Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 409,
									["min"] = 409,
									["count"] = 1,
									["amount"] = 409,
								},
							},
							["count"] = 1,
							["amount"] = 409,
						},
					},
					["HealingTaken"] = 1001,
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3522,
								},
								["Flametongue Attack"] = {
									["count"] = 409,
								},
							},
							["amount"] = 3931,
						},
					},
					["TimeDamage"] = 3.79,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Flametongue Attack"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementDone"] = {
						["Melee"] = 3522,
						["Fire"] = 409,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 3,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 12,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 36291,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 2.49,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 7703,
						["Fire"] = 5667,
						["Melee"] = 14973,
						["Nature"] = 7948,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 844,
								},
								["Melee"] = {
									["count"] = 3874,
								},
								["Stormstrike"] = {
									["count"] = 3654,
								},
							},
							["amount"] = 8372,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Stormstrike"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Improved Stormstrike"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1001,
									["min"] = 1001,
									["count"] = 1,
									["amount"] = 1001,
								},
							},
							["count"] = 1,
							["amount"] = 1001,
						},
						["Healing Wave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6985,
									["min"] = 6985,
									["count"] = 1,
									["amount"] = 6985,
								},
							},
							["count"] = 1,
							["amount"] = 6985,
						},
					},
					["WhoHealed"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 18.63,
					["Healing"] = 7986,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Flametongue Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 437,
									["min"] = 422,
									["count"] = 7,
									["amount"] = 3014,
								},
							},
							["count"] = 7,
							["amount"] = 3014,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2075,
									["min"] = 1974,
									["count"] = 2,
									["amount"] = 4049,
								},
							},
							["count"] = 2,
							["amount"] = 4049,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2599,
									["min"] = 1281,
									["count"] = 5,
									["amount"] = 10256,
								},
								["Hit"] = {
									["max"] = 1365,
									["min"] = 641,
									["count"] = 5,
									["amount"] = 4717,
								},
							},
							["count"] = 12,
							["amount"] = 14973,
						},
						["Stormstrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2416,
									["min"] = 1238,
									["count"] = 2,
									["amount"] = 3654,
								},
							},
							["count"] = 2,
							["amount"] = 3654,
						},
						["Lava Lash"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2653,
									["min"] = 2653,
									["count"] = 1,
									["amount"] = 2653,
								},
							},
							["count"] = 1,
							["amount"] = 2653,
						},
						["Earth Shock"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4008,
									["min"] = 3940,
									["count"] = 2,
									["amount"] = 7948,
								},
							},
							["count"] = 2,
							["amount"] = 7948,
						},
					},
					["HealingTaken"] = 1001,
					["RageGain"] = 0,
					["TimeDamage"] = 16.14,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
					},
					["ManaGain"] = 879,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 3,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 12,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 36291,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 2.49,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 7703,
						["Fire"] = 5667,
						["Melee"] = 14973,
						["Nature"] = 7948,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 844,
								},
								["Melee"] = {
									["count"] = 3874,
								},
								["Stormstrike"] = {
									["count"] = 3654,
								},
							},
							["amount"] = 8372,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Stormstrike"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Improved Stormstrike"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1001,
									["min"] = 1001,
									["count"] = 1,
									["amount"] = 1001,
								},
							},
							["count"] = 1,
							["amount"] = 1001,
						},
						["Healing Wave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6985,
									["min"] = 6985,
									["count"] = 1,
									["amount"] = 6985,
								},
							},
							["count"] = 1,
							["amount"] = 6985,
						},
					},
					["WhoHealed"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1001,
								},
							},
							["amount"] = 1001,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 18.63,
					["Healing"] = 7986,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Flametongue Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 437,
									["min"] = 422,
									["count"] = 7,
									["amount"] = 3014,
								},
							},
							["count"] = 7,
							["amount"] = 3014,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2075,
									["min"] = 1974,
									["count"] = 2,
									["amount"] = 4049,
								},
							},
							["count"] = 2,
							["amount"] = 4049,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2599,
									["min"] = 1281,
									["count"] = 5,
									["amount"] = 10256,
								},
								["Hit"] = {
									["max"] = 1365,
									["min"] = 641,
									["count"] = 5,
									["amount"] = 4717,
								},
							},
							["count"] = 12,
							["amount"] = 14973,
						},
						["Stormstrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2416,
									["min"] = 1238,
									["count"] = 2,
									["amount"] = 3654,
								},
							},
							["count"] = 2,
							["amount"] = 3654,
						},
						["Lava Lash"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2653,
									["min"] = 2653,
									["count"] = 1,
									["amount"] = 2653,
								},
							},
							["count"] = 1,
							["amount"] = 2653,
						},
						["Earth Shock"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4008,
									["min"] = 3940,
									["count"] = 2,
									["amount"] = 7948,
								},
							},
							["count"] = 2,
							["amount"] = 7948,
						},
					},
					["HealingTaken"] = 1001,
					["RageGain"] = 0,
					["TimeDamage"] = 16.14,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
					},
					["ManaGain"] = 879,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Flametongue Attack"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 0.69,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 1.8,
						},
					},
					["HealedWho"] = {
						["Druidwarr"] = {
							["Details"] = {
								["Healing Wave"] = {
									["count"] = 6985,
								},
							},
							["amount"] = 6985,
						},
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2002,
								},
							},
							["amount"] = 2002,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Stormstrike"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 22.42,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Trolopresor"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["Damage"] = 40222,
					["TimeHeal"] = 2.49,
					["ManaGainedFrom"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Stormstrike"] = {
									["count"] = 879,
								},
							},
							["amount"] = 879,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["WhoHealed"] = {
						["Trolopresor"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2002,
								},
							},
							["amount"] = 2002,
						},
					},
					["Healing"] = 8987,
					["HOT_Time"] = 6,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1001,
									["min"] = 1001,
									["count"] = 2,
									["amount"] = 2002,
								},
							},
							["count"] = 2,
							["amount"] = 2002,
						},
						["Healing Wave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6985,
									["min"] = 6985,
									["count"] = 1,
									["amount"] = 6985,
								},
							},
							["count"] = 1,
							["amount"] = 6985,
						},
					},
					["Attacks"] = {
						["Flametongue Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 437,
									["min"] = 409,
									["count"] = 8,
									["amount"] = 3423,
								},
							},
							["count"] = 8,
							["amount"] = 3423,
						},
						["Windfury Attack"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2075,
									["min"] = 1974,
									["count"] = 2,
									["amount"] = 4049,
								},
							},
							["count"] = 2,
							["amount"] = 4049,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2599,
									["min"] = 1281,
									["count"] = 6,
									["amount"] = 12188,
								},
								["Hit"] = {
									["max"] = 1590,
									["min"] = 641,
									["count"] = 6,
									["amount"] = 6307,
								},
							},
							["count"] = 14,
							["amount"] = 18495,
						},
						["Stormstrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2416,
									["min"] = 1238,
									["count"] = 2,
									["amount"] = 3654,
								},
							},
							["count"] = 2,
							["amount"] = 3654,
						},
						["Lava Lash"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2653,
									["min"] = 2653,
									["count"] = 1,
									["amount"] = 2653,
								},
							},
							["count"] = 1,
							["amount"] = 2653,
						},
						["Earth Shock"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4008,
									["min"] = 3940,
									["count"] = 2,
									["amount"] = 7948,
								},
							},
							["count"] = 2,
							["amount"] = 7948,
						},
					},
					["HealingTaken"] = 2002,
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3522,
								},
								["Flametongue Attack"] = {
									["count"] = 409,
								},
							},
							["amount"] = 3931,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2170,
								},
								["Windfury Attack"] = {
									["count"] = 4049,
								},
								["Melee"] = {
									["count"] = 11099,
								},
								["Lava Lash"] = {
									["count"] = 2653,
								},
								["Earth Shock"] = {
									["count"] = 7948,
								},
							},
							["amount"] = 27919,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 844,
								},
								["Melee"] = {
									["count"] = 3874,
								},
								["Stormstrike"] = {
									["count"] = 3654,
								},
							},
							["amount"] = 8372,
						},
					},
					["TimeDamage"] = 19.93,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Flametongue Attack"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 2.79,
								},
								["Windfury Attack"] = {
									["count"] = 1.35,
								},
								["Melee"] = {
									["count"] = 4.7,
								},
								["Lava Lash"] = {
									["count"] = 0,
								},
								["Earth Shock"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15.84,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Flametongue Attack"] = {
									["count"] = 0.13,
								},
								["Melee"] = {
									["count"] = 0.17,
								},
								["Stormstrike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.3,
						},
					},
					["ManaGain"] = 879,
					["ElementDone"] = {
						["Physical"] = 7703,
						["Fire"] = 6076,
						["Melee"] = 18495,
						["Nature"] = 7948,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 8,
								},
							},
							["amount"] = 9,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 14,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
				},
			},
			["UnitLockout"] = 1604180017,
			["LastActive"] = 1604180065,
		},
		["Doable"] = {
			["GUID"] = "0x0700000000348350",
			["TimeLast"] = {
				["DamageTaken"] = 1604180068,
				["TimeDamage"] = 1604180068,
				["ActiveTime"] = 1604180068,
				["ManaGain"] = 1604180068,
				["OVERALL"] = 1604180068,
				["DOT_Time"] = 1604180068,
				["Damage"] = 1604180068,
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
			},
			["TimeWindows"] = {
				["DamageTaken"] = {
					3059, -- [1]
				},
				["ActiveTime"] = {
					29.97000000000001, -- [1]
				},
				["TimeDamage"] = {
					29.97000000000001, -- [1]
				},
				["ManaGain"] = {
					1461, -- [1]
				},
				["DOT_Time"] = {
					27, -- [1]
				},
				["Damage"] = {
					123277, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "Doable",
			["LastAbility"] = 1138851.424,
			["LastDamageTaken"] = 3059,
			["level"] = 80,
			["LastDamageAbility"] = "Horseman's Cleave",
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[32] = 12.07229961719089,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["GuardianReverseGUIDs"] = {
				["Mirror Image"] = {
					["LatestGuardian"] = 2,
					["GUIDs"] = {
						"0xF1300079F000008D", -- [1]
						"0xF1300079F000008E", -- [2]
						[0] = "0xF1300079F000008C",
					},
				},
			},
			["LastEventHealth"] = {
				"25339 (100%)", -- [1]
				"25339 (100%)", -- [2]
				"25339 (100%)", -- [3]
				"25339 (100%)", -- [4]
				"25339 (100%)", -- [5]
				"25339 (100%)", -- [6]
				"25339 (100%)", -- [7]
				"25339 (100%)", -- [8]
				"25339 (100%)", -- [9]
				"25339 (100%)", -- [10]
				"25339 (100%)", -- [11]
				"25339 (100%)", -- [12]
				"25339 (100%)", -- [13]
				"25339 (100%)", -- [14]
				"25339 (100%)", -- [15]
				"25339 (100%)", -- [16]
				"25339 (100%)", -- [17]
				"25339 (100%)", -- [18]
				"25339 (100%)", -- [19]
				"25339 (100%)", -- [20]
				"25339 (100%)", -- [21]
				"25339 (100%)", -- [22]
				"25339 (100%)", -- [23]
				"25339 (100%)", -- [24]
				"25339 (100%)", -- [25]
				"25339 (100%)", -- [26]
				"25339 (100%)", -- [27]
				"25339 (100%)", -- [28]
				"25339 (100%)", -- [29]
				"25339 (100%)", -- [30]
				"25339 (100%)", -- [31]
				"22280 (87%)", -- [32]
				"22280 (87%)", -- [33]
			},
			["Owner"] = false,
			["Pet"] = {
				"Mirror Image <Doable>", -- [1]
			},
			["NextEventNum"] = 34,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				87.92770038280911, -- [32]
				87.92770038280911, -- [33]
			},
			["LastEvents"] = {
				"Doable Scorch Headless Horseman Crit -5166 (Fire)", -- [1]
				"Doable Living Bomb (DoT) Headless Horseman Crit -2432 (Fire)", -- [2]
				"Doable Scorch Headless Horseman Immune (Fire)", -- [3]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [4]
				"Doable Living Bomb Headless Horseman Immune (Fire)", -- [5]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [6]
				"Doable Scorch Head of the Horseman Crit -6587 (Fire)", -- [7]
				"Doable Fire Blast Head of the Horseman Crit -8526 (Fire)", -- [8]
				"Doable Living Bomb Headless Horseman Immune (Fire)", -- [9]
				"Doable Scorch Headless Horseman Hit -3180 (Fire)", -- [10]
				"Doable Living Bomb (DoT) Headless Horseman Crit -2115 (Fire)", -- [11]
				"Doable Living Bomb Headless Horseman Crit -6805 (Fire)", -- [12]
				"Doable Ignite (DoT) Headless Horseman Tick -1784 (Fire)", -- [13]
				"Doable Scorch Headless Horseman Hit -3926 (Fire)", -- [14]
				"Doable Living Bomb (DoT) Headless Horseman Crit -3232 (Fire)", -- [15]
				"Doable Scorch Headless Horseman Immune (Fire)", -- [16]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [17]
				"Doable Living Bomb Headless Horseman Immune (Fire)", -- [18]
				"Doable Pyroblast Head of the Horseman Crit -23219 (Fire)", -- [19]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [20]
				"Doable Living Bomb (DoT) Headless Horseman Crit -3232 (Fire)", -- [21]
				"Doable Scorch Headless Horseman Crit -6488 (Fire)", -- [22]
				"Doable Pyroblast (DoT) Head of the Horseman Tick -1736 (Fire)", -- [23]
				"Doable Scorch Headless Horseman Crit -6440 (Fire)", -- [24]
				"Doable Living Bomb (DoT) Headless Horseman Crit -3232 (Fire)", -- [25]
				"Doable Living Bomb Headless Horseman Hit -4236 (Fire)", -- [26]
				"Doable Scorch Headless Horseman Crit -7230 (Fire)", -- [27]
				"Doable Pyroblast (DoT) Head of the Horseman Tick -1736 (Fire)", -- [28]
				"Doable Ignite Headless Horseman Immune (Fire)", -- [29]
				"Doable Living Bomb Headless Horseman Immune (Fire)", -- [30]
				"Doable Pyroblast (DoT) Head of the Horseman Tick -1736 (Fire)", -- [31]
				"Headless Horseman Horseman's Cleave Doable Hit -3059 (Physical)", -- [32]
				"Doable Pyroblast Head of the Horseman Crit -20239 (Fire)", -- [33]
			},
			["Name"] = "Doable",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
			},
			["LastEventTimes"] = {
				1138824.951, -- [1]
				1138825.258, -- [2]
				1138827.083, -- [3]
				1138827.338, -- [4]
				1138828.263, -- [5]
				1138829.315, -- [6]
				1138830.357, -- [7]
				1138830.616, -- [8]
				1138831.126, -- [9]
				1138833.669, -- [10]
				1138834.222, -- [11]
				1138834.223, -- [12]
				1138836.25, -- [13]
				1138836.996, -- [14]
				1138837.609, -- [15]
				1138838.678, -- [16]
				1138839.586, -- [17]
				1138840.524, -- [18]
				1138841.616, -- [19]
				1138841.616, -- [20]
				1138843.553, -- [21]
				1138844.315, -- [22]
				1138844.585, -- [23]
				1138845.616, -- [24]
				1138846.64, -- [25]
				1138846.641, -- [26]
				1138847.207, -- [27]
				1138847.651, -- [28]
				1138849.31, -- [29]
				1138850.633, -- [30]
				1138850.633, -- [31]
				1138851.418, -- [32]
				1138851.424, -- [33]
			},
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["DamageTaken"] = 3059,
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Empowered Fire"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 65,
								},
							},
							["amount"] = 65,
						},
						["Master of Elements"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 29.97000000000001,
					["ElementTaken"] = {
						["Physical"] = 3059,
					},
					["DOT_Time"] = 27,
					["Damage"] = 123277,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["Attacks"] = {
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1784,
									["min"] = 1784,
									["count"] = 1,
									["amount"] = 1784,
								},
							},
							["count"] = 1,
							["amount"] = 1784,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23219,
									["min"] = 20239,
									["count"] = 2,
									["amount"] = 43458,
								},
							},
							["count"] = 2,
							["amount"] = 43458,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1736,
									["min"] = 1736,
									["count"] = 3,
									["amount"] = 5208,
								},
							},
							["count"] = 3,
							["amount"] = 5208,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7230,
									["min"] = 5166,
									["count"] = 5,
									["amount"] = 31911,
								},
								["Hit"] = {
									["max"] = 3926,
									["min"] = 3180,
									["count"] = 2,
									["amount"] = 7106,
								},
							},
							["count"] = 9,
							["amount"] = 39017,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8526,
									["min"] = 8526,
									["count"] = 1,
									["amount"] = 8526,
								},
							},
							["count"] = 1,
							["amount"] = 8526,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3232,
									["min"] = 2115,
									["count"] = 5,
									["amount"] = 14243,
								},
							},
							["count"] = 5,
							["amount"] = 14243,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6805,
									["min"] = 6805,
									["count"] = 1,
									["amount"] = 6805,
								},
								["Hit"] = {
									["max"] = 4236,
									["min"] = 4236,
									["count"] = 1,
									["amount"] = 4236,
								},
							},
							["count"] = 6,
							["amount"] = 11041,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 6587,
								},
								["Pyroblast"] = {
									["count"] = 43458,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5208,
								},
								["Fire Blast"] = {
									["count"] = 8526,
								},
							},
							["amount"] = 63779,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
					},
					["ManaGainedFrom"] = {
						["Doable"] = {
							["Details"] = {
								["Empowered Fire"] = {
									["count"] = 65,
								},
								["Master of Elements"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1461,
						},
					},
					["TimeDamage"] = 29.97000000000001,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["ManaGain"] = 1461,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 11,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 32,
						},
					},
					["ElementDone"] = {
						["Fire"] = 123277,
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["DamageTaken"] = 3059,
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Empowered Fire"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 65,
								},
							},
							["amount"] = 65,
						},
						["Master of Elements"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 29.97000000000001,
					["ElementTaken"] = {
						["Physical"] = 3059,
					},
					["DOT_Time"] = 27,
					["Damage"] = 123277,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["Attacks"] = {
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1784,
									["min"] = 1784,
									["count"] = 1,
									["amount"] = 1784,
								},
							},
							["count"] = 1,
							["amount"] = 1784,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23219,
									["min"] = 20239,
									["count"] = 2,
									["amount"] = 43458,
								},
							},
							["count"] = 2,
							["amount"] = 43458,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1736,
									["min"] = 1736,
									["count"] = 3,
									["amount"] = 5208,
								},
							},
							["count"] = 3,
							["amount"] = 5208,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7230,
									["min"] = 5166,
									["count"] = 5,
									["amount"] = 31911,
								},
								["Hit"] = {
									["max"] = 3926,
									["min"] = 3180,
									["count"] = 2,
									["amount"] = 7106,
								},
							},
							["count"] = 9,
							["amount"] = 39017,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8526,
									["min"] = 8526,
									["count"] = 1,
									["amount"] = 8526,
								},
							},
							["count"] = 1,
							["amount"] = 8526,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3232,
									["min"] = 2115,
									["count"] = 5,
									["amount"] = 14243,
								},
							},
							["count"] = 5,
							["amount"] = 14243,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6805,
									["min"] = 6805,
									["count"] = 1,
									["amount"] = 6805,
								},
								["Hit"] = {
									["max"] = 4236,
									["min"] = 4236,
									["count"] = 1,
									["amount"] = 4236,
								},
							},
							["count"] = 6,
							["amount"] = 11041,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 6587,
								},
								["Pyroblast"] = {
									["count"] = 43458,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5208,
								},
								["Fire Blast"] = {
									["count"] = 8526,
								},
							},
							["amount"] = 63779,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
					},
					["ManaGainedFrom"] = {
						["Doable"] = {
							["Details"] = {
								["Empowered Fire"] = {
									["count"] = 65,
								},
								["Master of Elements"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1461,
						},
					},
					["TimeDamage"] = 29.97000000000001,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["ManaGain"] = 1461,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 11,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 32,
						},
					},
					["ElementDone"] = {
						["Fire"] = 123277,
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Head of the Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["DamageTaken"] = 3059,
					["PartialResist"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Empowered Fire"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 65,
								},
							},
							["amount"] = 65,
						},
						["Master of Elements"] = {
							["Details"] = {
								["Doable"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["PartialAbsorb"] = {
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 29.97000000000001,
					["ElementTaken"] = {
						["Physical"] = 3059,
					},
					["DOT_Time"] = 27,
					["Damage"] = 123277,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3059,
								},
							},
							["amount"] = 3059,
						},
					},
					["Attacks"] = {
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1784,
									["min"] = 1784,
									["count"] = 1,
									["amount"] = 1784,
								},
							},
							["count"] = 1,
							["amount"] = 1784,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23219,
									["min"] = 20239,
									["count"] = 2,
									["amount"] = 43458,
								},
							},
							["count"] = 2,
							["amount"] = 43458,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1736,
									["min"] = 1736,
									["count"] = 3,
									["amount"] = 5208,
								},
							},
							["count"] = 3,
							["amount"] = 5208,
						},
						["Ignite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7230,
									["min"] = 5166,
									["count"] = 5,
									["amount"] = 31911,
								},
								["Hit"] = {
									["max"] = 3926,
									["min"] = 3180,
									["count"] = 2,
									["amount"] = 7106,
								},
							},
							["count"] = 9,
							["amount"] = 39017,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8526,
									["min"] = 8526,
									["count"] = 1,
									["amount"] = 8526,
								},
							},
							["count"] = 1,
							["amount"] = 8526,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3232,
									["min"] = 2115,
									["count"] = 5,
									["amount"] = 14243,
								},
							},
							["count"] = 5,
							["amount"] = 14243,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6805,
									["min"] = 6805,
									["count"] = 1,
									["amount"] = 6805,
								},
								["Hit"] = {
									["max"] = 4236,
									["min"] = 4236,
									["count"] = 1,
									["amount"] = 4236,
								},
							},
							["count"] = 6,
							["amount"] = 11041,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 6587,
								},
								["Pyroblast"] = {
									["count"] = 43458,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5208,
								},
								["Fire Blast"] = {
									["count"] = 8526,
								},
							},
							["amount"] = 63779,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 14243,
								},
								["Ignite (DoT)"] = {
									["count"] = 1784,
								},
								["Scorch"] = {
									["count"] = 32430,
								},
								["Living Bomb"] = {
									["count"] = 11041,
								},
							},
							["amount"] = 59498,
						},
					},
					["ManaGainedFrom"] = {
						["Doable"] = {
							["Details"] = {
								["Empowered Fire"] = {
									["count"] = 65,
								},
								["Master of Elements"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1461,
						},
					},
					["TimeDamage"] = 29.97000000000001,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Scorch"] = {
									["count"] = 1.04,
								},
								["Pyroblast"] = {
									["count"] = 1.88,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0.71,
								},
								["Fire Blast"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 3.89,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Ignite"] = {
									["count"] = 3.87,
								},
								["Scorch"] = {
									["count"] = 12.05,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.03,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4.43,
								},
								["Living Bomb"] = {
									["count"] = 3.7,
								},
							},
							["amount"] = 26.08000000000001,
						},
					},
					["ManaGain"] = 1461,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 11,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 32,
						},
					},
					["ElementDone"] = {
						["Fire"] = 123277,
					},
				},
			},
			["UnitLockout"] = 1604180042,
			["LastActive"] = 1604180068,
		},
		["Stormfang <Praxia>"] = {
			["GUID"] = "0xF1400DEC13000001",
			["TimeLast"] = {
				["EnergyGain"] = 1604180068,
				["HOT_Time"] = 1604180064,
				["ActiveTime"] = 1604180067,
				["Overhealing"] = 1604180064,
				["OVERALL"] = 1604180068,
				["TimeDamage"] = 1604180067,
				["Damage"] = 1604180065,
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"HEAL", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"HEAL", -- [21]
				"DAMAGE", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"HEAL", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"HEAL", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
			},
			["TimeWindows"] = {
				["EnergyGain"] = {
					900, -- [1]
				},
				["HOT_Time"] = {
					18, -- [1]
				},
				["ActiveTime"] = {
					31.35, -- [1]
				},
				["Overhealing"] = {
					1467, -- [1]
				},
				["TimeDamage"] = {
					31.35, -- [1]
				},
				["Damage"] = {
					11557, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "Stormfang",
			["level"] = 1,
			["LastFightIn"] = 2,
			["LastEventNum"] = {
				[26] = 0.9995707364935303,
				[23] = 0.9995707364935303,
				[37] = 3.998282945974121,
				[21] = 0.9995707364935303,
				[18] = 0.9995707364935303,
				[15] = 0.9995707364935303,
			},
			["type"] = "Pet",
			["FightsSaved"] = 3,
			["LastAbility"] = 1138850.162,
			["Owner"] = "Praxia",
			["LastEventHealth"] = {
				"16307 (100%)", -- [1]
				"16307 (100%)", -- [2]
				"16307 (100%)", -- [3]
				"16307 (100%)", -- [4]
				"16307 (100%)", -- [5]
				"16307 (100%)", -- [6]
				"16307 (100%)", -- [7]
				"16307 (100%)", -- [8]
				"16307 (100%)", -- [9]
				"16307 (100%)", -- [10]
				"16307 (100%)", -- [11]
				"16307 (100%)", -- [12]
				"16307 (100%)", -- [13]
				"16307 (100%)", -- [14]
				"16307 (100%)", -- [15]
				"16307 (100%)", -- [16]
				"16307 (100%)", -- [17]
				"16307 (100%)", -- [18]
				"16307 (100%)", -- [19]
				"16307 (100%)", -- [20]
				"16307 (100%)", -- [21]
				"16307 (100%)", -- [22]
				"16307 (100%)", -- [23]
				"16307 (100%)", -- [24]
				"16307 (100%)", -- [25]
				"16307 (100%)", -- [26]
				"16307 (100%)", -- [27]
				"16307 (100%)", -- [28]
				"16307 (100%)", -- [29]
				"16307 (100%)", -- [30]
				"16307 (100%)", -- [31]
				"16307 (100%)", -- [32]
				"16307 (100%)", -- [33]
				"16307 (100%)", -- [34]
				"16307 (100%)", -- [35]
				"16307 (100%)", -- [36]
				"16307 (100%)", -- [37]
				"16307 (100%)", -- [38]
				"16307 (100%)", -- [39]
				"16307 (100%)", -- [40]
				"16307 (100%)", -- [41]
				"16307 (100%)", -- [42]
				"16307 (100%)", -- [43]
			},
			["NextEventNum"] = 44,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
			},
			["LastEvents"] = {
				"Stormfang <Praxia> Melee Headless Horseman Hit -464 (Physical)", -- [1]
				"Stormfang <Praxia> Bite Headless Horseman Hit -650 (Physical)", -- [2]
				"Stormfang <Praxia> Melee Headless Horseman Hit -496 (Physical)", -- [3]
				"Stormfang <Praxia> Bite Headless Horseman Hit -568 (Physical)", -- [4]
				"Stormfang <Praxia> Melee Headless Horseman Hit -510 (Physical)", -- [5]
				"Stormfang <Praxia> Bite Headless Horseman Hit -500 (Physical)", -- [6]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [7]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [8]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [9]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [10]
				"Stormfang <Praxia> Melee Head of the Horseman Hit -525 (Physical)", -- [11]
				"Stormfang <Praxia> Bite Head of the Horseman Hit -392 (Physical)", -- [12]
				"Stormfang <Praxia> Melee Headless Horseman Hit -495 (Physical)", -- [13]
				"Stormfang <Praxia> Bite Headless Horseman Hit -384 (Physical)", -- [14]
				"Stormfang <Praxia> Bloodthirsty Stormfang <Praxia> Tick +163 (163 overheal)", -- [15]
				"Stormfang <Praxia> Melee Headless Horseman Hit -579 (Physical)", -- [16]
				"Stormfang <Praxia> Bite Headless Horseman Hit -420 (Physical)", -- [17]
				"Stormfang <Praxia> Bloodthirsty Stormfang <Praxia> Tick +163 (163 overheal)", -- [18]
				"Stormfang <Praxia> Melee Headless Horseman Hit -582 (Physical)", -- [19]
				"Stormfang <Praxia> Bite Headless Horseman Hit -440 (Physical)", -- [20]
				"Stormfang <Praxia> Bloodthirsty Stormfang <Praxia> Tick +163 (163 overheal)", -- [21]
				"Stormfang <Praxia> Melee Headless Horseman Hit -585 (Physical)", -- [22]
				"Stormfang <Praxia> Bloodthirsty Stormfang <Praxia> Tick +163 (163 overheal)", -- [23]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [24]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [25]
				"Stormfang <Praxia> Bloodthirsty Stormfang <Praxia> Tick +163 (163 overheal)", -- [26]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [27]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [28]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [29]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [30]
				"Stormfang <Praxia> Melee Headless Horseman Hit -398 (Physical)", -- [31]
				"Stormfang <Praxia> Bite Headless Horseman Hit -557 (Physical)", -- [32]
				"Stormfang <Praxia> Melee Headless Horseman Hit -401 (Physical)", -- [33]
				"Stormfang <Praxia> Melee Headless Horseman Hit -392 (Physical)", -- [34]
				"Stormfang <Praxia> Bite Headless Horseman Hit -435 (Physical)", -- [35]
				"Stormfang <Praxia> Melee Headless Horseman Hit -438 (Physical)", -- [36]
				"Stormfang <Praxia> Improved Leader of the Pack Stormfang <Praxia> Tick +652 (652 overheal)", -- [37]
				"Stormfang <Praxia> Bite Headless Horseman Crit -894 (Physical)", -- [38]
				"Stormfang <Praxia> Melee Headless Horseman Hit -452 (Physical)", -- [39]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [40]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [41]
				"Stormfang <Praxia> Bite Headless Horseman Immune (Physical)", -- [42]
				"Stormfang <Praxia> Melee Headless Horseman Immune", -- [43]
			},
			["Name"] = "Stormfang",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				true, -- [21]
				false, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
			},
			["LastEventTimes"] = {
				1138822.307, -- [1]
				1138822.63, -- [2]
				1138823.97, -- [3]
				1138824.317, -- [4]
				1138825.382, -- [5]
				1138825.771, -- [6]
				1138826.93, -- [7]
				1138827.084, -- [8]
				1138828.539, -- [9]
				1138828.679, -- [10]
				1138830.21, -- [11]
				1138830.484, -- [12]
				1138833.386, -- [13]
				1138833.766, -- [14]
				1138834.787, -- [15]
				1138834.788, -- [16]
				1138835.267, -- [17]
				1138835.817, -- [18]
				1138835.98, -- [19]
				1138836.856, -- [20]
				1138836.857, -- [21]
				1138837.292, -- [22]
				1138837.907, -- [23]
				1138838.237, -- [24]
				1138838.563, -- [25]
				1138838.819, -- [26]
				1138839.775, -- [27]
				1138839.884, -- [28]
				1138841.141, -- [29]
				1138841.774, -- [30]
				1138842.405, -- [31]
				1138843.684, -- [32]
				1138843.685, -- [33]
				1138844.996, -- [34]
				1138845.244, -- [35]
				1138846.272, -- [36]
				1138847.08, -- [37]
				1138847.08, -- [38]
				1138847.496, -- [39]
				1138848.246, -- [40]
				1138848.766, -- [41]
				1138849.97, -- [42]
				1138850.162, -- [43]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["EnergyGain"] = 125,
					["EnergyGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Go for the Throat"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["EnergyGained"] = {
						["Go for the Throat"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 18,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 20,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 17,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 11557,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6317,
						["Physical"] = 5240,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 525,
								},
								["Bite"] = {
									["count"] = 392,
								},
							},
							["amount"] = 917,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Go for the Throat"] = {
									["count"] = 625,
								},
							},
							["amount"] = 625,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 652,
									["min"] = 652,
									["count"] = 1,
									["amount"] = 652,
								},
							},
							["count"] = 1,
							["amount"] = 652,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 163,
									["min"] = 163,
									["count"] = 5,
									["amount"] = 815,
								},
							},
							["count"] = 5,
							["amount"] = 815,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 625,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1467,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["Go for the Throat"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 625,
								},
							},
							["amount"] = 625,
						},
					},
					["ActiveTime"] = 31.35,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 585,
									["min"] = 392,
									["count"] = 13,
									["amount"] = 6317,
								},
							},
							["count"] = 20,
							["amount"] = 6317,
						},
						["Bite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 894,
									["min"] = 894,
									["count"] = 1,
									["amount"] = 894,
								},
								["Hit"] = {
									["max"] = 650,
									["min"] = 384,
									["count"] = 9,
									["amount"] = 4346,
								},
							},
							["count"] = 17,
							["amount"] = 5240,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 31.35,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 18,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 20,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 17,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 11557,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6317,
						["Physical"] = 5240,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 525,
								},
								["Bite"] = {
									["count"] = 392,
								},
							},
							["amount"] = 917,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Go for the Throat"] = {
									["count"] = 625,
								},
							},
							["amount"] = 625,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 652,
									["min"] = 652,
									["count"] = 1,
									["amount"] = 652,
								},
							},
							["count"] = 1,
							["amount"] = 652,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 163,
									["min"] = 163,
									["count"] = 5,
									["amount"] = 815,
								},
							},
							["count"] = 5,
							["amount"] = 815,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 625,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1467,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["Go for the Throat"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 625,
								},
							},
							["amount"] = 625,
						},
					},
					["ActiveTime"] = 31.35,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 585,
									["min"] = 392,
									["count"] = 13,
									["amount"] = 6317,
								},
							},
							["count"] = 20,
							["amount"] = 6317,
						},
						["Bite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 894,
									["min"] = 894,
									["count"] = 1,
									["amount"] = 894,
								},
								["Hit"] = {
									["max"] = 650,
									["min"] = 384,
									["count"] = 9,
									["amount"] = 4346,
								},
							},
							["count"] = 17,
							["amount"] = 5240,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 31.35,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ActiveTime"] = 31.35,
					["Overhealing"] = 1467,
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 652,
									["min"] = 652,
									["count"] = 1,
									["amount"] = 652,
								},
							},
							["count"] = 1,
							["amount"] = 652,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 163,
									["min"] = 163,
									["count"] = 5,
									["amount"] = 815,
								},
							},
							["count"] = 5,
							["amount"] = 815,
						},
					},
					["EnergyGained"] = {
						["Go for the Throat"] = {
							["Details"] = {
								["Praxia"] = {
									["count"] = 900,
								},
							},
							["amount"] = 900,
						},
					},
					["HOT_Time"] = 18,
					["TimeSpent"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 20,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 17,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 585,
									["min"] = 392,
									["count"] = 13,
									["amount"] = 6317,
								},
							},
							["count"] = 20,
							["amount"] = 6317,
						},
						["Bite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 894,
									["min"] = 894,
									["count"] = 1,
									["amount"] = 894,
								},
								["Hit"] = {
									["max"] = 650,
									["min"] = 384,
									["count"] = 9,
									["amount"] = 4346,
								},
							},
							["count"] = 17,
							["amount"] = 5240,
						},
					},
					["EnergyGain"] = 900,
					["ElementDone"] = {
						["Melee"] = 6317,
						["Physical"] = 5240,
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 525,
								},
								["Bite"] = {
									["count"] = 392,
								},
							},
							["amount"] = 917,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5792,
								},
								["Bite"] = {
									["count"] = 4848,
								},
							},
							["amount"] = 10640,
						},
					},
					["TimeDamage"] = 31.35,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.53,
								},
								["Bite"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 1.8,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19.39,
								},
								["Bite"] = {
									["count"] = 10.16,
								},
							},
							["amount"] = 29.55,
						},
					},
					["EnergyGainedFrom"] = {
						["Praxia"] = {
							["Details"] = {
								["Go for the Throat"] = {
									["count"] = 900,
								},
							},
							["amount"] = 900,
						},
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Stormfang <Praxia>"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 11557,
				},
			},
			["UnitLockout"] = 1604180039,
			["LastActive"] = 1604180068,
		},
	},
	["FightNum"] = 3,
	["CombatTimes"] = {
		{
			1604180014, -- [1]
			1604180022, -- [2]
			"22:33:35", -- [3]
			"22:33:42", -- [4]
			"Fallen Champion", -- [5]
		}, -- [1]
		{
			1604180030, -- [1]
			1604180034, -- [2]
			"22:33:51", -- [3]
			"22:33:54", -- [4]
			"Unfettered Spirit", -- [5]
		}, -- [2]
		{
			1604180037, -- [1]
			1604180073, -- [2]
			"22:33:58", -- [3]
			"22:34:33", -- [4]
			"Headless Horseman", -- [5]
		}, -- [3]
	},
	["FoughtWho"] = {
		"Headless Horseman 22:33:58-22:34:33", -- [1]
		"Unfettered Spirit 22:33:51-22:33:54", -- [2]
		"Fallen Champion 22:33:35-22:33:42", -- [3]
	},
}
