
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				true, -- [4]
			},
			["itemFrameColumns"] = 15,
			["y"] = -155.0361696690146,
			["x"] = -54.31357012779722,
		},
		["keys"] = {
			["y"] = 149.9999976748339,
			["x"] = -350.0000179174567,
		},
		["guildbank"] = {
			["point"] = "TOPLEFT",
			["y"] = -134.9999489891021,
		},
		["bank"] = {
			["y"] = -47.18522567549667,
			["x"] = 191.7899800521261,
			["point"] = "TOPLEFT",
		},
	},
	["version"] = "2.13.3",
}
