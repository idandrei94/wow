
DBM_SavedOptions = {
	["SpecialWarningFontSize"] = 50,
	["ShowWarningsInChat"] = true,
	["DontSetIcons"] = false,
	["BigBrotherAnnounceToRaid"] = false,
	["ArrowPosX"] = 0,
	["HPFramePoint"] = "CENTER",
	["AutoRespond"] = true,
	["HealthFrameGrowUp"] = false,
	["StatusEnabled"] = true,
	["HideBossEmoteFrame"] = false,
	["ShowBigBrotherOnCombatStart"] = false,
	["BlockVersionUpdatePopup"] = true,
	["WarningColors"] = {
		{
			["b"] = 0.9411764705882353,
			["g"] = 0.8,
			["r"] = 0.4117647058823529,
		}, -- [1]
		{
			["b"] = 0,
			["g"] = 0.9490196078431372,
			["r"] = 0.9490196078431372,
		}, -- [2]
		{
			["b"] = 0,
			["g"] = 0.5019607843137255,
			["r"] = 1,
		}, -- [3]
		{
			["b"] = 0.1019607843137255,
			["g"] = 0.1019607843137255,
			["r"] = 1,
		}, -- [4]
	},
	["RangeFrameY"] = 16.79001704962267,
	["SpecialWarningFont"] = "Fonts\\FRIZQT__.TTF",
	["SpamBlockRaidWarning"] = true,
	["ShowFakedRaidWarnings"] = false,
	["LatencyThreshold"] = 250,
	["DontSendBossAnnounces"] = false,
	["HPFrameMaxEntries"] = 5,
	["WarningIconRight"] = true,
	["RangeFramePoint"] = "LEFT",
	["SpecialWarningPoint"] = "CENTER",
	["ShowSpecialWarnings"] = true,
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["DontShowBossAnnounces"] = false,
	["SpecialWarningY"] = 75,
	["RangeFrameSound2"] = "none",
	["AlwaysShowHealthFrame"] = false,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["RangeFrameX"] = 253.6489145474772,
	["Enabled"] = true,
	["RangeFrameSound1"] = "none",
	["WarningIconLeft"] = true,
	["HealthFrameWidth"] = 200,
	["SpecialWarningFontColor"] = {
		0, -- [1]
		0, -- [2]
		1, -- [3]
	},
	["DontSendBossWhispers"] = false,
	["RangeFrameLocked"] = false,
	["HPFrameY"] = 49.99998755352242,
	["FixCLEUOnCombatStart"] = false,
	["SpecialWarningX"] = 0,
	["ShowMinimapButton"] = true,
	["HPFrameX"] = -89.50611187017148,
	["HealthFrameLocked"] = false,
	["SpamBlockBossWhispers"] = false,
	["ArrowPosY"] = -150,
	["ArrowPoint"] = "TOP",
}
DBT_SavedOptions = {
	["DBM"] = {
		["HugeTimerPoint"] = "CENTER",
		["TimerPoint"] = "TOPRIGHT",
		["TimerX"] = -223.0000166180992,
		["HugeTimerX"] = 0,
		["HugeTimerY"] = -120.0000016412938,
		["TimerY"] = -260.0000123097031,
	},
}
