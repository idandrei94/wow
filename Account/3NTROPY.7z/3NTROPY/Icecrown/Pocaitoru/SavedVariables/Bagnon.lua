
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 12,
			["y"] = -27.5161714963217,
			["x"] = -169.638799527663,
		},
		["keys"] = {
			["y"] = 149.9999976748339,
			["x"] = -350.0001579745232,
		},
		["bank"] = {
			["y"] = -117.9014390795187,
			["x"] = 42.50789301582324,
			["point"] = "TOPLEFT",
			["itemFrameColumns"] = 15,
		},
	},
	["version"] = "2.13.3",
}
