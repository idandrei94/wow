
DBM_SavedOptions = {
	["SpecialWarningFontSize"] = 50,
	["ShowWarningsInChat"] = true,
	["DontSetIcons"] = false,
	["BigBrotherAnnounceToRaid"] = false,
	["ArrowPosX"] = 0,
	["HPFramePoint"] = "CENTER",
	["AutoRespond"] = true,
	["HealthFrameGrowUp"] = false,
	["StatusEnabled"] = true,
	["HideBossEmoteFrame"] = false,
	["ShowBigBrotherOnCombatStart"] = false,
	["BlockVersionUpdatePopup"] = true,
	["WarningColors"] = {
		{
			["b"] = 0.9411764705882353,
			["g"] = 0.8,
			["r"] = 0.4117647058823529,
		}, -- [1]
		{
			["b"] = 0,
			["g"] = 0.9490196078431372,
			["r"] = 0.9490196078431372,
		}, -- [2]
		{
			["b"] = 0,
			["g"] = 0.5019607843137255,
			["r"] = 1,
		}, -- [3]
		{
			["b"] = 0.1019607843137255,
			["g"] = 0.1019607843137255,
			["r"] = 1,
		}, -- [4]
	},
	["RangeFrameY"] = 117.1064314027091,
	["SpecialWarningFont"] = "Fonts\\FRIZQT__.TTF",
	["SpamBlockRaidWarning"] = true,
	["ShowFakedRaidWarnings"] = false,
	["LatencyThreshold"] = 250,
	["DontSendBossAnnounces"] = false,
	["HPFrameMaxEntries"] = 5,
	["WarningIconRight"] = true,
	["RangeFramePoint"] = "BOTTOM",
	["SpecialWarningPoint"] = "CENTER",
	["ShowSpecialWarnings"] = true,
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["DontShowBossAnnounces"] = false,
	["SpecialWarningY"] = 75,
	["RangeFrameSound2"] = "none",
	["AlwaysShowHealthFrame"] = false,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["RangeFrameX"] = 119.9256838604268,
	["Enabled"] = true,
	["RangeFrameLocked"] = false,
	["WarningIconLeft"] = true,
	["HealthFrameWidth"] = 200,
	["RangeFrameSound1"] = "none",
	["DontSendBossWhispers"] = false,
	["SpecialWarningFontColor"] = {
		0, -- [1]
		0, -- [2]
		1, -- [3]
	},
	["HPFrameY"] = -13.20948221901,
	["FixCLEUOnCombatStart"] = false,
	["SpecialWarningX"] = 0,
	["ShowMinimapButton"] = true,
	["HPFrameX"] = -340.7653902575949,
	["HealthFrameLocked"] = false,
	["SpamBlockBossWhispers"] = false,
	["ArrowPosY"] = -150,
	["ArrowPoint"] = "TOP",
}
DBT_SavedOptions = {
	["DBM"] = {
		["HugeTimerPoint"] = "CENTER",
		["TimerPoint"] = "TOPRIGHT",
		["TimerX"] = -223.0000166180992,
		["HugeTimerX"] = 0,
		["HugeTimerY"] = -120.0000016412938,
		["TimerY"] = -260.0000123097031,
	},
}
