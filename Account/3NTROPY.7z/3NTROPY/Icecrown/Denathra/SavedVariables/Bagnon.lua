
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				true, -- [4]
			},
			["itemFrameColumns"] = 13,
			["y"] = -76.86401833434536,
			["x"] = -110.1460591408743,
		},
		["keys"] = {
			["y"] = 149.9999976748339,
			["x"] = -350.0000179174567,
		},
		["bank"] = {
			["point"] = "TOPLEFT",
			["y"] = -11.8520491313077,
			["x"] = 283.2095690708041,
		},
	},
	["version"] = "2.13.3",
}
