
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				true, -- [4]
			},
			["itemFrameColumns"] = 13,
			["y"] = -145.5681719222374,
			["x"] = -145.307665778704,
		},
		["bank"] = {
			["y"] = -0,
			["x"] = 163.8222285138361,
		},
	},
	["version"] = "2.13.3",
}
