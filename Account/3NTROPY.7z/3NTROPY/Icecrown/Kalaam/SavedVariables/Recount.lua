
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Bossjinbei"] = {
			["GUID"] = "0x0700000000138285",
			["LastEventHealth"] = {
				"26117 (100%)", -- [1]
				"26117 (100%)", -- [2]
				"26117 (100%)", -- [3]
				"26117 (100%)", -- [4]
				"26117 (100%)", -- [5]
				"26117 (100%)", -- [6]
				"26117 (100%)", -- [7]
				"26117 (100%)", -- [8]
				"26117 (100%)", -- [9]
				"26117 (100%)", -- [10]
				"26117 (100%)", -- [11]
				"26117 (100%)", -- [12]
				"26117 (100%)", -- [13]
				"26117 (100%)", -- [14]
				"26117 (100%)", -- [15]
				"26117 (100%)", -- [16]
				"26117 (100%)", -- [17]
				"26117 (100%)", -- [18]
				"26117 (100%)", -- [19]
				"26117 (100%)", -- [20]
				"26117 (100%)", -- [21]
				"26117 (100%)", -- [22]
				"26117 (100%)", -- [23]
				"26117 (100%)", -- [24]
				"26117 (100%)", -- [25]
				"26117 (100%)", -- [26]
				"26117 (100%)", -- [27]
				"26117 (100%)", -- [28]
				"26117 (100%)", -- [29]
				"26117 (100%)", -- [30]
				"26117 (100%)", -- [31]
				"26117 (100%)", -- [32]
				"26117 (100%)", -- [33]
				"26117 (100%)", -- [34]
				"26117 (100%)", -- [35]
				"26117 (100%)", -- [36]
				"26117 (100%)", -- [37]
				"26117 (100%)", -- [38]
				"26117 (100%)", -- [39]
				"26117 (100%)", -- [40]
				"26117 (100%)", -- [41]
				"26117 (100%)", -- [42]
				"26117 (100%)", -- [43]
				"26117 (100%)", -- [44]
				"26117 (100%)", -- [45]
				"26117 (100%)", -- [46]
				"26117 (100%)", -- [47]
				"26117 (100%)", -- [48]
				"26117 (100%)", -- [49]
				"26117 (100%)", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["EnergyGain"] = {
					70, -- [1]
				},
				["HOT_Time"] = {
					9, -- [1]
				},
				["ActiveTime"] = {
					30.34, -- [1]
				},
				["Overhealing"] = {
					3288, -- [1]
				},
				["TimeDamage"] = {
					30.34, -- [1]
				},
				["DOT_Time"] = {
					9, -- [1]
				},
				["Damage"] = {
					55112, -- [1]
				},
			},
			["enClass"] = "ROGUE",
			["unit"] = "Bossjinbei",
			["level"] = 80,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[20] = 4.196500363747751,
				[38] = 4.196500363747751,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["EnergyGain"] = 1604179338,
				["Overhealing"] = 1604179327,
				["HOT_Time"] = 1604179327,
				["ActiveTime"] = 1604179334,
				["TimeDamage"] = 1604179334,
				["OVERALL"] = 1604179338,
				["DOT_Time"] = 1604179327,
				["Damage"] = 1604179331,
			},
			["Owner"] = false,
			["LastAbility"] = 1138116.416,
			["NextEventNum"] = 5,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Bossjinbei Melee Headless Horseman Immune", -- [1]
				"Bossjinbei Hemorrhage Headless Horseman Immune (Physical)", -- [2]
				"Bossjinbei Melee Headless Horseman Immune", -- [3]
				"Bossjinbei Melee Headless Horseman Immune", -- [4]
				"Bossjinbei Melee Headless Horseman Crit -752 (Physical)", -- [5]
				"Bossjinbei Hemorrhage Headless Horseman Crit -3594 (Physical)", -- [6]
				"Bossjinbei Melee Headless Horseman Miss", -- [7]
				"Bossjinbei Melee Headless Horseman Hit -1047 (Physical)", -- [8]
				"Bossjinbei Melee Headless Horseman Hit -446 (Physical)", -- [9]
				"Bossjinbei Melee Headless Horseman Hit -993 (Physical)", -- [10]
				"Bossjinbei Hemorrhage Headless Horseman Hit -1889 (Physical)", -- [11]
				"Bossjinbei Melee Headless Horseman Dodge", -- [12]
				"Bossjinbei Hemorrhage Headless Horseman Immune (Physical)", -- [13]
				"Bossjinbei Melee Headless Horseman Immune", -- [14]
				"Bossjinbei Rupture Headless Horseman Immune (Physical)", -- [15]
				"Bossjinbei Melee Headless Horseman Immune", -- [16]
				"Bossjinbei Rupture Headless Horseman Immune (Physical)", -- [17]
				"Bossjinbei Rupture Headless Horseman Immune (Physical)", -- [18]
				"Bossjinbei Rupture (DoT) Headless Horseman Tick -1167 (Physical)", -- [19]
				"Bossjinbei Improved Leader of the Pack Bossjinbei Tick +1096 (1096 overheal)", -- [20]
				"Bossjinbei Melee Headless Horseman Crit -2036 (Physical)", -- [21]
				"Bossjinbei Melee Headless Horseman Crit -740 (Physical)", -- [22]
				"Bossjinbei Hemorrhage Headless Horseman Hit -1633 (Physical)", -- [23]
				"Bossjinbei Melee Headless Horseman Hit -408 (Physical)", -- [24]
				"Bossjinbei Waylay Headless Horseman Immune (Physical)", -- [25]
				"Bossjinbei Backstab Headless Horseman Hit -2303 (Physical)", -- [26]
				"Bossjinbei Melee Headless Horseman Miss", -- [27]
				"Bossjinbei Rupture (DoT) Headless Horseman Crit -2334 (Physical)", -- [28]
				"Bossjinbei Waylay Headless Horseman Immune (Physical)", -- [29]
				"Bossjinbei Backstab Headless Horseman Crit -5400 (Physical)", -- [30]
				"Bossjinbei Melee Headless Horseman Crit -736 (Physical)", -- [31]
				"Bossjinbei Melee Headless Horseman Crit -1754 (Physical)", -- [32]
				"Bossjinbei Eviscerate Headless Horseman Immune (Physical)", -- [33]
				"Bossjinbei Rupture Headless Horseman Immune (Physical)", -- [34]
				"Bossjinbei Melee Headless Horseman Immune", -- [35]
				"Bossjinbei Rupture Headless Horseman Immune (Physical)", -- [36]
				"Bossjinbei Rupture (DoT) Headless Horseman Crit -2334 (Physical)", -- [37]
				"Bossjinbei Improved Leader of the Pack Bossjinbei Tick +1096 (1096 overheal)", -- [38]
				"Bossjinbei Melee Headless Horseman Crit -1486 (Physical)", -- [39]
				"Bossjinbei Hemorrhage Headless Horseman Hit -1367 (Physical)", -- [40]
				"Bossjinbei Melee Headless Horseman Hit -346 (Physical)", -- [41]
				"Bossjinbei Hemorrhage Headless Horseman Crit -2954 (Physical)", -- [42]
				"Bossjinbei Melee Headless Horseman Crit -722 (Physical)", -- [43]
				"Bossjinbei Melee Headless Horseman Crit -1604 (Physical)", -- [44]
				"Bossjinbei Melee Headless Horseman Hit -263 (Physical)", -- [45]
				"Bossjinbei Melee Headless Horseman Crit -1558 (Physical)", -- [46]
				"Bossjinbei Eviscerate Headless Horseman Hit -4382 (Physical)", -- [47]
				"Bossjinbei Melee Headless Horseman Miss", -- [48]
				"Bossjinbei Hemorrhage Headless Horseman Immune (Physical)", -- [49]
				"Bossjinbei Melee Headless Horseman Immune", -- [50]
			},
			["Name"] = "Bossjinbei",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138114.537, -- [1]
				1138115.787, -- [2]
				1138115.787, -- [3]
				1138116.416, -- [4]
				1138089.785, -- [5]
				1138090.809, -- [6]
				1138090.997, -- [7]
				1138091.324, -- [8]
				1138092.247, -- [9]
				1138092.82, -- [10]
				1138093.569, -- [11]
				1138093.569, -- [12]
				1138094.402, -- [13]
				1138094.579, -- [14]
				1138094.579, -- [15]
				1138095.137, -- [16]
				1138096.551, -- [17]
				1138098.484, -- [18]
				1138100.458, -- [19]
				1138100.817, -- [20]
				1138100.818, -- [21]
				1138100.966, -- [22]
				1138101.124, -- [23]
				1138102.096, -- [24]
				1138102.405, -- [25]
				1138102.406, -- [26]
				1138102.569, -- [27]
				1138102.569, -- [28]
				1138103.387, -- [29]
				1138103.388, -- [30]
				1138103.589, -- [31]
				1138104.177, -- [32]
				1138104.387, -- [33]
				1138104.568, -- [34]
				1138104.695, -- [35]
				1138106.512, -- [36]
				1138108.584, -- [37]
				1138108.765, -- [38]
				1138108.766, -- [39]
				1138108.933, -- [40]
				1138108.934, -- [41]
				1138110.036, -- [42]
				1138110.036, -- [43]
				1138110.364, -- [44]
				1138111.312, -- [45]
				1138112.664, -- [46]
				1138112.855, -- [47]
				1138112.855, -- [48]
				1138114.018, -- [49]
				1138114.378, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1096,
									["min"] = 1096,
									["count"] = 3,
									["amount"] = 3288,
								},
							},
							["count"] = 3,
							["amount"] = 3288,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGain"] = 66,
					["Overhealing"] = 3288,
					["ActiveTime"] = 30.34,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["Damage"] = 55112,
					["EnergyGained"] = {
						["Invigoration"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 16,
								},
							},
							["amount"] = 16,
						},
						["Relentless Strikes Effect"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 50,
								},
							},
							["amount"] = 50,
						},
					},
					["DOTs"] = {
						["Rupture (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Eviscerate"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4382,
									["min"] = 4382,
									["count"] = 1,
									["amount"] = 4382,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 4382,
						},
						["Ambush"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8808,
									["min"] = 8808,
									["count"] = 1,
									["amount"] = 8808,
								},
							},
							["count"] = 1,
							["amount"] = 8808,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2056,
									["min"] = 722,
									["count"] = 10,
									["amount"] = 13444,
								},
								["Hit"] = {
									["max"] = 1047,
									["min"] = 263,
									["count"] = 6,
									["amount"] = 3503,
								},
							},
							["count"] = 27,
							["amount"] = 16947,
						},
						["Backstab"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5400,
									["min"] = 5400,
									["count"] = 1,
									["amount"] = 5400,
								},
								["Hit"] = {
									["max"] = 2303,
									["min"] = 2303,
									["count"] = 1,
									["amount"] = 2303,
								},
							},
							["count"] = 2,
							["amount"] = 7703,
						},
						["Waylay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2334,
									["min"] = 2334,
									["count"] = 2,
									["amount"] = 4668,
								},
								["Tick"] = {
									["max"] = 1167,
									["min"] = 1167,
									["count"] = 1,
									["amount"] = 1167,
								},
							},
							["count"] = 3,
							["amount"] = 5835,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3594,
									["min"] = 2954,
									["count"] = 2,
									["amount"] = 6548,
								},
								["Hit"] = {
									["max"] = 1889,
									["min"] = 1367,
									["count"] = 3,
									["amount"] = 4889,
								},
							},
							["count"] = 8,
							["amount"] = 11437,
						},
						["Rupture"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 27,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 12,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 24,
						},
					},
					["TimeDamage"] = 30.34,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGainedFrom"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Invigoration"] = {
									["count"] = 16,
								},
								["Relentless Strikes Effect"] = {
									["count"] = 50,
								},
							},
							["amount"] = 66,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
					},
					["ElementDone"] = {
						["Melee"] = 16947,
						["Physical"] = 38165,
					},
				},
				["LastFightData"] = {
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1096,
									["min"] = 1096,
									["count"] = 3,
									["amount"] = 3288,
								},
							},
							["count"] = 3,
							["amount"] = 3288,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGain"] = 66,
					["Overhealing"] = 3288,
					["ActiveTime"] = 30.34,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["Damage"] = 55112,
					["EnergyGained"] = {
						["Invigoration"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 16,
								},
							},
							["amount"] = 16,
						},
						["Relentless Strikes Effect"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 50,
								},
							},
							["amount"] = 50,
						},
					},
					["DOTs"] = {
						["Rupture (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Eviscerate"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4382,
									["min"] = 4382,
									["count"] = 1,
									["amount"] = 4382,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 4382,
						},
						["Ambush"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8808,
									["min"] = 8808,
									["count"] = 1,
									["amount"] = 8808,
								},
							},
							["count"] = 1,
							["amount"] = 8808,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2056,
									["min"] = 722,
									["count"] = 10,
									["amount"] = 13444,
								},
								["Hit"] = {
									["max"] = 1047,
									["min"] = 263,
									["count"] = 6,
									["amount"] = 3503,
								},
							},
							["count"] = 27,
							["amount"] = 16947,
						},
						["Backstab"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5400,
									["min"] = 5400,
									["count"] = 1,
									["amount"] = 5400,
								},
								["Hit"] = {
									["max"] = 2303,
									["min"] = 2303,
									["count"] = 1,
									["amount"] = 2303,
								},
							},
							["count"] = 2,
							["amount"] = 7703,
						},
						["Waylay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2334,
									["min"] = 2334,
									["count"] = 2,
									["amount"] = 4668,
								},
								["Tick"] = {
									["max"] = 1167,
									["min"] = 1167,
									["count"] = 1,
									["amount"] = 1167,
								},
							},
							["count"] = 3,
							["amount"] = 5835,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3594,
									["min"] = 2954,
									["count"] = 2,
									["amount"] = 6548,
								},
								["Hit"] = {
									["max"] = 1889,
									["min"] = 1367,
									["count"] = 3,
									["amount"] = 4889,
								},
							},
							["count"] = 8,
							["amount"] = 11437,
						},
						["Rupture"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 27,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 12,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 24,
						},
					},
					["TimeDamage"] = 30.34,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGainedFrom"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Invigoration"] = {
									["count"] = 16,
								},
								["Relentless Strikes Effect"] = {
									["count"] = 50,
								},
							},
							["amount"] = 66,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
					},
					["ElementDone"] = {
						["Melee"] = 16947,
						["Physical"] = 38165,
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Invigoration"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 4,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["Invigoration"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1096,
									["min"] = 1096,
									["count"] = 3,
									["amount"] = 3288,
								},
							},
							["count"] = 3,
							["amount"] = 3288,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGain"] = 70,
					["Overhealing"] = 3288,
					["ActiveTime"] = 30.34,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["Damage"] = 55112,
					["EnergyGained"] = {
						["Invigoration"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Relentless Strikes Effect"] = {
							["Details"] = {
								["Bossjinbei"] = {
									["count"] = 50,
								},
							},
							["amount"] = 50,
						},
					},
					["DOTs"] = {
						["Rupture (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Eviscerate"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4382,
									["min"] = 4382,
									["count"] = 1,
									["amount"] = 4382,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 4382,
						},
						["Ambush"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8808,
									["min"] = 8808,
									["count"] = 1,
									["amount"] = 8808,
								},
							},
							["count"] = 1,
							["amount"] = 8808,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2056,
									["min"] = 722,
									["count"] = 10,
									["amount"] = 13444,
								},
								["Hit"] = {
									["max"] = 1047,
									["min"] = 263,
									["count"] = 6,
									["amount"] = 3503,
								},
							},
							["count"] = 27,
							["amount"] = 16947,
						},
						["Backstab"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5400,
									["min"] = 5400,
									["count"] = 1,
									["amount"] = 5400,
								},
								["Hit"] = {
									["max"] = 2303,
									["min"] = 2303,
									["count"] = 1,
									["amount"] = 2303,
								},
							},
							["count"] = 2,
							["amount"] = 7703,
						},
						["Waylay"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2334,
									["min"] = 2334,
									["count"] = 2,
									["amount"] = 4668,
								},
								["Tick"] = {
									["max"] = 1167,
									["min"] = 1167,
									["count"] = 1,
									["amount"] = 1167,
								},
							},
							["count"] = 3,
							["amount"] = 5835,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3594,
									["min"] = 2954,
									["count"] = 2,
									["amount"] = 6548,
								},
								["Hit"] = {
									["max"] = 1889,
									["min"] = 1367,
									["count"] = 3,
									["amount"] = 4889,
								},
							},
							["count"] = 8,
							["amount"] = 11437,
						},
						["Rupture"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 7,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 27,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 12,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 24,
						},
					},
					["TimeDamage"] = 30.34,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 0.4,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 9.49,
								},
								["Backstab"] = {
									["count"] = 0,
								},
								["Waylay"] = {
									["count"] = 4.63,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.04,
								},
								["Hemorrhage"] = {
									["count"] = 6.44,
								},
								["Rupture"] = {
									["count"] = 5.34,
								},
							},
							["amount"] = 30.34,
						},
					},
					["EnergyGainedFrom"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Invigoration"] = {
									["count"] = 20,
								},
								["Relentless Strikes Effect"] = {
									["count"] = 50,
								},
							},
							["amount"] = 70,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
					},
					["ElementDone"] = {
						["Melee"] = 16947,
						["Physical"] = 38165,
					},
				},
			},
			["UnitLockout"] = 1604179308,
			["LastActive"] = 1604179338,
		},
		["Headless Horseman"] = {
			["GUID"] = "0xF130005C8200008A",
			["LastEventHealth"] = {
				"49890 (39%)", -- [1]
				"37792 (29%)", -- [2]
				"36367 (28%)", -- [3]
				"35965 (28%)", -- [4]
				"35965 (28%)", -- [5]
				"33592 (26%)", -- [6]
				"33592 (26%)", -- [7]
				"27935 (22%)", -- [8]
				"25557 (20%)", -- [9]
				"25557 (20%)", -- [10]
				"25557 (20%)", -- [11]
				"25557 (20%)", -- [12]
				"20088 (15%)", -- [13]
				"14641 (11%)", -- [14]
				"8701 (6%)", -- [15]
				"8701 (6%)", -- [16]
				"7823 (6%)", -- [17]
				"6586 (5%)", -- [18]
				"6586 (5%)", -- [19]
				"4510 (3%)", -- [20]
				"3206 (2%)", -- [21]
				"3206 (2%)", -- [22]
				"2464 (1%)", -- [23]
				"2464 (1%)", -- [24]
				"1 (0%)", -- [25]
				"1 (0%)", -- [26]
				"1 (0%)", -- [27]
				"1 (0%)", -- [28]
				"1 (0%)", -- [29]
				"1 (0%)", -- [30]
				"1 (0%)", -- [31]
				"1 (0%)", -- [32]
				"5041 (4%)", -- [33]
				"5041 (4%)", -- [34]
				"5041 (4%)", -- [35]
				"5041 (4%)", -- [36]
				"5041 (4%)", -- [37]
				"5041 (4%)", -- [38]
				"5041 (4%)", -- [39]
				"5041 (4%)", -- [40]
				"10081 (8%)", -- [41]
				"10081 (8%)", -- [42]
				"10081 (8%)", -- [43]
				"10081 (8%)", -- [44]
				"10081 (8%)", -- [45]
				"0 (0%)", -- [46]
				"???", -- [47]
				"50923 (40%)", -- [48]
				"50923 (40%)", -- [49]
				"50563 (40%)", -- [50]
			},
			["LastAttackedBy"] = "Kalaam",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Damage"] = {
					13814, -- [1]
				},
				["TimeDamage"] = {
					26.3, -- [1]
				},
				["DamageTaken"] = {
					395534, -- [1]
				},
				["ActiveTime"] = {
					26.3, -- [1]
				},
			},
			["enClass"] = "MOB",
			["level"] = -1,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				0.5341269841269841, -- [1]
				9.601587301587301, -- [2]
				1.130952380952381, -- [3]
				0.319047619047619, -- [4]
				nil, -- [5]
				1.883333333333333, -- [6]
				4.054761904761905, -- [7]
				0.4349206349206349, -- [8]
				1.887301587301587, -- [9]
				1.706349206349206, -- [10]
				2.357142857142857, -- [11]
				0.276984126984127, -- [12]
				1.236507936507937, -- [13]
				4.323015873015873, -- [14]
				3.477777777777778, -- [15]
				[17] = 0.6968253968253968,
				[18] = 0.9817460317460317,
				[19] = 1.647619047619048,
				[20] = 1.034920634920635,
				[21] = 0.5888888888888889,
				[23] = 0.2365079365079365,
				[24] = 3.86031746031746,
				[48] = 0.2857142857142857,
			},
			["type"] = "Boss",
			["FightsSaved"] = 1,
			["LastAbility"] = 1138116.771,
			["LastDamageTaken"] = 4864,
			["Owner"] = false,
			["TimeLast"] = {
				["ActiveTime"] = 1604179335,
				["TimeDamage"] = 1604179335,
				["OVERALL"] = 1604179335,
				["DamageTaken"] = 1604179332,
				["Damage"] = 1604179335,
			},
			["NextEventNum"] = 48,
			["LastEventHealthNum"] = {
				39.5952380952381, -- [1]
				29.99365079365079, -- [2]
				28.86269841269841, -- [3]
				28.54365079365079, -- [4]
				28.54365079365079, -- [5]
				26.66031746031746, -- [6]
				26.66031746031746, -- [7]
				22.17063492063492, -- [8]
				20.28333333333334, -- [9]
				20.28333333333334, -- [10]
				20.28333333333334, -- [11]
				20.28333333333334, -- [12]
				15.94285714285714, -- [13]
				11.61984126984127, -- [14]
				6.905555555555556, -- [15]
				6.905555555555556, -- [16]
				6.208730158730159, -- [17]
				5.226984126984127, -- [18]
				5.226984126984127, -- [19]
				3.57936507936508, -- [20]
				2.544444444444444, -- [21]
				2.544444444444444, -- [22]
				1.955555555555556, -- [23]
				1.955555555555556, -- [24]
				0.0007936507936507937, -- [25]
				0.0007936507936507937, -- [26]
				0.0007936507936507937, -- [27]
				0.0007936507936507937, -- [28]
				0.0007936507936507937, -- [29]
				0.0007936507936507937, -- [30]
				0.0007936507936507937, -- [31]
				0.0007936507936507937, -- [32]
				4.000793650793651, -- [33]
				4.000793650793651, -- [34]
				4.000793650793651, -- [35]
				4.000793650793651, -- [36]
				4.000793650793651, -- [37]
				4.000793650793651, -- [38]
				4.000793650793651, -- [39]
				4.000793650793651, -- [40]
				8.000793650793652, -- [41]
				8.000793650793652, -- [42]
				8.000793650793652, -- [43]
				8.000793650793652, -- [44]
				8.000793650793652, -- [45]
				0, -- [46]
				0, -- [47]
				40.41507936507936, -- [48]
				40.41507936507936, -- [49]
				40.12936507936508, -- [50]
			},
			["LastEvents"] = {
				"Dinfaroth Steady Shot Headless Horseman Hit -673 (Physical)", -- [1]
				"Allzz Ferocious Bite Headless Horseman Crit -12098 (Physical)", -- [2]
				"Kalaam Deadly Poison IX (DoT) Headless Horseman Tick -1425 (Nature)", -- [3]
				"RawrxD <Dinfaroth> Bite Headless Horseman Hit -402 (Physical)", -- [4]
				"Kalaam Blade Twisting Headless Horseman Immune (Physical)", -- [5]
				"Kalaam Instant Poison IX Headless Horseman Crit -2373 (Nature)", -- [6]
				"Kalaam Melee Headless Horseman Crit -5109 (Physical)", -- [7]
				"Dinfaroth Auto Shot Headless Horseman Hit -548 (Physical)", -- [8]
				"Kalaam Instant Poison IX Headless Horseman Crit -2378 (Nature)", -- [9]
				"Kalaam Melee Headless Horseman Crit -2150 (Physical)", -- [10]
				"Allzz Melee Headless Horseman Crit -2970 (Physical)", -- [11]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -349 (Physical)", -- [12]
				"Bossjinbei Melee Headless Horseman Crit -1558 (Physical)", -- [13]
				"Kalaam Eviscerate Headless Horseman Hit -5447 (Physical)", -- [14]
				"Bossjinbei Eviscerate Headless Horseman Hit -4382 (Physical)", -- [15]
				"Bossjinbei Melee Headless Horseman Miss", -- [16]
				"Dkrobot Rune Strike Headless Horseman Hit -878 (Physical)", -- [17]
				"Kalaam Instant Poison IX Headless Horseman Hit -1237 (Nature)", -- [18]
				"Kalaam Melee Headless Horseman Crit -2076 (Physical)", -- [19]
				"Allzz Melee Headless Horseman Hit -1304 (Physical)", -- [20]
				"RawrxD <Dinfaroth> Melee Headless Horseman Crit -742 (Physical)", -- [21]
				"Headless Horseman Melee Dkrobot Hit -1764 (Physical)", -- [22]
				"Dkrobot Melee Headless Horseman Hit -298 (Physical)", -- [23]
				"Kalaam Melee Headless Horseman Crit -4864 (Physical)", -- [24]
				"Bossjinbei Hemorrhage Headless Horseman Immune (Physical)", -- [25]
				"RawrxD <Dinfaroth> Bite Headless Horseman Immune (Physical)", -- [26]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [27]
				"Bossjinbei Melee Headless Horseman Immune", -- [28]
				"Kalaam Melee Headless Horseman Immune", -- [29]
				"Allzz Melee Headless Horseman Immune", -- [30]
				"Bossjinbei Melee Headless Horseman Immune", -- [31]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [32]
				"Kalaam Melee Headless Horseman Immune", -- [33]
				"RawrxD <Dinfaroth> Growl Headless Horseman Immune (Physical)", -- [34]
				"Kalaam Deadly Poison IX Headless Horseman Immune (Nature)", -- [35]
				"Dkrobot Melee Headless Horseman Immune", -- [36]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [37]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [38]
				"Bossjinbei Hemorrhage Headless Horseman Immune (Physical)", -- [39]
				"Bossjinbei Melee Headless Horseman Immune", -- [40]
				"Dkrobot Melee Headless Horseman Immune", -- [41]
				"Bossjinbei Melee Headless Horseman Immune", -- [42]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [43]
				"Dinfaroth Serpent Sting Headless Horseman Immune (Nature)", -- [44]
				"Headless Horseman Horseman's Cleave Kalaam Hit -2366 (Physical)", -- [45]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [46]
				"Dinfaroth Kill Shot Headless Horseman Immune (Physical)", -- [47]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -360 (Physical)", -- [48]
				"Headless Horseman Melee Dkrobot Parry", -- [49]
				"Dkrobot Melee Headless Horseman Miss", -- [50]
			},
			["Name"] = "Headless Horseman",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				false, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				1138111.746, -- [1]
				1138111.747, -- [2]
				1138111.885, -- [3]
				1138112.077, -- [4]
				1138112.287, -- [5]
				1138112.288, -- [6]
				1138112.289, -- [7]
				1138112.447, -- [8]
				1138112.448, -- [9]
				1138112.449, -- [10]
				1138112.449, -- [11]
				1138112.449, -- [12]
				1138112.664, -- [13]
				1138112.665, -- [14]
				1138112.855, -- [15]
				1138112.855, -- [16]
				1138113.196, -- [17]
				1138113.199, -- [18]
				1138113.199, -- [19]
				1138113.427, -- [20]
				1138113.603, -- [21]
				1138113.603, -- [22]
				1138113.805, -- [23]
				1138113.807, -- [24]
				1138114.018, -- [25]
				1138114.018, -- [26]
				1138114.184, -- [27]
				1138114.378, -- [28]
				1138114.378, -- [29]
				1138114.379, -- [30]
				1138114.537, -- [31]
				1138114.538, -- [32]
				1138114.969, -- [33]
				1138115.147, -- [34]
				1138115.147, -- [35]
				1138115.49, -- [36]
				1138115.491, -- [37]
				1138115.493, -- [38]
				1138115.787, -- [39]
				1138115.787, -- [40]
				1138116.269, -- [41]
				1138116.416, -- [42]
				1138116.416, -- [43]
				1138116.417, -- [44]
				1138116.771, -- [45]
				1138116.959, -- [46]
				1138117.346, -- [47]
				1138111.504, -- [48]
				1138111.504, -- [49]
				1138111.746, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["PartialBlock"] = {
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 6,
									["amount"] = 240,
								},
							},
							["count"] = 6,
							["amount"] = 240,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
					["DamageTaken"] = 395534,
					["PartialResist"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.3,
					["ElementTaken"] = {
						["Arcane"] = 1049,
						["Physical"] = 247254,
						["Melee"] = 119294,
						["Nature"] = 27937,
					},
					["Damage"] = 13814,
					["ElementTakenBlock"] = {
						["Melee"] = 240,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1960,
									["min"] = 1764,
									["count"] = 6,
									["amount"] = 11448,
								},
							},
							["count"] = 9,
							["amount"] = 11448,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2366,
									["min"] = 2366,
									["count"] = 1,
									["amount"] = 2366,
								},
							},
							["count"] = 1,
							["amount"] = 2366,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["TimeDamage"] = 26.3,
					["WhoDamaged"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
						["Kalaam"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
						["Dinfaroth"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
						["RawrxD <Dinfaroth>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
					},
					["ElementDone"] = {
						["Melee"] = 11448,
						["Physical"] = 2366,
					},
					["ElementHitsTaken"] = {
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 33,
								},
								["Crit"] = {
									["count"] = 30,
								},
								["Hit"] = {
									["count"] = 31,
								},
							},
							["amount"] = 95,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 34,
								},
								["Hit"] = {
									["count"] = 31,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 35,
								},
								["Miss"] = {
									["count"] = 8,
								},
							},
							["amount"] = 109,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 31,
						},
					},
					["TimeDamaging"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
				},
				["LastFightData"] = {
					["PartialBlock"] = {
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 6,
									["amount"] = 240,
								},
							},
							["count"] = 6,
							["amount"] = 240,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
					["DamageTaken"] = 395534,
					["PartialResist"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.3,
					["ElementTaken"] = {
						["Arcane"] = 1049,
						["Physical"] = 247254,
						["Melee"] = 119294,
						["Nature"] = 27937,
					},
					["Damage"] = 13814,
					["ElementTakenBlock"] = {
						["Melee"] = 240,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1960,
									["min"] = 1764,
									["count"] = 6,
									["amount"] = 11448,
								},
							},
							["count"] = 9,
							["amount"] = 11448,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2366,
									["min"] = 2366,
									["count"] = 1,
									["amount"] = 2366,
								},
							},
							["count"] = 1,
							["amount"] = 2366,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["TimeDamage"] = 26.3,
					["WhoDamaged"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
						["Kalaam"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
						["Dinfaroth"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
						["RawrxD <Dinfaroth>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
					},
					["ElementDone"] = {
						["Melee"] = 11448,
						["Physical"] = 2366,
					},
					["ElementHitsTaken"] = {
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 33,
								},
								["Crit"] = {
									["count"] = 30,
								},
								["Hit"] = {
									["count"] = 31,
								},
							},
							["amount"] = 95,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 34,
								},
								["Hit"] = {
									["count"] = 31,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 35,
								},
								["Miss"] = {
									["count"] = 8,
								},
							},
							["amount"] = 109,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 31,
						},
					},
					["TimeDamaging"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["PartialBlock"] = {
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 40,
									["min"] = 40,
									["count"] = 6,
									["amount"] = 240,
								},
							},
							["count"] = 6,
							["amount"] = 240,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
					["DamageTaken"] = 395534,
					["PartialResist"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Blade Twisting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Rupture"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Steady Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Kill Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Backstab"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Killing Spree"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Waylay"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Rake"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Growl"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 109,
									["amount"] = 0,
								},
							},
							["count"] = 109,
							["amount"] = 0,
						},
						["Thorns"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 26.3,
					["ElementTaken"] = {
						["Arcane"] = 1049,
						["Physical"] = 247254,
						["Melee"] = 119294,
						["Nature"] = 27937,
					},
					["Damage"] = 13814,
					["ElementTakenBlock"] = {
						["Melee"] = 240,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1960,
									["min"] = 1764,
									["count"] = 6,
									["amount"] = 11448,
								},
							},
							["count"] = 9,
							["amount"] = 11448,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2366,
									["min"] = 2366,
									["count"] = 1,
									["amount"] = 2366,
								},
							},
							["count"] = 1,
							["amount"] = 2366,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["TimeDamage"] = 26.3,
					["WhoDamaged"] = {
						["Bossjinbei"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 4382,
								},
								["Ambush"] = {
									["count"] = 8808,
								},
								["Melee"] = {
									["count"] = 16947,
								},
								["Backstab"] = {
									["count"] = 7703,
								},
								["Hemorrhage"] = {
									["count"] = 11437,
								},
								["Rupture (DoT)"] = {
									["count"] = 5835,
								},
							},
							["amount"] = 55112,
						},
						["Kalaam"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
						["Dinfaroth"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
						["RawrxD <Dinfaroth>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
					},
					["ElementDone"] = {
						["Melee"] = 11448,
						["Physical"] = 2366,
					},
					["ElementHitsTaken"] = {
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 33,
								},
								["Crit"] = {
									["count"] = 30,
								},
								["Hit"] = {
									["count"] = 31,
								},
							},
							["amount"] = 95,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 34,
								},
								["Hit"] = {
									["count"] = 31,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 35,
								},
								["Miss"] = {
									["count"] = 8,
								},
							},
							["amount"] = 109,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 31,
						},
					},
					["TimeDamaging"] = {
						["Allzz"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.64,
								},
							},
							["amount"] = 18.64,
						},
						["Dkrobot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.49,
								},
							},
							["amount"] = 4.49,
						},
						["Kalaam"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 3.17,
								},
							},
							["amount"] = 3.17,
						},
					},
				},
			},
			["UnitLockout"] = 1604179335,
			["LastActive"] = 1604179335,
		},
		["Dinfaroth"] = {
			["GUID"] = "0x07000000005F763D",
			["LastEventHealth"] = {
				"16012 (100%)", -- [1]
				"16012 (100%)", -- [2]
				"16012 (100%)", -- [3]
				"16012 (100%)", -- [4]
				"16012 (100%)", -- [5]
				"16012 (100%)", -- [6]
				"16012 (100%)", -- [7]
				"16012 (100%)", -- [8]
				"16012 (100%)", -- [9]
				"16012 (100%)", -- [10]
				"16012 (100%)", -- [11]
				"16012 (100%)", -- [12]
				"16012 (100%)", -- [13]
				"16012 (100%)", -- [14]
				"16012 (100%)", -- [15]
				"16012 (100%)", -- [16]
				"16012 (100%)", -- [17]
				"16012 (100%)", -- [18]
				"16012 (100%)", -- [19]
				"16012 (100%)", -- [20]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
			},
			["TimeWindows"] = {
				["Damage"] = {
					5745, -- [1]
				},
				["TimeDamage"] = {
					22.73, -- [1]
				},
				["ActiveTime"] = {
					22.73, -- [1]
				},
			},
			["enClass"] = "HUNTER",
			["unit"] = "Dinfaroth",
			["level"] = 80,
			["LastFightIn"] = 1,
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["TimeLast"] = {
				["Damage"] = 1604179330,
				["OVERALL"] = 1604179335,
				["TimeDamage"] = 1604179335,
				["ActiveTime"] = 1604179335,
			},
			["LastAbility"] = 1138117.346,
			["Owner"] = false,
			["Pet"] = {
				"RawrxD <Dinfaroth>", -- [1]
			},
			["NextEventNum"] = 21,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
			},
			["LastEvents"] = {
				"Dinfaroth Serpent Sting Headless Horseman Immune (Nature)", -- [1]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [2]
				"Dinfaroth Aimed Shot Headless Horseman Hit -906 (Physical)", -- [3]
				"Dinfaroth Auto Shot Headless Horseman Hit -605 (Physical)", -- [4]
				"Dinfaroth Auto Shot Headless Horseman Hit -650 (Physical)", -- [5]
				"Dinfaroth Arcane Shot Headless Horseman Hit -1049 (Arcane)", -- [6]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [7]
				"Dinfaroth Steady Shot Headless Horseman Immune (Physical)", -- [8]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [9]
				"Dinfaroth Steady Shot Headless Horseman Immune (Physical)", -- [10]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [11]
				"Dinfaroth Steady Shot Headless Horseman Hit -675 (Physical)", -- [12]
				"Dinfaroth Auto Shot Headless Horseman Hit -639 (Physical)", -- [13]
				"Dinfaroth Steady Shot Headless Horseman Hit -673 (Physical)", -- [14]
				"Dinfaroth Auto Shot Headless Horseman Hit -548 (Physical)", -- [15]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [16]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [17]
				"Dinfaroth Serpent Sting Headless Horseman Immune (Nature)", -- [18]
				"Dinfaroth Auto Shot Headless Horseman Immune (Physical)", -- [19]
				"Dinfaroth Kill Shot Headless Horseman Immune (Physical)", -- [20]
			},
			["Name"] = "Dinfaroth",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
			},
			["LastEventTimes"] = {
				1138098.118, -- [1]
				1138098.511, -- [2]
				1138100.457, -- [3]
				1138100.658, -- [4]
				1138102.766, -- [5]
				1138102.766, -- [6]
				1138104.695, -- [7]
				1138105.85, -- [8]
				1138106.2, -- [9]
				1138109.158, -- [10]
				1138109.158, -- [11]
				1138109.821, -- [12]
				1138110.364, -- [13]
				1138111.746, -- [14]
				1138112.447, -- [15]
				1138114.184, -- [16]
				1138115.493, -- [17]
				1138116.416, -- [18]
				1138116.959, -- [19]
				1138117.346, -- [20]
			},
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 10,
								},
							},
							["amount"] = 17,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 5745,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Arcane"] = 1049,
						["Physical"] = 4696,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 22.73,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Steady Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 675,
									["min"] = 673,
									["count"] = 2,
									["amount"] = 1348,
								},
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 1348,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 906,
									["min"] = 906,
									["count"] = 1,
									["amount"] = 906,
								},
							},
							["count"] = 1,
							["amount"] = 906,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 650,
									["min"] = 548,
									["count"] = 4,
									["amount"] = 2442,
								},
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 2442,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1049,
									["min"] = 1049,
									["count"] = 1,
									["amount"] = 1049,
								},
							},
							["count"] = 1,
							["amount"] = 1049,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 22.73,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 10,
								},
							},
							["amount"] = 17,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 5745,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Arcane"] = 1049,
						["Physical"] = 4696,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 22.73,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Steady Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 675,
									["min"] = 673,
									["count"] = 2,
									["amount"] = 1348,
								},
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 1348,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 906,
									["min"] = 906,
									["count"] = 1,
									["amount"] = 906,
								},
							},
							["count"] = 1,
							["amount"] = 906,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 650,
									["min"] = 548,
									["count"] = 4,
									["amount"] = 2442,
								},
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 2442,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1049,
									["min"] = 1049,
									["count"] = 1,
									["amount"] = 1049,
								},
							},
							["count"] = 1,
							["amount"] = 1049,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 22.73,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["ElementDone"] = {
						["Arcane"] = 1049,
						["Physical"] = 4696,
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Auto Shot"] = {
									["count"] = 2442,
								},
								["Steady Shot"] = {
									["count"] = 1348,
								},
								["Aimed Shot"] = {
									["count"] = 906,
								},
								["Arcane Shot"] = {
									["count"] = 1049,
								},
							},
							["amount"] = 5745,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Immune"] = {
									["count"] = 10,
								},
							},
							["amount"] = 17,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeDamage"] = 22.73,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Steady Shot"] = {
									["count"] = 6.16,
								},
								["Kill Shot"] = {
									["count"] = 0.39,
								},
								["Aimed Shot"] = {
									["count"] = 1.95,
								},
								["Auto Shot"] = {
									["count"] = 9.809999999999999,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting"] = {
									["count"] = 4.42,
								},
							},
							["amount"] = 22.73,
						},
					},
					["Attacks"] = {
						["Steady Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 675,
									["min"] = 673,
									["count"] = 2,
									["amount"] = 1348,
								},
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 1348,
						},
						["Kill Shot"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aimed Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 906,
									["min"] = 906,
									["count"] = 1,
									["amount"] = 906,
								},
							},
							["count"] = 1,
							["amount"] = 906,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 650,
									["min"] = 548,
									["count"] = 4,
									["amount"] = 2442,
								},
								["Immune"] = {
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 2442,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1049,
									["min"] = 1049,
									["count"] = 1,
									["amount"] = 1049,
								},
							},
							["count"] = 1,
							["amount"] = 1049,
						},
						["Serpent Sting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 22.73,
					["Damage"] = 5745,
				},
			},
			["UnitLockout"] = 1604179279,
			["LastActive"] = 1604179335,
		},
		["Dkrobot"] = {
			["GUID"] = "0x07000000005C3505",
			["LastEventHealth"] = {
				"17107 (90%)", -- [1]
				"17902 (94%)", -- [2]
				"17902 (94%)", -- [3]
				"17902 (94%)", -- [4]
				"17902 (94%)", -- [5]
				"17902 (94%)", -- [6]
				"17902 (94%)", -- [7]
				"17902 (94%)", -- [8]
				"17902 (94%)", -- [9]
				"17902 (94%)", -- [10]
				"17902 (94%)", -- [11]
				"17902 (94%)", -- [12]
				"17902 (94%)", -- [13]
				"17902 (94%)", -- [14]
				"18697 (98%)", -- [15]
				"18697 (98%)", -- [16]
				"18697 (98%)", -- [17]
				"18697 (98%)", -- [18]
				"18697 (98%)", -- [19]
				"18697 (98%)", -- [20]
				"18697 (98%)", -- [21]
				"18697 (98%)", -- [22]
				"18697 (98%)", -- [23]
				"18697 (98%)", -- [24]
				"18697 (98%)", -- [25]
				"18697 (98%)", -- [26]
				"16933 (89%)", -- [27]
				"17692 (89%)", -- [28]
				"17692 (89%)", -- [29]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					25.75, -- [1]
				},
				["TimeHeal"] = {
					3.69, -- [1]
				},
				["HOT_Time"] = {
					6, -- [1]
				},
				["ActiveTime"] = {
					29.44, -- [1]
				},
				["HealingTaken"] = {
					1590, -- [1]
				},
				["Healing"] = {
					1590, -- [1]
				},
				["DamageTaken"] = {
					1764, -- [1]
				},
				["Damage"] = {
					9742, -- [1]
				},
			},
			["enClass"] = "DEATHKNIGHT",
			["unit"] = "Dkrobot",
			["level"] = 80,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[26] = 9.296932644671657,
				[15] = 4.189944134078212,
				[2] = 4.189944134078212,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["LastDamageTaken"] = 1764,
			["TimeLast"] = {
				["TimeHeal"] = 1604179320,
				["OVERALL"] = 1604179334,
				["DamageTaken"] = 1604179332,
				["HealingTaken"] = 1604179320,
				["HOT_Time"] = 1604179320,
				["TimeDamage"] = 1604179334,
				["ActiveTime"] = 1604179334,
				["Healing"] = 1604179320,
				["Damage"] = 1604179332,
			},
			["Owner"] = false,
			["LastAbility"] = 1138116.269,
			["NextEventNum"] = 30,
			["LastEventHealthNum"] = {
				90.16021924739117, -- [1]
				94.35016338146939, -- [2]
				94.35016338146939, -- [3]
				94.35016338146939, -- [4]
				94.35016338146939, -- [5]
				94.35016338146939, -- [6]
				94.35016338146939, -- [7]
				94.35016338146939, -- [8]
				94.35016338146939, -- [9]
				94.35016338146939, -- [10]
				94.35016338146939, -- [11]
				94.35016338146939, -- [12]
				94.35016338146939, -- [13]
				94.35016338146939, -- [14]
				98.54010751554759, -- [15]
				98.54010751554759, -- [16]
				98.54010751554759, -- [17]
				98.54010751554759, -- [18]
				98.54010751554759, -- [19]
				98.54010751554759, -- [20]
				98.54010751554759, -- [21]
				98.54010751554759, -- [22]
				98.54010751554759, -- [23]
				98.54010751554759, -- [24]
				98.54010751554759, -- [25]
				98.54010751554759, -- [26]
				89.24317487087593, -- [27]
				89.24085750315258, -- [28]
				89.24085750315258, -- [29]
			},
			["LastEvents"] = {
				"Dkrobot Melee Headless Horseman Hit -623 (Physical)", -- [1]
				"Dkrobot Improved Leader of the Pack Dkrobot Tick +795", -- [2]
				"Dkrobot Melee Headless Horseman Crit -620 (Physical)", -- [3]
				"Dkrobot Heart Strike Headless Horseman Hit -980 (Physical)", -- [4]
				"Dkrobot Melee Headless Horseman Miss", -- [5]
				"Dkrobot Melee Headless Horseman Hit -394 (Physical)", -- [6]
				"Dkrobot Death Strike Headless Horseman Hit -959 (Physical)", -- [7]
				"Dkrobot Heart Strike Headless Horseman Hit -947 (Physical)", -- [8]
				"Dkrobot Melee Headless Horseman Miss", -- [9]
				"Dkrobot Melee Headless Horseman Immune", -- [10]
				"Dkrobot Death Strike Headless Horseman Immune (Physical)", -- [11]
				"Dkrobot Melee Headless Horseman Immune", -- [12]
				"Dkrobot Melee Headless Horseman Immune", -- [13]
				"Dkrobot Melee Headless Horseman Immune", -- [14]
				"Dkrobot Improved Leader of the Pack Dkrobot Tick +795", -- [15]
				"Dkrobot Melee Headless Horseman Crit -1242 (Physical)", -- [16]
				"Dkrobot Melee Headless Horseman Miss", -- [17]
				"Dkrobot Heart Strike Headless Horseman Crit -2278 (Physical)", -- [18]
				"Dkrobot Melee Headless Horseman Immune", -- [19]
				"Dkrobot Melee Headless Horseman Immune", -- [20]
				"Dkrobot Death Strike Headless Horseman Immune (Physical)", -- [21]
				"Dkrobot Melee Headless Horseman Hit -523 (Physical)", -- [22]
				"Headless Horseman Melee Dkrobot Parry", -- [23]
				"Dkrobot Melee Headless Horseman Miss", -- [24]
				"Dkrobot Rune Strike Headless Horseman Hit -878 (Physical)", -- [25]
				"Headless Horseman Melee Dkrobot Hit -1764 (Physical)", -- [26]
				"Dkrobot Melee Headless Horseman Hit -298 (Physical)", -- [27]
				"Dkrobot Melee Headless Horseman Immune", -- [28]
				"Dkrobot Melee Headless Horseman Immune", -- [29]
			},
			["Name"] = "Dkrobot",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
			},
			["LastEventTimes"] = {
				1138088.974, -- [1]
				1138089.167, -- [2]
				1138089.167, -- [3]
				1138090.434, -- [4]
				1138091.157, -- [5]
				1138091.324, -- [6]
				1138091.711, -- [7]
				1138092.98, -- [8]
				1138093.569, -- [9]
				1138093.741, -- [10]
				1138094.402, -- [11]
				1138096.22, -- [12]
				1138098.076, -- [13]
				1138098.484, -- [14]
				1138102.239, -- [15]
				1138102.239, -- [16]
				1138102.569, -- [17]
				1138102.765, -- [18]
				1138104.856, -- [19]
				1138105.051, -- [20]
				1138105.551, -- [21]
				1138110.17, -- [22]
				1138111.504, -- [23]
				1138111.746, -- [24]
				1138113.196, -- [25]
				1138113.603, -- [26]
				1138113.805, -- [27]
				1138115.49, -- [28]
				1138116.269, -- [29]
			},
			["Fights"] = {
				["Fight1"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["TimeHealing"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
					},
					["TimeSpent"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["HealedWho"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 6,
					["ActiveTime"] = 29.44,
					["ElementTaken"] = {
						["Melee"] = 1764,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Dkrobot"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["Damage"] = 9742,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 795,
									["min"] = 795,
									["count"] = 2,
									["amount"] = 1590,
								},
							},
							["count"] = 2,
							["amount"] = 1590,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
					},
					["DamageTaken"] = 1764,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["Healing"] = 1590,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["Attacks"] = {
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 878,
									["min"] = 878,
									["count"] = 1,
									["amount"] = 878,
								},
							},
							["count"] = 1,
							["amount"] = 878,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2278,
									["min"] = 2278,
									["count"] = 1,
									["amount"] = 2278,
								},
								["Hit"] = {
									["max"] = 980,
									["min"] = 947,
									["count"] = 2,
									["amount"] = 1927,
								},
							},
							["count"] = 3,
							["amount"] = 4205,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 623,
									["min"] = 298,
									["count"] = 3,
									["amount"] = 1315,
								},
								["Hit (Blocked)"] = {
									["max"] = 523,
									["min"] = 523,
									["count"] = 1,
									["amount"] = 523,
								},
								["Crit"] = {
									["max"] = 1242,
									["min"] = 620,
									["count"] = 2,
									["amount"] = 1862,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 3700,
						},
						["Death Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 959,
									["min"] = 959,
									["count"] = 1,
									["amount"] = 959,
								},
							},
							["count"] = 3,
							["amount"] = 959,
						},
					},
					["HealingTaken"] = 1590,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
					},
					["TimeDamage"] = 25.75,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["TimeHeal"] = 3.69,
					["ElementDone"] = {
						["Melee"] = 3700,
						["Physical"] = 6042,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 18,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
					},
				},
				["LastFightData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["TimeHealing"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
					},
					["TimeSpent"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["HealedWho"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 6,
					["ActiveTime"] = 29.44,
					["ElementTaken"] = {
						["Melee"] = 1764,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Dkrobot"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["Damage"] = 9742,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 795,
									["min"] = 795,
									["count"] = 2,
									["amount"] = 1590,
								},
							},
							["count"] = 2,
							["amount"] = 1590,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
					},
					["DamageTaken"] = 1764,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["Healing"] = 1590,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["Attacks"] = {
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 878,
									["min"] = 878,
									["count"] = 1,
									["amount"] = 878,
								},
							},
							["count"] = 1,
							["amount"] = 878,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2278,
									["min"] = 2278,
									["count"] = 1,
									["amount"] = 2278,
								},
								["Hit"] = {
									["max"] = 980,
									["min"] = 947,
									["count"] = 2,
									["amount"] = 1927,
								},
							},
							["count"] = 3,
							["amount"] = 4205,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 623,
									["min"] = 298,
									["count"] = 3,
									["amount"] = 1315,
								},
								["Hit (Blocked)"] = {
									["max"] = 523,
									["min"] = 523,
									["count"] = 1,
									["amount"] = 523,
								},
								["Crit"] = {
									["max"] = 1242,
									["min"] = 620,
									["count"] = 2,
									["amount"] = 1862,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 3700,
						},
						["Death Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 959,
									["min"] = 959,
									["count"] = 1,
									["amount"] = 959,
								},
							},
							["count"] = 3,
							["amount"] = 959,
						},
					},
					["HealingTaken"] = 1590,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
					},
					["TimeDamage"] = 25.75,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["TimeHeal"] = 3.69,
					["ElementDone"] = {
						["Melee"] = 3700,
						["Physical"] = 6042,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 18,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["TimeHealing"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
					},
					["TimeSpent"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 3.69,
								},
							},
							["amount"] = 3.69,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["HealedWho"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 6,
					["ActiveTime"] = 29.44,
					["ElementTaken"] = {
						["Melee"] = 1764,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Dkrobot"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["Damage"] = 9742,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 795,
									["min"] = 795,
									["count"] = 2,
									["amount"] = 1590,
								},
							},
							["count"] = 2,
							["amount"] = 1590,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1764,
								},
							},
							["amount"] = 1764,
						},
					},
					["DamageTaken"] = 1764,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["Healing"] = 1590,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Dkrobot"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 1590,
								},
							},
							["amount"] = 1590,
						},
					},
					["Attacks"] = {
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 878,
									["min"] = 878,
									["count"] = 1,
									["amount"] = 878,
								},
							},
							["count"] = 1,
							["amount"] = 878,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2278,
									["min"] = 2278,
									["count"] = 1,
									["amount"] = 2278,
								},
								["Hit"] = {
									["max"] = 980,
									["min"] = 947,
									["count"] = 2,
									["amount"] = 1927,
								},
							},
							["count"] = 3,
							["amount"] = 4205,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 623,
									["min"] = 298,
									["count"] = 3,
									["amount"] = 1315,
								},
								["Hit (Blocked)"] = {
									["max"] = 523,
									["min"] = 523,
									["count"] = 1,
									["amount"] = 523,
								},
								["Crit"] = {
									["max"] = 1242,
									["min"] = 620,
									["count"] = 2,
									["amount"] = 1862,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 3700,
						},
						["Death Strike"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 959,
									["min"] = 959,
									["count"] = 1,
									["amount"] = 959,
								},
							},
							["count"] = 3,
							["amount"] = 959,
						},
					},
					["HealingTaken"] = 1590,
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 878,
								},
								["Heart Strike"] = {
									["count"] = 4205,
								},
								["Melee"] = {
									["count"] = 3700,
								},
								["Death Strike"] = {
									["count"] = 959,
								},
							},
							["amount"] = 9742,
						},
					},
					["TimeDamage"] = 25.75,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.45,
								},
								["Heart Strike"] = {
									["count"] = 2.74,
								},
								["Melee"] = {
									["count"] = 20.01,
								},
								["Death Strike"] = {
									["count"] = 1.55,
								},
							},
							["amount"] = 25.75,
						},
					},
					["TimeHeal"] = 3.69,
					["ElementDone"] = {
						["Melee"] = 3700,
						["Physical"] = 6042,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 18,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
					},
				},
			},
			["UnitLockout"] = 1604179307,
			["LastActive"] = 1604179334,
		},
		["RawrxD <Dinfaroth>"] = {
			["GUID"] = "0xF1402A59E0000001",
			["LastEventHealth"] = {
				"11320 (100%)", -- [1]
				"11320 (100%)", -- [2]
				"11320 (100%)", -- [3]
				"11320 (100%)", -- [4]
				"11320 (100%)", -- [5]
				"11320 (100%)", -- [6]
				"11320 (100%)", -- [7]
				"11320 (100%)", -- [8]
				"11320 (100%)", -- [9]
				"11320 (100%)", -- [10]
				"11320 (100%)", -- [11]
				"11320 (100%)", -- [12]
				"11320 (100%)", -- [13]
				"11320 (100%)", -- [14]
				"11320 (100%)", -- [15]
				"11320 (100%)", -- [16]
				"11320 (100%)", -- [17]
				"11320 (100%)", -- [18]
				"11320 (100%)", -- [19]
				"11320 (100%)", -- [20]
				"11320 (100%)", -- [21]
				"11320 (100%)", -- [22]
				"11320 (100%)", -- [23]
				"11320 (100%)", -- [24]
				"11320 (100%)", -- [25]
				"11320 (100%)", -- [26]
				"11320 (100%)", -- [27]
				"11320 (100%)", -- [28]
				"11320 (100%)", -- [29]
				"11320 (100%)", -- [30]
				"11320 (100%)", -- [31]
				"11320 (100%)", -- [32]
				"11320 (100%)", -- [33]
				"11320 (100%)", -- [34]
				"11320 (100%)", -- [35]
				"11320 (100%)", -- [36]
				"11320 (100%)", -- [37]
				"11320 (100%)", -- [38]
				"11320 (100%)", -- [39]
				"11320 (100%)", -- [40]
				"11320 (100%)", -- [41]
				"11320 (100%)", -- [42]
				"11320 (100%)", -- [43]
				"11320 (100%)", -- [44]
				"11320 (100%)", -- [45]
				"11320 (100%)", -- [46]
				"11320 (100%)", -- [47]
				"11320 (100%)", -- [48]
				"11320 (100%)", -- [49]
				"11320 (100%)", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"HEAL", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"HEAL", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
				"HEAL", -- [45]
				"HEAL", -- [46]
				"HEAL", -- [47]
				"HEAL", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Overhealing"] = {
					2364, -- [1]
				},
				["ActiveTime"] = {
					45.61000000000001, -- [1]
				},
				["HOT_Time"] = {
					42, -- [1]
				},
				["TimeDamage"] = {
					45.61000000000001, -- [1]
				},
				["Damage"] = {
					26478, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "RawrxD",
			["level"] = 1,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[14] = 1.042402826855124,
				[15] = 1.042402826855124,
				[8] = 1.042402826855124,
				[11] = 1.042402826855124,
				[43] = 1.042402826855124,
				[45] = 1.042402826855124,
				[47] = 1.042402826855124,
				[48] = 1.042402826855124,
				[24] = 4.187279151943463,
				[6] = 1.042402826855124,
				[46] = 1.042402826855124,
			},
			["type"] = "Pet",
			["FightsSaved"] = 2,
			["LastAbility"] = 1138116.416,
			["Owner"] = "Dinfaroth",
			["TimeLast"] = {
				["HOT_Time"] = 1604179327,
				["ActiveTime"] = 1604179334,
				["Overhealing"] = 1604179327,
				["OVERALL"] = 1604179334,
				["TimeDamage"] = 1604179334,
				["Damage"] = 1604179332,
			},
			["NextEventNum"] = 38,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Haunting Phantasm Melee RawrxD <Dinfaroth> Miss", -- [1]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [2]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [3]
				"RawrxD <Dinfaroth> Bite Haunting Phantasm Crit -1214 (Physical)", -- [4]
				"RawrxD <Dinfaroth> Melee Haunting Phantasm Crit -990 (Physical)", -- [5]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [6]
				"RawrxD <Dinfaroth> Melee Unfettered Spirit Crit -1040 (Physical)", -- [7]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [8]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [9]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [10]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [11]
				"RawrxD <Dinfaroth> Melee Unfettered Spirit Crit -1040 (Physical)", -- [12]
				"RawrxD <Dinfaroth> Bite Unfettered Spirit Crit -1097 (Physical)", -- [13]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [14]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [15]
				"RawrxD <Dinfaroth> Melee Headless Horseman Miss", -- [16]
				"RawrxD <Dinfaroth> Bite Headless Horseman Immune (Physical)", -- [17]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [18]
				"RawrxD <Dinfaroth> Monstrous Bite Headless Horseman Immune (Physical)", -- [19]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [20]
				"RawrxD <Dinfaroth> Bite Headless Horseman Immune (Physical)", -- [21]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [22]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -320 (Physical)", -- [23]
				"RawrxD <Dinfaroth> Improved Leader of the Pack RawrxD <Dinfaroth> Tick +474 (474 overheal)", -- [24]
				"RawrxD <Dinfaroth> Bite Headless Horseman Crit -680 (Physical)", -- [25]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -405 (Physical)", -- [26]
				"RawrxD <Dinfaroth> Bite Headless Horseman Hit -338 (Physical)", -- [27]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -414 (Physical)", -- [28]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -360 (Physical)", -- [29]
				"RawrxD <Dinfaroth> Bite Headless Horseman Hit -402 (Physical)", -- [30]
				"RawrxD <Dinfaroth> Melee Headless Horseman Hit -349 (Physical)", -- [31]
				"RawrxD <Dinfaroth> Melee Headless Horseman Crit -742 (Physical)", -- [32]
				"RawrxD <Dinfaroth> Bite Headless Horseman Immune (Physical)", -- [33]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [34]
				"RawrxD <Dinfaroth> Growl Headless Horseman Immune (Physical)", -- [35]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [36]
				"RawrxD <Dinfaroth> Melee Headless Horseman Immune", -- [37]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [38]
				"RawrxD <Dinfaroth> Melee Unfettered Spirit Hit -507 (Physical)", -- [39]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [40]
				"RawrxD <Dinfaroth> Monstrous Bite Unfettered Spirit Crit -997 (Physical)", -- [41]
				"RawrxD <Dinfaroth> Melee Unfettered Spirit Hit -542 (Physical)", -- [42]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [43]
				"RawrxD <Dinfaroth> Bite Unfettered Spirit Crit -1086 (Physical)", -- [44]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [45]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [46]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [47]
				"RawrxD <Dinfaroth> Bloodthirsty RawrxD <Dinfaroth> Tick +118 (118 overheal)", -- [48]
				"RawrxD <Dinfaroth> Melee Haunting Phantasm Crit -1044 (Physical)", -- [49]
				"Unfettered Spirit Melee RawrxD <Dinfaroth> Miss", -- [50]
			},
			["Name"] = "RawrxD",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				true, -- [43]
				false, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				1138092.981, -- [1]
				1138092.981, -- [2]
				1138092.981, -- [3]
				1138093.369, -- [4]
				1138093.743, -- [5]
				1138093.889, -- [6]
				1138094.772, -- [7]
				1138094.96, -- [8]
				1138095.138, -- [9]
				1138095.138, -- [10]
				1138095.872, -- [11]
				1138095.873, -- [12]
				1138096.55, -- [13]
				1138096.951, -- [14]
				1138097.865, -- [15]
				1138103.589, -- [16]
				1138104.181, -- [17]
				1138104.567, -- [18]
				1138105.39, -- [19]
				1138105.848, -- [20]
				1138106.94, -- [21]
				1138107.262, -- [22]
				1138108.583, -- [23]
				1138108.935, -- [24]
				1138108.935, -- [25]
				1138109.665, -- [26]
				1138110.583, -- [27]
				1138110.583, -- [28]
				1138111.504, -- [29]
				1138112.077, -- [30]
				1138112.449, -- [31]
				1138113.603, -- [32]
				1138114.018, -- [33]
				1138114.537, -- [34]
				1138115.147, -- [35]
				1138115.491, -- [36]
				1138116.416, -- [37]
				1138083.841, -- [38]
				1138083.841, -- [39]
				1138083.981, -- [40]
				1138084.18, -- [41]
				1138084.829, -- [42]
				1138085.153, -- [43]
				1138085.883, -- [44]
				1138086.191, -- [45]
				1138087.262, -- [46]
				1138088.203, -- [47]
				1138089.369, -- [48]
				1138092.82, -- [49]
				1138092.981, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 30,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 474,
									["min"] = 474,
									["count"] = 1,
									["amount"] = 474,
								},
							},
							["count"] = 1,
							["amount"] = 474,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 118,
									["min"] = 118,
									["count"] = 1,
									["amount"] = 118,
								},
							},
							["count"] = 1,
							["amount"] = 118,
						},
					},
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.96,
								},
								["Bite"] = {
									["count"] = 0.75,
								},
							},
							["amount"] = 2.71,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.9,
								},
								["Melee"] = {
									["count"] = 4.75,
								},
								["Monstrous Bite"] = {
									["count"] = 0.32,
								},
							},
							["amount"] = 5.97,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Veil of Shadow"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 6,
					["ActiveTime"] = 8.68,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Damage"] = 7425,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 6,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
					},
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 518,
									["min"] = 518,
									["count"] = 1,
									["amount"] = 518,
								},
								["Crit"] = {
									["max"] = 956,
									["min"] = 956,
									["count"] = 1,
									["amount"] = 956,
								},
								["Hit"] = {
									["max"] = 469,
									["min"] = 469,
									["count"] = 1,
									["amount"] = 469,
								},
							},
							["count"] = 3,
							["amount"] = 1943,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 988,
									["min"] = 868,
									["count"] = 4,
									["amount"] = 3734,
								},
								["Hit"] = {
									["max"] = 493,
									["min"] = 490,
									["count"] = 2,
									["amount"] = 983,
								},
							},
							["count"] = 6,
							["amount"] = 4717,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 765,
									["min"] = 765,
									["count"] = 1,
									["amount"] = 765,
								},
							},
							["count"] = 1,
							["amount"] = 765,
						},
					},
					["ElementDone"] = {
						["Melee"] = 4717,
						["Physical"] = 2708,
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2866,
								},
								["Bite"] = {
									["count"] = 518,
								},
							},
							["amount"] = 3384,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1425,
								},
								["Melee"] = {
									["count"] = 1851,
								},
								["Monstrous Bite"] = {
									["count"] = 765,
								},
							},
							["amount"] = 4041,
						},
					},
					["TimeDamage"] = 8.68,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.96,
								},
								["Bite"] = {
									["count"] = 0.75,
								},
							},
							["amount"] = 2.71,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.9,
								},
								["Melee"] = {
									["count"] = 4.75,
								},
								["Monstrous Bite"] = {
									["count"] = 0.32,
								},
							},
							["amount"] = 5.97,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Overhealing"] = 592,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Veil of Shadow"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 27,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 17,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 10435,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6704,
						["Physical"] = 3731,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2034,
								},
								["Bite"] = {
									["count"] = 1214,
								},
							},
							["amount"] = 3248,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1097,
								},
								["Melee"] = {
									["count"] = 2080,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3177,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 40,
						["Physical"] = 15,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 474,
									["min"] = 474,
									["count"] = 1,
									["amount"] = 474,
								},
							},
							["count"] = 1,
							["amount"] = 474,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 118,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 944,
								},
							},
							["count"] = 8,
							["amount"] = 944,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1418,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.6800000000000001,
								},
								["Melee"] = {
									["count"] = 2.13,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.81,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 23.54000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 1097,
									["min"] = 1097,
									["count"] = 1,
									["amount"] = 1097,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1214,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1894,
								},
								["Hit"] = {
									["max"] = 402,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 740,
								},
							},
							["count"] = 8,
							["amount"] = 3731,
						},
						["Growl"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 414,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 1528,
								},
								["Hit (Blocked)"] = {
									["max"] = 320,
									["min"] = 320,
									["count"] = 1,
									["amount"] = 320,
								},
								["Crit"] = {
									["max"] = 1044,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 4856,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 17,
							["amount"] = 6704,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 23.54000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.6800000000000001,
								},
								["Melee"] = {
									["count"] = 2.13,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.81,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 24,
								},
							},
							["amount"] = 24,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 27,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 17,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 10435,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6704,
						["Physical"] = 3731,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2034,
								},
								["Bite"] = {
									["count"] = 1214,
								},
							},
							["amount"] = 3248,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1097,
								},
								["Melee"] = {
									["count"] = 2080,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3177,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 40,
						["Physical"] = 15,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 474,
									["min"] = 474,
									["count"] = 1,
									["amount"] = 474,
								},
							},
							["count"] = 1,
							["amount"] = 474,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 118,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 944,
								},
							},
							["count"] = 8,
							["amount"] = 944,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1418,
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.6800000000000001,
								},
								["Melee"] = {
									["count"] = 2.13,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.81,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 23.54000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 1097,
									["min"] = 1097,
									["count"] = 1,
									["amount"] = 1097,
								},
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1214,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1894,
								},
								["Hit"] = {
									["max"] = 402,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 740,
								},
							},
							["count"] = 8,
							["amount"] = 3731,
						},
						["Growl"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 414,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 1528,
								},
								["Hit (Blocked)"] = {
									["max"] = 320,
									["min"] = 320,
									["count"] = 1,
									["amount"] = 320,
								},
								["Crit"] = {
									["max"] = 1044,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 4856,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 17,
							["amount"] = 6704,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 23.54000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0.6800000000000001,
								},
								["Melee"] = {
									["count"] = 2.13,
								},
								["Monstrous Bite"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.81,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 24,
								},
							},
							["amount"] = 24,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 40,
						["Physical"] = 60,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 474,
									["min"] = 474,
									["count"] = 2,
									["amount"] = 948,
								},
							},
							["count"] = 2,
							["amount"] = 948,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 118,
									["min"] = 118,
									["count"] = 12,
									["amount"] = 1416,
								},
							},
							["count"] = 12,
							["amount"] = 1416,
						},
					},
					["TimeSpent"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1.62,
								},
								["Melee"] = {
									["count"] = 6.19,
								},
								["Monstrous Bite"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 8.09,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.13,
								},
								["Melee"] = {
									["count"] = 13,
								},
								["Monstrous Bite"] = {
									["count"] = 0.66,
								},
							},
							["amount"] = 16.79,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Veil of Shadow"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 42,
					["ActiveTime"] = 45.61000000000001,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Bloodthirsty"] = {
							["Details"] = {
								["RawrxD <Dinfaroth>"] = {
									["count"] = 36,
								},
							},
							["amount"] = 36,
						},
					},
					["Damage"] = 26478,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 28,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 19,
						},
					},
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 542,
									["min"] = 338,
									["count"] = 4,
									["amount"] = 1751,
								},
								["Crit (Blocked)"] = {
									["max"] = 1097,
									["min"] = 1097,
									["count"] = 1,
									["amount"] = 1097,
								},
								["Crit"] = {
									["max"] = 1214,
									["min"] = 680,
									["count"] = 5,
									["amount"] = 5040,
								},
								["Hit (Blocked)"] = {
									["max"] = 518,
									["min"] = 518,
									["count"] = 1,
									["amount"] = 518,
								},
							},
							["count"] = 14,
							["amount"] = 8406,
						},
						["Growl"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 6,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 542,
									["min"] = 349,
									["count"] = 8,
									["amount"] = 3560,
								},
								["Hit (Blocked)"] = {
									["max"] = 320,
									["min"] = 320,
									["count"] = 1,
									["amount"] = 320,
								},
								["Crit"] = {
									["max"] = 1044,
									["min"] = 742,
									["count"] = 12,
									["amount"] = 11454,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 15334,
						},
						["Monstrous Bite"] = {
							["Details"] = {
								["Crit (Blocked)"] = {
									["max"] = 997,
									["min"] = 765,
									["count"] = 2,
									["amount"] = 1762,
								},
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 976,
									["min"] = 976,
									["count"] = 1,
									["amount"] = 976,
								},
							},
							["count"] = 4,
							["amount"] = 2738,
						},
					},
					["ElementDone"] = {
						["Melee"] = 15334,
						["Physical"] = 11144,
					},
					["DamagedWho"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2590,
								},
								["Bite"] = {
									["count"] = 1420,
								},
							},
							["amount"] = 4010,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1060,
								},
								["Melee"] = {
									["count"] = 4800,
								},
								["Monstrous Bite"] = {
									["count"] = 976,
								},
							},
							["amount"] = 6836,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2034,
								},
								["Bite"] = {
									["count"] = 1214,
								},
							},
							["amount"] = 3248,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 4712,
								},
								["Melee"] = {
									["count"] = 5910,
								},
								["Monstrous Bite"] = {
									["count"] = 1762,
								},
							},
							["amount"] = 12384,
						},
					},
					["TimeDamage"] = 45.61000000000001,
					["TimeDamaging"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.93,
								},
								["Growl"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 10.95,
								},
								["Monstrous Bite"] = {
									["count"] = 0.82,
								},
							},
							["amount"] = 16.31,
						},
						["Anguished Dead"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 1.62,
								},
								["Melee"] = {
									["count"] = 6.19,
								},
								["Monstrous Bite"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 8.09,
						},
						["Haunting Phantasm"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.87,
								},
								["Bite"] = {
									["count"] = 0.55,
								},
							},
							["amount"] = 4.42,
						},
						["Unfettered Spirit"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.13,
								},
								["Melee"] = {
									["count"] = 13,
								},
								["Monstrous Bite"] = {
									["count"] = 0.66,
								},
							},
							["amount"] = 16.79,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Overhealing"] = 2364,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Veil of Shadow"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
				},
			},
			["UnitLockout"] = 1604179279,
			["LastActive"] = 1604179334,
		},
		["Allzz"] = {
			["GUID"] = "0x070000000001D3A3",
			["LastEventHealth"] = {
				"25544 (84%)", -- [1]
				"25544 (84%)", -- [2]
				"25544 (84%)", -- [3]
				"25544 (84%)", -- [4]
				"25544 (84%)", -- [5]
				"25544 (84%)", -- [6]
				"25544 (84%)", -- [7]
				"26810 (88%)", -- [8]
				"26810 (88%)", -- [9]
				"29475 (97%)", -- [10]
				"29475 (97%)", -- [11]
				"29475 (97%)", -- [12]
				"29475 (97%)", -- [13]
				"29475 (97%)", -- [14]
				"29475 (97%)", -- [15]
				"29475 (97%)", -- [16]
				"29475 (97%)", -- [17]
				"29475 (97%)", -- [18]
				"28822 (95%)", -- [19]
				"28822 (95%)", -- [20]
				"28822 (95%)", -- [21]
				"28822 (95%)", -- [22]
				"28822 (95%)", -- [23]
				"28822 (95%)", -- [24]
				"28822 (95%)", -- [25]
				"28822 (95%)", -- [26]
				"28822 (95%)", -- [27]
				"28822 (95%)", -- [28]
				"30088 (99%)", -- [29]
				"30088 (99%)", -- [30]
				"30088 (99%)", -- [31]
				"30088 (99%)", -- [32]
				"30088 (99%)", -- [33]
				"28128 (93%)", -- [34]
				"28128 (93%)", -- [35]
				"28128 (93%)", -- [36]
				"28128 (93%)", -- [37]
				"28128 (93%)", -- [38]
				"28128 (93%)", -- [39]
				"26172 (86%)", -- [40]
				"26172 (86%)", -- [41]
				"26172 (86%)", -- [42]
				"26172 (86%)", -- [43]
				"26172 (86%)", -- [44]
				"26172 (86%)", -- [45]
				"27438 (90%)", -- [46]
				"27438 (90%)", -- [47]
				"27438 (90%)", -- [48]
				"27438 (90%)", -- [49]
				"25544 (84%)", -- [50]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"HEAL", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"HEAL", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"HEAL", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					5.61, -- [1]
				},
				["Healing"] = {
					6330, -- [1]
				},
				["DamageTaken"] = {
					9684, -- [1]
				},
				["EnergyGain"] = {
					60, -- [1]
				},
				["HealingTaken"] = {
					6330, -- [1]
				},
				["HOT_Time"] = {
					15, -- [1]
				},
				["TimeDamage"] = {
					27.07, -- [1]
				},
				["ActiveTime"] = {
					32.68, -- [1]
				},
				["ManaGain"] = {
					2800, -- [1]
				},
				["DOT_Time"] = {
					9, -- [1]
				},
				["Damage"] = {
					186133, -- [1]
				},
			},
			["enClass"] = "DRUID",
			["unit"] = "Allzz",
			["level"] = 80,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[49] = 6.27900808911285,
				[29] = 4.197056093356319,
				[46] = 4.197056093356319,
				[33] = 6.497811961278345,
				[18] = 6.361888343720992,
				[19] = 4.197056093356319,
				[39] = 6.484551120541043,
				[8] = 4.197056093356319,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["LastDamageTaken"] = 1894,
			["TimeLast"] = {
				["TimeHeal"] = 1604179334,
				["OVERALL"] = 1604179334,
				["DamageTaken"] = 1604179327,
				["ActiveTime"] = 1604179334,
				["EnergyGain"] = 1604179328,
				["HealingTaken"] = 1604179334,
				["HOT_Time"] = 1604179334,
				["TimeDamage"] = 1604179334,
				["Healing"] = 1604179334,
				["ManaGain"] = 1604179334,
				["DOT_Time"] = 1604179327,
				["Damage"] = 1604179334,
			},
			["Owner"] = false,
			["LastAbility"] = 1138116.27,
			["NextEventNum"] = 10,
			["LastEventHealthNum"] = {
				84.68372894841534, -- [1]
				84.68372894841534, -- [2]
				84.68372894841534, -- [3]
				84.68372894841534, -- [4]
				84.68372894841534, -- [5]
				84.68372894841534, -- [6]
				84.68372894841534, -- [7]
				88.88078504177165, -- [8]
				88.88078504177165, -- [9]
				97.71582018299961, -- [10]
				97.71582018299961, -- [11]
				97.71582018299961, -- [12]
				97.71582018299961, -- [13]
				97.71582018299961, -- [14]
				97.71582018299961, -- [15]
				97.71582018299961, -- [16]
				97.71582018299961, -- [17]
				97.71582018299961, -- [18]
				95.55098793263493, -- [19]
				95.55098793263493, -- [20]
				95.55098793263493, -- [21]
				95.55098793263493, -- [22]
				95.55098793263493, -- [23]
				95.55098793263493, -- [24]
				95.55098793263493, -- [25]
				95.55098793263493, -- [26]
				95.55098793263493, -- [27]
				95.55098793263493, -- [28]
				99.74804402599125, -- [29]
				99.74804402599125, -- [30]
				99.74804402599125, -- [31]
				99.74804402599125, -- [32]
				99.74804402599125, -- [33]
				93.2502320647129, -- [34]
				93.2502320647129, -- [35]
				93.2502320647129, -- [36]
				93.2502320647129, -- [37]
				93.2502320647129, -- [38]
				93.2502320647129, -- [39]
				86.76568094417186, -- [40]
				86.76568094417186, -- [41]
				86.76568094417186, -- [42]
				86.76568094417186, -- [43]
				86.76568094417186, -- [44]
				86.76568094417186, -- [45]
				90.96273703752819, -- [46]
				90.96273703752819, -- [47]
				90.96273703752819, -- [48]
				90.96273703752819, -- [49]
				84.68372894841534, -- [50]
			},
			["LastEvents"] = {
				"Allzz Melee Headless Horseman Crit -3022 (Physical)", -- [1]
				"Allzz Mangle (Cat) Headless Horseman Crit -8760 (Physical)", -- [2]
				"Allzz Melee Headless Horseman Crit -2866 (Physical)", -- [3]
				"Allzz Ferocious Bite Headless Horseman Crit -12098 (Physical)", -- [4]
				"Allzz Melee Headless Horseman Crit -2970 (Physical)", -- [5]
				"Allzz Melee Headless Horseman Hit -1304 (Physical)", -- [6]
				"Allzz Melee Headless Horseman Immune", -- [7]
				"Allzz Improved Leader of the Pack Allzz Tick +1266", -- [8]
				"Allzz Melee Head of the Horseman Crit -2630 (Physical)", -- [9]
				"Allzz Melee Headless Horseman Hit -1695 (Physical)", -- [10]
				"Allzz Melee Headless Horseman Hit -1799 (Physical)", -- [11]
				"Headless Horseman Melee Allzz Dodge", -- [12]
				"Allzz Melee Headless Horseman Hit -1766 (Physical)", -- [13]
				"Allzz Rake (DoT) Headless Horseman Crit -5205 (Physical)", -- [14]
				"Allzz Mangle (Cat) Headless Horseman Crit -11910 (Physical)", -- [15]
				"Allzz Melee Headless Horseman Crit -3913 (Physical)", -- [16]
				"Allzz Thorns Headless Horseman Hit -79 (Nature)", -- [17]
				"Headless Horseman Melee Allzz Hit -1919 (Physical)", -- [18]
				"Allzz Improved Leader of the Pack Allzz Tick +1266", -- [19]
				"Allzz Mangle (Cat) Headless Horseman Crit -11710 (Physical)", -- [20]
				"Allzz Melee Headless Horseman Immune", -- [21]
				"Allzz Melee Headless Horseman Immune", -- [22]
				"Allzz Rake Headless Horseman Immune (Physical)", -- [23]
				"Allzz Melee Head of the Horseman Crit -3795 (Physical)", -- [24]
				"Allzz Mangle (Cat) Head of the Horseman Crit -11296 (Physical)", -- [25]
				"Allzz Melee Head of the Horseman Hit -1676 (Physical)", -- [26]
				"Allzz Ferocious Bite Head of the Horseman Crit -16294 (Physical)", -- [27]
				"Allzz Rake Headless Horseman Immune (Physical)", -- [28]
				"Allzz Improved Leader of the Pack Allzz Tick +1266", -- [29]
				"Allzz Rake Headless Horseman Crit -1930 (Physical)", -- [30]
				"Allzz Melee Headless Horseman Hit -1826 (Physical)", -- [31]
				"Allzz Thorns Headless Horseman Hit -79 (Nature)", -- [32]
				"Headless Horseman Melee Allzz Hit -1960 (Physical)", -- [33]
				"Allzz Mangle (Cat) Headless Horseman Crit -11880 (Physical)", -- [34]
				"Allzz Melee Headless Horseman Hit -1797 (Physical)", -- [35]
				"Allzz Melee Headless Horseman Crit -4110 (Physical)", -- [36]
				"Allzz Ferocious Bite Headless Horseman Crit -19147 (Physical)", -- [37]
				"Allzz Thorns Headless Horseman Hit -79 (Nature)", -- [38]
				"Headless Horseman Melee Allzz Hit -1956 (Physical)", -- [39]
				"Allzz Melee Headless Horseman Crit -3920 (Physical)", -- [40]
				"Allzz Rake (DoT) Headless Horseman Crit -7545 (Physical)", -- [41]
				"Allzz Melee Headless Horseman Immune", -- [42]
				"Allzz Melee Headless Horseman Immune", -- [43]
				"Allzz Rake Headless Horseman Immune (Physical)", -- [44]
				"Allzz Melee Head of the Horseman Hit -1502 (Physical)", -- [45]
				"Allzz Improved Leader of the Pack Allzz Tick +1266", -- [46]
				"Allzz Mangle (Cat) Head of the Horseman Crit -10215 (Physical)", -- [47]
				"Allzz Thorns Headless Horseman Hit -79 (Nature)", -- [48]
				"Headless Horseman Melee Allzz Hit -1894 (Physical)", -- [49]
				"Allzz Rake (DoT) Headless Horseman Crit -7545 (Physical)", -- [50]
			},
			["Name"] = "Allzz",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				true, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				true, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138110.364, -- [1]
				1138110.582, -- [2]
				1138111.313, -- [3]
				1138111.746, -- [4]
				1138112.449, -- [5]
				1138113.427, -- [6]
				1138114.379, -- [7]
				1138116.27, -- [8]
				1138116.27, -- [9]
				1138090.236, -- [10]
				1138090.998, -- [11]
				1138091.157, -- [12]
				1138091.88, -- [13]
				1138091.88, -- [14]
				1138092.247, -- [15]
				1138092.616, -- [16]
				1138093.188, -- [17]
				1138093.188, -- [18]
				1138093.57, -- [19]
				1138093.571, -- [20]
				1138093.571, -- [21]
				1138094.403, -- [22]
				1138094.96, -- [23]
				1138096.221, -- [24]
				1138096.365, -- [25]
				1138097.101, -- [26]
				1138097.681, -- [27]
				1138097.865, -- [28]
				1138100.314, -- [29]
				1138100.314, -- [30]
				1138100.457, -- [31]
				1138101.126, -- [32]
				1138101.126, -- [33]
				1138101.503, -- [34]
				1138101.503, -- [35]
				1138102.239, -- [36]
				1138102.976, -- [37]
				1138103.17, -- [38]
				1138103.17, -- [39]
				1138103.388, -- [40]
				1138103.406, -- [41]
				1138104.18, -- [42]
				1138105.052, -- [43]
				1138106.348, -- [44]
				1138106.939, -- [45]
				1138107.442, -- [46]
				1138107.443, -- [47]
				1138109.113, -- [48]
				1138109.113, -- [49]
				1138109.31, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
						["Rake (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
					},
					["HealedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["HOT_Time"] = 15,
					["ElementTaken"] = {
						["Melee"] = 9684,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 186133,
					["TimeHeal"] = 5.61,
					["ElementDone"] = {
						["Physical"] = 139141,
						["Melee"] = 46597,
						["Nature"] = 395,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 18,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 24,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
					},
					["EnergyGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 120,
					},
					["TimeHealing"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 32.68,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1266,
									["min"] = 1266,
									["count"] = 5,
									["amount"] = 6330,
								},
							},
							["count"] = 5,
							["amount"] = 6330,
						},
					},
					["EnergyGain"] = 60,
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
					},
					["Healing"] = 6330,
					["DamageTaken"] = 9684,
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1766,
									["min"] = 1264,
									["count"] = 3,
									["amount"] = 4725,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4110,
									["min"] = 2177,
									["count"] = 10,
									["amount"] = 31968,
								},
								["Hit"] = {
									["max"] = 1826,
									["min"] = 1304,
									["count"] = 6,
									["amount"] = 9904,
								},
							},
							["count"] = 24,
							["amount"] = 46597,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7545,
									["min"] = 5205,
									["count"] = 3,
									["amount"] = 20295,
								},
							},
							["count"] = 3,
							["amount"] = 20295,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 19147,
									["min"] = 12098,
									["count"] = 3,
									["amount"] = 47539,
								},
							},
							["count"] = 3,
							["amount"] = 47539,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11910,
									["min"] = 8760,
									["count"] = 6,
									["amount"] = 65771,
								},
								["Hit"] = {
									["max"] = 3024,
									["min"] = 3024,
									["count"] = 1,
									["amount"] = 3024,
								},
							},
							["count"] = 7,
							["amount"] = 68795,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1930,
									["min"] = 1930,
									["count"] = 1,
									["amount"] = 1930,
								},
								["Hit"] = {
									["max"] = 582,
									["min"] = 582,
									["count"] = 1,
									["amount"] = 582,
								},
							},
							["count"] = 5,
							["amount"] = 2512,
						},
						["Thorns"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 79,
									["min"] = 79,
									["count"] = 5,
									["amount"] = 395,
								},
							},
							["count"] = 5,
							["amount"] = 395,
						},
					},
					["HealingTaken"] = 6330,
					["WhoHealed"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["TimeDamage"] = 27.07,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
					},
					["ManaGain"] = 2800,
					["ManaGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 16294,
								},
								["Mangle (Cat)"] = {
									["count"] = 21511,
								},
								["Melee"] = {
									["count"] = 9603,
								},
							},
							["amount"] = 47408,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Rake (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
					},
					["HealedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["HOT_Time"] = 15,
					["ElementTaken"] = {
						["Melee"] = 9684,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 186133,
					["TimeHeal"] = 5.61,
					["ElementDone"] = {
						["Physical"] = 139141,
						["Melee"] = 46597,
						["Nature"] = 395,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 18,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 24,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
					},
					["EnergyGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 120,
					},
					["TimeHealing"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 32.68,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1266,
									["min"] = 1266,
									["count"] = 5,
									["amount"] = 6330,
								},
							},
							["count"] = 5,
							["amount"] = 6330,
						},
					},
					["EnergyGain"] = 60,
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
					},
					["Healing"] = 6330,
					["DamageTaken"] = 9684,
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1766,
									["min"] = 1264,
									["count"] = 3,
									["amount"] = 4725,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4110,
									["min"] = 2177,
									["count"] = 10,
									["amount"] = 31968,
								},
								["Hit"] = {
									["max"] = 1826,
									["min"] = 1304,
									["count"] = 6,
									["amount"] = 9904,
								},
							},
							["count"] = 24,
							["amount"] = 46597,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7545,
									["min"] = 5205,
									["count"] = 3,
									["amount"] = 20295,
								},
							},
							["count"] = 3,
							["amount"] = 20295,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 19147,
									["min"] = 12098,
									["count"] = 3,
									["amount"] = 47539,
								},
							},
							["count"] = 3,
							["amount"] = 47539,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11910,
									["min"] = 8760,
									["count"] = 6,
									["amount"] = 65771,
								},
								["Hit"] = {
									["max"] = 3024,
									["min"] = 3024,
									["count"] = 1,
									["amount"] = 3024,
								},
							},
							["count"] = 7,
							["amount"] = 68795,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1930,
									["min"] = 1930,
									["count"] = 1,
									["amount"] = 1930,
								},
								["Hit"] = {
									["max"] = 582,
									["min"] = 582,
									["count"] = 1,
									["amount"] = 582,
								},
							},
							["count"] = 5,
							["amount"] = 2512,
						},
						["Thorns"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 79,
									["min"] = 79,
									["count"] = 5,
									["amount"] = 395,
								},
							},
							["count"] = 5,
							["amount"] = 395,
						},
					},
					["HealingTaken"] = 6330,
					["WhoHealed"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["TimeDamage"] = 27.07,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
					},
					["ManaGain"] = 2800,
					["ManaGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 16294,
								},
								["Mangle (Cat)"] = {
									["count"] = 21511,
								},
								["Melee"] = {
									["count"] = 9603,
								},
							},
							["amount"] = 47408,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Rake (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
					},
					["HealedWho"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["HOT_Time"] = 15,
					["ElementTaken"] = {
						["Melee"] = 9684,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 186133,
					["TimeHeal"] = 5.61,
					["ElementDone"] = {
						["Physical"] = 139141,
						["Melee"] = 46597,
						["Nature"] = 395,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 18,
						},
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 24,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9684,
								},
							},
							["amount"] = 9684,
						},
					},
					["EnergyGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["King of the Jungle"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 120,
					},
					["TimeHealing"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 32.68,
					["Heals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1266,
									["min"] = 1266,
									["count"] = 5,
									["amount"] = 6330,
								},
							},
							["count"] = 5,
							["amount"] = 6330,
						},
					},
					["EnergyGain"] = 60,
					["EnergyGained"] = {
						["King of the Jungle"] = {
							["Details"] = {
								["Allzz"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["TimeSpent"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 5.61,
								},
							},
							["amount"] = 5.61,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
					},
					["Healing"] = 6330,
					["DamageTaken"] = 9684,
					["DOT_Time"] = 9,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 1766,
									["min"] = 1264,
									["count"] = 3,
									["amount"] = 4725,
								},
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4110,
									["min"] = 2177,
									["count"] = 10,
									["amount"] = 31968,
								},
								["Hit"] = {
									["max"] = 1826,
									["min"] = 1304,
									["count"] = 6,
									["amount"] = 9904,
								},
							},
							["count"] = 24,
							["amount"] = 46597,
						},
						["Rake (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7545,
									["min"] = 5205,
									["count"] = 3,
									["amount"] = 20295,
								},
							},
							["count"] = 3,
							["amount"] = 20295,
						},
						["Ferocious Bite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 19147,
									["min"] = 12098,
									["count"] = 3,
									["amount"] = 47539,
								},
							},
							["count"] = 3,
							["amount"] = 47539,
						},
						["Mangle (Cat)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11910,
									["min"] = 8760,
									["count"] = 6,
									["amount"] = 65771,
								},
								["Hit"] = {
									["max"] = 3024,
									["min"] = 3024,
									["count"] = 1,
									["amount"] = 3024,
								},
							},
							["count"] = 7,
							["amount"] = 68795,
						},
						["Rake"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1930,
									["min"] = 1930,
									["count"] = 1,
									["amount"] = 1930,
								},
								["Hit"] = {
									["max"] = 582,
									["min"] = 582,
									["count"] = 1,
									["amount"] = 582,
								},
							},
							["count"] = 5,
							["amount"] = 2512,
						},
						["Thorns"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 79,
									["min"] = 79,
									["count"] = 5,
									["amount"] = 395,
								},
							},
							["count"] = 5,
							["amount"] = 395,
						},
					},
					["HealingTaken"] = 6330,
					["WhoHealed"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 6330,
								},
							},
							["amount"] = 6330,
						},
					},
					["TimeDamage"] = 27.07,
					["TimeDamaging"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 0.58,
								},
								["Mangle (Cat)"] = {
									["count"] = 0.14,
								},
								["Melee"] = {
									["count"] = 2.59,
								},
							},
							["amount"] = 3.31,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12.18,
								},
								["Rake (DoT)"] = {
									["count"] = 0.22,
								},
								["Ferocious Bite"] = {
									["count"] = 1.17,
								},
								["Mangle (Cat)"] = {
									["count"] = 1.16,
								},
								["Rake"] = {
									["count"] = 2.43,
								},
								["Thorns"] = {
									["count"] = 6.600000000000001,
								},
							},
							["amount"] = 23.76,
						},
					},
					["ManaGain"] = 2800,
					["ManaGainedFrom"] = {
						["Allzz"] = {
							["Details"] = {
								["Improved Leader of the Pack"] = {
									["count"] = 2800,
								},
							},
							["amount"] = 2800,
						},
					},
					["DamagedWho"] = {
						["Head of the Horseman"] = {
							["Details"] = {
								["Ferocious Bite"] = {
									["count"] = 16294,
								},
								["Mangle (Cat)"] = {
									["count"] = 21511,
								},
								["Melee"] = {
									["count"] = 9603,
								},
							},
							["amount"] = 47408,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 36994,
								},
								["Rake (DoT)"] = {
									["count"] = 20295,
								},
								["Ferocious Bite"] = {
									["count"] = 31245,
								},
								["Mangle (Cat)"] = {
									["count"] = 47284,
								},
								["Rake"] = {
									["count"] = 2512,
								},
								["Thorns"] = {
									["count"] = 395,
								},
							},
							["amount"] = 138725,
						},
					},
				},
			},
			["UnitLockout"] = 1604179305,
			["LastActive"] = 1604179334,
		},
		["Kalaam"] = {
			["GUID"] = "0x070000000000104C",
			["LastEventHealth"] = {
				"30632 (100%)", -- [1]
				"30632 (100%)", -- [2]
				"30632 (100%)", -- [3]
				"30632 (100%)", -- [4]
				"30632 (100%)", -- [5]
				"30632 (100%)", -- [6]
				"30632 (100%)", -- [7]
				"30632 (100%)", -- [8]
				"30632 (100%)", -- [9]
				"30632 (100%)", -- [10]
				"30632 (100%)", -- [11]
				"30632 (100%)", -- [12]
				"30632 (100%)", -- [13]
				"30632 (100%)", -- [14]
				"30632 (100%)", -- [15]
				"30632 (100%)", -- [16]
				"30632 (100%)", -- [17]
				"30632 (100%)", -- [18]
				"30632 (100%)", -- [19]
				"30632 (100%)", -- [20]
				"30632 (100%)", -- [21]
				"30632 (100%)", -- [22]
				"30632 (100%)", -- [23]
				"30632 (100%)", -- [24]
				"30632 (100%)", -- [25]
				"30632 (100%)", -- [26]
				"30632 (100%)", -- [27]
				"30632 (100%)", -- [28]
				"30632 (100%)", -- [29]
				"30632 (100%)", -- [30]
				"30632 (100%)", -- [31]
				"30632 (100%)", -- [32]
				"30632 (100%)", -- [33]
				"30632 (100%)", -- [34]
				"30632 (100%)", -- [35]
				"30632 (100%)", -- [36]
				"30632 (100%)", -- [37]
				"30632 (100%)", -- [38]
				"30632 (100%)", -- [39]
				"30632 (100%)", -- [40]
				"30632 (100%)", -- [41]
				"30632 (100%)", -- [42]
				"30632 (100%)", -- [43]
				"30632 (100%)", -- [44]
				"30632 (100%)", -- [45]
				"28266 (92%)", -- [46]
				"28266 (92%)", -- [47]
				"28266 (92%)", -- [48]
				"30632 (100%)", -- [49]
				"30632 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Headless Horseman",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"HEAL", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"HEAL", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["EnergyGain"] = {
					45, -- [1]
				},
				["DamageTaken"] = {
					2366, -- [1]
				},
				["Overhealing"] = {
					6430, -- [1]
				},
				["ActiveTime"] = {
					40.92999999999998, -- [1]
				},
				["TimeDamage"] = {
					40.92999999999998, -- [1]
				},
				["HOT_Time"] = {
					15, -- [1]
				},
				["DOT_Time"] = {
					9, -- [1]
				},
				["Damage"] = {
					224163, -- [1]
				},
			},
			["enClass"] = "ROGUE",
			["unit"] = "Kalaam",
			["level"] = 80,
			["LastDamageAbility"] = "Horseman's Cleave",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[39] = 4.198224079394097,
				[12] = 4.198224079394097,
				[46] = 7.723948811700183,
			},
			["type"] = "Self",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 2366,
			["LastAbility"] = 1138116.777,
			["Owner"] = false,
			["TimeLast"] = {
				["OVERALL"] = 1604179335,
				["DamageTaken"] = 1604179335,
				["EnergyGain"] = 1604179310,
				["Overhealing"] = 1604179332,
				["ActiveTime"] = 1604179335,
				["TimeDamage"] = 1604179335,
				["HOT_Time"] = 1604179332,
				["DOT_Time"] = 1604179330,
				["Damage"] = 1604179335,
			},
			["NextEventNum"] = 49,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				92.27605118829982, -- [46]
				92.27605118829982, -- [47]
				92.27605118829982, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Kalaam Sinister Strike Headless Horseman Crit -7589 (Physical)", -- [1]
				"Kalaam Instant Poison IX Headless Horseman Crit -2222 (Nature)", -- [2]
				"Kalaam Melee Headless Horseman Crit -2256 (Physical)", -- [3]
				"Kalaam Melee Headless Horseman Crit -4783 (Physical)", -- [4]
				"Kalaam Instant Poison IX Headless Horseman Immune (Nature)", -- [5]
				"Kalaam Eviscerate Headless Horseman Crit -6810 (Physical)", -- [6]
				"Kalaam Melee (Hack and Slash) Headless Horseman Immune", -- [7]
				"Kalaam Melee Headless Horseman Immune", -- [8]
				"Kalaam Melee Headless Horseman Immune", -- [9]
				"Kalaam Deadly Poison IX Headless Horseman Immune (Nature)", -- [10]
				"Kalaam Melee Head of the Horseman Hit -1940 (Physical)", -- [11]
				"Kalaam Improved Leader of the Pack Kalaam Tick +1286 (1286 overheal)", -- [12]
				"Kalaam Sinister Strike Head of the Horseman Crit -6609 (Physical)", -- [13]
				"Kalaam Melee Head of the Horseman Miss", -- [14]
				"Kalaam Deadly Poison IX Headless Horseman Immune (Nature)", -- [15]
				"Kalaam Instant Poison IX Headless Horseman Hit -1022 (Nature)", -- [16]
				"Kalaam Melee Headless Horseman Hit -1652 (Physical)", -- [17]
				"Kalaam Instant Poison IX Headless Horseman Hit -1122 (Nature)", -- [18]
				"Kalaam Instant Poison IX (Hack and Slash) Headless Horseman Hit -2087 (Physical)", -- [19]
				"Kalaam Sinister Strike Headless Horseman Crit -6313 (Physical)", -- [20]
				"Kalaam Instant Poison IX Headless Horseman Crit -1619 (Nature)", -- [21]
				"Kalaam Melee Headless Horseman Crit -1740 (Physical)", -- [22]
				"Kalaam Instant Poison IX Headless Horseman Hit -1028 (Nature)", -- [23]
				"Kalaam Melee Headless Horseman Hit -798 (Physical)", -- [24]
				"Kalaam Sinister Strike Headless Horseman Crit -7411 (Physical)", -- [25]
				"Kalaam Melee Headless Horseman Hit -1753 (Physical)", -- [26]
				"Kalaam Instant Poison IX Headless Horseman Hit -1047 (Nature)", -- [27]
				"Kalaam Melee Headless Horseman Hit -791 (Physical)", -- [28]
				"Kalaam Sinister Strike Headless Horseman Crit -9352 (Physical)", -- [29]
				"Kalaam Deadly Poison IX (DoT) Headless Horseman Tick -1425 (Nature)", -- [30]
				"Kalaam Blade Twisting Headless Horseman Immune (Physical)", -- [31]
				"Kalaam Instant Poison IX Headless Horseman Crit -2373 (Nature)", -- [32]
				"Kalaam Melee Headless Horseman Crit -5109 (Physical)", -- [33]
				"Kalaam Instant Poison IX Headless Horseman Crit -2378 (Nature)", -- [34]
				"Kalaam Melee Headless Horseman Crit -2150 (Physical)", -- [35]
				"Kalaam Eviscerate Headless Horseman Hit -5447 (Physical)", -- [36]
				"Kalaam Instant Poison IX Headless Horseman Hit -1237 (Nature)", -- [37]
				"Kalaam Melee Headless Horseman Crit -2076 (Physical)", -- [38]
				"Kalaam Improved Leader of the Pack Kalaam Tick +1286 (1286 overheal)", -- [39]
				"Kalaam Melee Headless Horseman Crit -4864 (Physical)", -- [40]
				"Kalaam Melee Headless Horseman Immune", -- [41]
				"Kalaam Melee Headless Horseman Immune", -- [42]
				"Kalaam Deadly Poison IX Headless Horseman Immune (Nature)", -- [43]
				"Kalaam Instant Poison IX Head of the Horseman Hit -1258 (Nature)", -- [44]
				"Kalaam Melee Head of the Horseman Crit -5220 (Physical)", -- [45]
				"Headless Horseman Horseman's Cleave Kalaam Hit -2366 (Physical)", -- [46]
				"Kalaam Instant Poison IX Head of the Horseman Crit -2437 (Nature)", -- [47]
				"Kalaam Sinister Strike Head of the Horseman Crit -7787 (Physical)", -- [48]
				"Kalaam Instant Poison IX Headless Horseman Hit -1176 (Nature)", -- [49]
				"Kalaam Melee Headless Horseman Crit -5025 (Physical)", -- [50]
			},
			["Name"] = "Kalaam",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				1138103.167, -- [1]
				1138103.169, -- [2]
				1138103.169, -- [3]
				1138104.179, -- [4]
				1138104.18, -- [5]
				1138104.18, -- [6]
				1138104.18, -- [7]
				1138104.567, -- [8]
				1138105.051, -- [9]
				1138105.216, -- [10]
				1138106.939, -- [11]
				1138107.261, -- [12]
				1138107.262, -- [13]
				1138107.442, -- [14]
				1138108.17, -- [15]
				1138108.934, -- [16]
				1138108.934, -- [17]
				1138109.103, -- [18]
				1138109.104, -- [19]
				1138109.11, -- [20]
				1138109.112, -- [21]
				1138109.113, -- [22]
				1138109.823, -- [23]
				1138109.823, -- [24]
				1138110.17, -- [25]
				1138110.582, -- [26]
				1138110.948, -- [27]
				1138110.948, -- [28]
				1138111.313, -- [29]
				1138111.885, -- [30]
				1138112.287, -- [31]
				1138112.288, -- [32]
				1138112.289, -- [33]
				1138112.448, -- [34]
				1138112.449, -- [35]
				1138112.665, -- [36]
				1138113.199, -- [37]
				1138113.199, -- [38]
				1138113.805, -- [39]
				1138113.807, -- [40]
				1138114.378, -- [41]
				1138114.969, -- [42]
				1138115.147, -- [43]
				1138116.591, -- [44]
				1138116.591, -- [45]
				1138116.771, -- [46]
				1138116.777, -- [47]
				1138116.777, -- [48]
				1138102.767, -- [49]
				1138102.767, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1286,
									["min"] = 1286,
									["count"] = 1,
									["amount"] = 1286,
								},
							},
							["count"] = 1,
							["amount"] = 1286,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9034,
								},
							},
							["amount"] = 9034,
						},
					},
					["ElementDone"] = {
						["Melee"] = 9034,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5046,
									["min"] = 3988,
									["count"] = 2,
									["amount"] = 9034,
								},
							},
							["count"] = 2,
							["amount"] = 9034,
						},
					},
					["HOT_Time"] = 3,
					["Overhealing"] = 1286,
					["ActiveTime"] = 7,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["TimeDamage"] = 7,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Damage"] = 9034,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2366,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 34,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 2366,
					},
					["DOT_Time"] = 9,
					["Damage"] = 207451,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 109991,
						["Melee"] = 66223,
						["Nature"] = 31237,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7160,
								},
								["Sinister Strike"] = {
									["count"] = 14396,
								},
								["Instant Poison IX"] = {
									["count"] = 3695,
								},
							},
							["amount"] = 25251,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["EnergyGainedFrom"] = {
						["Kalaam"] = {
							["Details"] = {
								["Combat Potency"] = {
									["count"] = 30,
								},
								["Tricks of the Trade"] = {
									["count"] = 15,
								},
							},
							["amount"] = 45,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1286,
									["min"] = 1286,
									["count"] = 4,
									["amount"] = 5144,
								},
							},
							["count"] = 4,
							["amount"] = 5144,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 45,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 5144,
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["Combat Potency"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["Tricks of the Trade"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ActiveTime"] = 31.66000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2422,
									["min"] = 791,
									["count"] = 9,
									["amount"] = 12444,
								},
								["Hit (Blocked)"] = {
									["max"] = 1652,
									["min"] = 1652,
									["count"] = 1,
									["amount"] = 1652,
								},
								["Crit"] = {
									["max"] = 5362,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 52127,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 66223,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2087,
									["min"] = 2087,
									["count"] = 1,
									["amount"] = 2087,
								},
							},
							["count"] = 1,
							["amount"] = 2087,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9352,
									["min"] = 6313,
									["count"] = 7,
									["amount"] = 51445,
								},
								["Hit"] = {
									["max"] = 3182,
									["min"] = 2912,
									["count"] = 3,
									["amount"] = 9175,
								},
							},
							["count"] = 10,
							["amount"] = 60620,
						},
						["Killing Spree"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4958,
									["min"] = 2916,
									["count"] = 5,
									["amount"] = 18958,
								},
								["Hit"] = {
									["max"] = 2494,
									["min"] = 1374,
									["count"] = 5,
									["amount"] = 10192,
								},
							},
							["count"] = 10,
							["amount"] = 29150,
						},
						["Eviscerate"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6810,
									["min"] = 6810,
									["count"] = 1,
									["amount"] = 6810,
								},
								["Hit"] = {
									["max"] = 5447,
									["min"] = 5447,
									["count"] = 1,
									["amount"] = 5447,
								},
							},
							["count"] = 2,
							["amount"] = 12257,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2437,
									["min"] = 1619,
									["count"] = 6,
									["amount"] = 13262,
								},
								["Hit"] = {
									["max"] = 1392,
									["min"] = 1022,
									["count"] = 11,
									["amount"] = 13135,
								},
							},
							["count"] = 18,
							["amount"] = 26397,
						},
						["Blade Twisting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1847,
									["min"] = 1425,
									["count"] = 3,
									["amount"] = 4840,
								},
							},
							["count"] = 3,
							["amount"] = 4840,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3963,
									["min"] = 3963,
									["count"] = 1,
									["amount"] = 3963,
								},
								["Hit"] = {
									["max"] = 1914,
									["min"] = 1914,
									["count"] = 1,
									["amount"] = 1914,
								},
							},
							["count"] = 3,
							["amount"] = 5877,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 31.66000000000001,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2366,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 34,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 2366,
					},
					["DOT_Time"] = 9,
					["Damage"] = 207451,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 109991,
						["Melee"] = 66223,
						["Nature"] = 31237,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7160,
								},
								["Sinister Strike"] = {
									["count"] = 14396,
								},
								["Instant Poison IX"] = {
									["count"] = 3695,
								},
							},
							["amount"] = 25251,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["EnergyGainedFrom"] = {
						["Kalaam"] = {
							["Details"] = {
								["Combat Potency"] = {
									["count"] = 30,
								},
								["Tricks of the Trade"] = {
									["count"] = 15,
								},
							},
							["amount"] = 45,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1286,
									["min"] = 1286,
									["count"] = 4,
									["amount"] = 5144,
								},
							},
							["count"] = 4,
							["amount"] = 5144,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 45,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 5144,
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["Combat Potency"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["Tricks of the Trade"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ActiveTime"] = 31.66000000000001,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2422,
									["min"] = 791,
									["count"] = 9,
									["amount"] = 12444,
								},
								["Hit (Blocked)"] = {
									["max"] = 1652,
									["min"] = 1652,
									["count"] = 1,
									["amount"] = 1652,
								},
								["Crit"] = {
									["max"] = 5362,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 52127,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 66223,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2087,
									["min"] = 2087,
									["count"] = 1,
									["amount"] = 2087,
								},
							},
							["count"] = 1,
							["amount"] = 2087,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9352,
									["min"] = 6313,
									["count"] = 7,
									["amount"] = 51445,
								},
								["Hit"] = {
									["max"] = 3182,
									["min"] = 2912,
									["count"] = 3,
									["amount"] = 9175,
								},
							},
							["count"] = 10,
							["amount"] = 60620,
						},
						["Killing Spree"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4958,
									["min"] = 2916,
									["count"] = 5,
									["amount"] = 18958,
								},
								["Hit"] = {
									["max"] = 2494,
									["min"] = 1374,
									["count"] = 5,
									["amount"] = 10192,
								},
							},
							["count"] = 10,
							["amount"] = 29150,
						},
						["Eviscerate"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6810,
									["min"] = 6810,
									["count"] = 1,
									["amount"] = 6810,
								},
								["Hit"] = {
									["max"] = 5447,
									["min"] = 5447,
									["count"] = 1,
									["amount"] = 5447,
								},
							},
							["count"] = 2,
							["amount"] = 12257,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2437,
									["min"] = 1619,
									["count"] = 6,
									["amount"] = 13262,
								},
								["Hit"] = {
									["max"] = 1392,
									["min"] = 1022,
									["count"] = 11,
									["amount"] = 13135,
								},
							},
							["count"] = 18,
							["amount"] = 26397,
						},
						["Blade Twisting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1847,
									["min"] = 1425,
									["count"] = 3,
									["amount"] = 4840,
								},
							},
							["count"] = 3,
							["amount"] = 4840,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3963,
									["min"] = 3963,
									["count"] = 1,
									["amount"] = 3963,
								},
								["Hit"] = {
									["max"] = 1914,
									["min"] = 1914,
									["count"] = 1,
									["amount"] = 1914,
								},
							},
							["count"] = 3,
							["amount"] = 5877,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 31.66000000000001,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 40,
					},
					["OverHeals"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1286,
									["min"] = 1286,
									["count"] = 5,
									["amount"] = 6430,
								},
							},
							["count"] = 5,
							["amount"] = 6430,
						},
					},
					["TimeSpent"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.27,
								},
							},
							["amount"] = 9.27,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["DamageTaken"] = 2366,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 6430,
					["ActiveTime"] = 40.92999999999998,
					["ElementTaken"] = {
						["Physical"] = 2366,
					},
					["HOTs"] = {
						["Improved Leader of the Pack"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["Damage"] = 224163,
					["WhoDamaged"] = {
						["Headless Horseman"] = {
							["Details"] = {
								["Horseman's Cleave"] = {
									["count"] = 2366,
								},
							},
							["amount"] = 2366,
						},
					},
					["DOTs"] = {
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Headless Horseman"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["EnergyGained"] = {
						["Combat Potency"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["Tricks of the Trade"] = {
							["Details"] = {
								["Kalaam"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Immune"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 38,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Immune"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 26,
						},
					},
					["EnergyGain"] = 45,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 8,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2422,
									["min"] = 791,
									["count"] = 9,
									["amount"] = 12444,
								},
								["Hit (Blocked)"] = {
									["max"] = 1652,
									["min"] = 1652,
									["count"] = 1,
									["amount"] = 1652,
								},
								["Crit"] = {
									["max"] = 5520,
									["min"] = 1740,
									["count"] = 19,
									["amount"] = 68839,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 38,
							["amount"] = 82935,
						},
						["Instant Poison IX (Hack and Slash)"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2087,
									["min"] = 2087,
									["count"] = 1,
									["amount"] = 2087,
								},
							},
							["count"] = 1,
							["amount"] = 2087,
						},
						["Sinister Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9352,
									["min"] = 6313,
									["count"] = 7,
									["amount"] = 51445,
								},
								["Hit"] = {
									["max"] = 3182,
									["min"] = 2912,
									["count"] = 3,
									["amount"] = 9175,
								},
							},
							["count"] = 10,
							["amount"] = 60620,
						},
						["Killing Spree"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4958,
									["min"] = 2916,
									["count"] = 5,
									["amount"] = 18958,
								},
								["Hit"] = {
									["max"] = 2494,
									["min"] = 1374,
									["count"] = 5,
									["amount"] = 10192,
								},
							},
							["count"] = 10,
							["amount"] = 29150,
						},
						["Eviscerate"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6810,
									["min"] = 6810,
									["count"] = 1,
									["amount"] = 6810,
								},
								["Hit"] = {
									["max"] = 5447,
									["min"] = 5447,
									["count"] = 1,
									["amount"] = 5447,
								},
							},
							["count"] = 2,
							["amount"] = 12257,
						},
						["Instant Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 2437,
									["min"] = 1619,
									["count"] = 6,
									["amount"] = 13262,
								},
								["Hit"] = {
									["max"] = 1392,
									["min"] = 1022,
									["count"] = 11,
									["amount"] = 13135,
								},
							},
							["count"] = 18,
							["amount"] = 26397,
						},
						["Blade Twisting"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Deadly Poison IX"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Deadly Poison IX (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1847,
									["min"] = 1425,
									["count"] = 3,
									["amount"] = 4840,
								},
							},
							["count"] = 3,
							["amount"] = 4840,
						},
						["Melee (Hack and Slash)"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 3963,
									["min"] = 3963,
									["count"] = 1,
									["amount"] = 3963,
								},
								["Hit"] = {
									["max"] = 1914,
									["min"] = 1914,
									["count"] = 1,
									["amount"] = 1914,
								},
							},
							["count"] = 3,
							["amount"] = 5877,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Horseman's Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 16712,
								},
							},
							["amount"] = 16712,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Eviscerate"] = {
									["count"] = 12257,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 4840,
								},
								["Melee"] = {
									["count"] = 59063,
								},
								["Instant Poison IX"] = {
									["count"] = 22702,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 2087,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 5877,
								},
								["Sinister Strike"] = {
									["count"] = 46224,
								},
								["Killing Spree"] = {
									["count"] = 29150,
								},
							},
							["amount"] = 182200,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7160,
								},
								["Sinister Strike"] = {
									["count"] = 14396,
								},
								["Instant Poison IX"] = {
									["count"] = 3695,
								},
							},
							["amount"] = 25251,
						},
					},
					["TimeDamage"] = 40.92999999999998,
					["TimeDamaging"] = {
						["Anguished Dead"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.27,
								},
							},
							["amount"] = 9.27,
						},
						["Headless Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.809999999999999,
								},
								["Instant Poison IX (Hack and Slash)"] = {
									["count"] = 0,
								},
								["Sinister Strike"] = {
									["count"] = 1.62,
								},
								["Killing Spree"] = {
									["count"] = 5.34,
								},
								["Eviscerate"] = {
									["count"] = 0.22,
								},
								["Instant Poison IX"] = {
									["count"] = 5.970000000000001,
								},
								["Blade Twisting"] = {
									["count"] = 0.4,
								},
								["Deadly Poison IX"] = {
									["count"] = 4.23,
								},
								["Deadly Poison IX (DoT)"] = {
									["count"] = 1.06,
								},
								["Melee (Hack and Slash)"] = {
									["count"] = 0.16,
								},
							},
							["amount"] = 27.81000000000001,
						},
						["Head of the Horseman"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.9,
								},
								["Sinister Strike"] = {
									["count"] = 0.32,
								},
								["Instant Poison IX"] = {
									["count"] = 1.63,
								},
							},
							["amount"] = 3.85,
						},
					},
					["EnergyGainedFrom"] = {
						["Kalaam"] = {
							["Details"] = {
								["Combat Potency"] = {
									["count"] = 30,
								},
								["Tricks of the Trade"] = {
									["count"] = 15,
								},
							},
							["amount"] = 45,
						},
					},
					["ElementDone"] = {
						["Physical"] = 109991,
						["Melee"] = 82935,
						["Nature"] = 31237,
					},
					["HOT_Time"] = 15,
				},
			},
			["UnitLockout"] = 1604179282,
			["LastActive"] = 1604179335,
		},
	},
	["FightNum"] = 2,
	["CombatTimes"] = {
		{
			1604179279, -- [1]
			1604179287, -- [2]
			"22:21:19", -- [3]
			"22:21:27", -- [4]
			"Anguished Dead", -- [5]
		}, -- [1]
		{
			1604179305, -- [1]
			1604179338, -- [2]
			"22:21:45", -- [3]
			"22:22:18", -- [4]
			"Headless Horseman", -- [5]
		}, -- [2]
	},
	["FoughtWho"] = {
		"Headless Horseman 22:21:45-22:22:18", -- [1]
		"Anguished Dead 22:21:19-22:21:27", -- [2]
	},
}
