
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 12,
			["y"] = -190.9139231016951,
			["x"] = -173.5113774140611,
		},
		["bank"] = {
			["y"] = -96.88874743368342,
			["x"] = 464.5924337315682,
			["point"] = "TOPLEFT",
		},
	},
	["version"] = "2.13.3",
}
