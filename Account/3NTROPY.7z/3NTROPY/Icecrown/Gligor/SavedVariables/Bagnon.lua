
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["y"] = 200.567654025673,
			["x"] = -112.9876769613854,
		},
		["bank"] = {
			["y"] = 149.9999976748339,
		},
	},
	["version"] = "2.13.3",
}
