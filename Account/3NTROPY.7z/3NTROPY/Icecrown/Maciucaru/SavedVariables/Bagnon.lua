
BagnonFrameSettings = {
	["frames"] = {
		["inventory"] = {
			["point"] = "TOPRIGHT",
			["itemFrameColumns"] = 14,
			["y"] = -96.46052295311699,
			["x"] = -149.5361286708646,
		},
		["bank"] = {
			["y"] = -55.04942995474619,
			["x"] = 162.1333514240378,
			["point"] = "TOPLEFT",
			["hiddenBags"] = {
				[-1] = true,
			},
		},
	},
	["version"] = "2.13.3",
}
